import PageManager from "./page-manager";
import swal from "./global/sweet-alert";

export default class capsv2 extends PageManager {
    constructor(context) {
        super(context);
    }

    onReady() {
      this.loadConfig();
      this.restrictions();
    }

    tablePopup() {
        swal.fire({
          customClass: {
            container: 'caps--table-popup',
            popup: 'caps--table-popup-content',
            confirmButton: 'button button--primary'
          },
          showCloseButton: true,
            html: `<table class="swal-table">
            <thead>
            <tr>
            <th colspan="4">Fraction/Decimal</th>
            </tr>
            </thead>
            <tbody>
            <tr>
            <td>1/64 <span>0.0156</span></td>
            <td>17/64 <span>0.265</span></td>
            <td>33/64 <span>0.5156</span></td>
            <td>49/64 <span>0.7656</span></td>
            </tr>
            <tr>
            <td>1/32 <span>0.0313</span></td>
            <td>9/32 <span>0.2812</span></td>
            <td>17/32 <span>0.5312</span></td>
            <td>25/32 <span>0.7812</span></td>
            </tr>
            <tr>
            <td>3/64 <span>0.0469</span></td>
            <td>19/64 <span>0.2969</span></td>
            <td>35/64 <span>0.5469</span></td>
            <td>51/64 <span>0.7969</span></td>
            </tr>
            <tr>
            <td>1/16 <span>0.0625</span></td>
            <td>5/16 <span>0.3125</span></td>
            <td>9/16 <span>0.5625</span></td>
            <td>13/16 <span>0.8125</span></td>
            </tr>
            <tr>
            <td>5/64 <span>0.0781</span></td>
            <td>21/64 <span>0.3281</span></td>
            <td>37/64 <span>0.5781</span></td>
            <td>53/64 <span>0.8281</span></td>
            </tr>
            <tr>
            <td>3/32 <span>0.0937</span></td>
            <td>11/32 <span>0.3437</span></td>
            <td>19/32 <span>0.5937</span></td>
            <td>27/32 <span>0.8437</span></td>
            </tr>
            <tr>
            <td>7/64 <span>0.1094</span></td>
            <td>23/64 <span>0.3594</span></td>
            <td>39/64 <span>0.6094</span></td>
            <td>55/64 <span>0.8594</span></td>
            </tr>
            <tr>
            <td>1/8 <span>0.1250</span></td>
            <td>3/8 <span>0.3750</span></td>
            <td>5/8 <span>0.6250</span></td>
            <td>7/8 <span>0.8750</span></td>
            </tr>
            <tr>
            <td>9/64 <span>0.1406</span></td>
            <td>25/64 <span>0.3906</span></td>
            <td>41/64 <span>0.6406</span></td>
            <td>57/64 <span>0.8906</span></td>
            </tr>
            <tr>
            <td>5/32 <span>0.1562</span></td>
            <td>13/32 <span>0.4062</span></td>
            <td>21/32 <span>0.6562</span></td>
            <td>29/32 <span>0.9062</span></td>
            </tr>
            <tr>
            <td>11/64 <span>0.1719</span></td>
            <td>27/64 <span>0.4219</span></td>
            <td>43/64 <span>0.6719</span></td>
            <td>59/64 <span>0.9219</span></td>
            </tr>
            <tr>
            <td>3/16 <span>0.1875</span></td>
            <td>7/16 <span>0.4375</span></td>
            <td>11/16 <span>0.6875</span></td>
            <td>15/16 <span>0.9375</span></td>
            </tr>
            <tr>
            <td>13/64 <span>0.2031</span></td>
            <td>29/64 <span>0.4531</span></td>
            <td>45/64 <span>0.7031</span></td>
            <td>61/64 <span>0.9531</span></td>
            </tr>
            <tr>
            <td>7/32 <span>0.2187</span></td>
            <td>15/32 <span>0.4687</span></td>
            <td>23/32 <span>0.7187</span></td>
            <td>31/32 <span>0.9687</span></td>
            </tr>
            <tr>
            <td>15/64 <span>0.2344</span></td>
            <td>31/64 <span>0.4844</span></td>
            <td>47/64 <span>0.7344</span></td>
            <td>63/64 <span>0.9844</span></td>
            </tr>
            <tr>
            <td>1/4 <span>0.250</span></td>
            <td>1/2 <span>0.5000</span></td>
            <td>3/4 <span>0.7500</span></td>
            <td>1 <span>1.0000</span></td>
            </tr>
            </tbody>
            </table>`
        });
    }

    restrictions() {
      let getSteps = document.querySelectorAll('.accordion-navigation');
      let steps;
      getSteps.forEach(step => {
        steps = step.dataset.stepNumber;
        if (steps != 'step-1') {
          step.disabled = true;
        }
      });

      let stepOneRadios = document.querySelectorAll('.caps-step__one .form-radio');
      let stepTwoRadios = document.querySelectorAll('.caps-step__two .form-radio');
      let stepThreeRadios = document.querySelectorAll('.caps-step__three .form-radio');

      let stepThreeSelects = document.querySelectorAll('.caps-step__three select');
      let stepThreeSelectFields = document.querySelectorAll('.caps-step__three .form-field select');
      let stepFourSelectFields = document.querySelectorAll('.caps-step__four .form-field select');
      let stepFourSelectParents = document.querySelectorAll('.caps-step__four .form-field')

      let stepOneContinueButton = document.querySelector('.caps-step__one .caps__continue-button');
      let stepOneContinueText = document.querySelector('.caps-step__one .caps__continue-text');
      let stepTwoContinueButton = document.querySelector('.caps-step__two .caps__continue-button');
      let stepTwoContinueText = document.querySelector('.caps-step__two .caps__continue-text');
      let stepThreeContinueButton = document.querySelector('.caps-step__three .caps__continue-button');
      let stepThreeContinueText = document.querySelector('.caps-step__three .caps__continue-text');
      let stepFourContinueButton = document.querySelector('.caps-step__four .caps__continue-button');
      let stepFourContinueText = document.querySelector('.caps-step__four .caps__continue-text');

      let stepThreeFormFields = document.querySelectorAll('.caps-step__three .form-field');      

      let materialTypes = document.querySelectorAll('[data-labelname="material-type"] .form-radio');
      let materialTypesParent = document.querySelector('[data-labelname="material-type"]');
      let mountingTypes = document.querySelectorAll('[data-labelname="mounting-type"] .form-radio');
      let mountingTypesParent = document.querySelector('[data-labelname="mounting-type"]');
      let meshTypes = document.querySelectorAll('[data-labelname="mesh-type"] .form-radio');
      let meshTypesParent = document.querySelector('[data-labelname="mesh-type"]');

      let capTypesParent = document.querySelector('.caps-step__two .form-field');

      let flangeTypeAnimalGuard = document.querySelector('[data-labelname="flange-type-animal-guard"]');
      let flangeTypeKnockdown = document.querySelector('[data-labelname="flange-type-knockdown"]');
      let flangeTypeKnockdownRadios = document.querySelectorAll('[data-labelname="flange-type-knockdown"] .form-radio');
      let lidTypeKnockdown = document.querySelector('[data-labelname="lid-type-knockdown"]');
      let lidPitchKnockdown = document.querySelector('[data-labelname="lid-pitch-knockdown"]');
      let lidPitchKnockdownSelect = document.querySelector('[data-labelname="lid-pitch-knockdown"] select');
      let flangeTypePreAssembled = document.querySelector('[data-labelname="flange-type-pre-assembled"]');
      let lidTypePreAssembled = document.querySelector('[data-labelname="lid-type-pre-assembled"]');
      let lidPitchPreAssembled = document.querySelector('[data-labelname="lid-pitch-pre-assembled"]');

      let dripEdgeOutsideMount = document.querySelector('[data-labelname="drip-edge-style-outside-mount"]');
      let dripEdgeOutsideMountRadios = document.querySelectorAll('[data-labelname="drip-edge-style-outside-mount"] .form-radio');
      let lidPitchOutsideMountSelect = document.querySelector('[data-labelname="lid-pitch-outside-mount"] select')
      let lidTypeOutsideMount = document.querySelector('[data-labelname="lid-type-outside-mount"]');
      let lidPitchOutsideMount = document.querySelector('[data-labelname="lid-pitch-outside-mount"]');
      let chimneyTypeBigDripper = document.querySelector('[data-labelname="chimney-type-the-big-dripper"]');
      let chimneyTypeBigDripperRadios = document.querySelectorAll('[data-labelname="chimney-type-the-big-dripper"] .form-radio');
      let skirtProfileBigDripper = document.querySelector('[data-labelname="skirt-profile-the-big-dripper"]');
      let skirtProfileBigDripperRadios = document.querySelectorAll('[data-labelname="skirt-profile-the-big-dripper"] .form-radio');
      let lidTypeBigDripper = document.querySelector('[data-labelname="lid-type-the-big-dripper"]');
      let lidTypeBigDripperRadios = document.querySelectorAll('[data-labelname="lid-type-the-big-dripper"] .form-radio');
      let lidPitchBigDripper = document.querySelector('[data-labelname="lid-pitch-the-big-dripper"]');
      let lidPitchBigDripperSelect = document.querySelector('[data-labelname="lid-pitch-the-big-dripper"] select');
      let lidTypeMSFRectangle = document.querySelector('[data-labelname="lid-type-msf-rectangle"]');
      let lidPitchMSFRectangle = document.querySelector('[data-labelname="lid-pitch-msf-rectangle"]');
      let lidTypeMSFRound = document.querySelector('[data-labelname="lid-type-msf-round"]');
      
      let stepOneTitle = document.querySelector('[data-step-number="step-1"]');
      let stepTwoTitle = document.querySelector('[data-step-number="step-2"]');
      let stepThreeTitle = document.querySelector('[data-step-number="step-3"]');
      let stepFourTitle = document.querySelector('[data-step-number="step-4"]');
      let stepFiveTitle = document.querySelector('[data-step-number="step-5"]');

      let stepFourInputs = document.querySelectorAll('.caps-step__four .form-input');
      let powderCoatOptions = document.querySelector('[data-labelname="powder-coat"] select');

      let length1Field = document.querySelector('[data-labelname="length-1-fractional"]');
      let length3Field = document.querySelector('[data-labelname="length-3-fractional"]');      
      let width2Field = document.querySelector('[data-labelname="width-2-fractional"]');
      let width4Field = document.querySelector('[data-labelname="width-4-fractional"]');

      let allRadioFields = document.querySelectorAll('.custom-form-pv .form-radio input');
      let allInputFields = document.querySelectorAll('.custom-form-pv input');
      let allSelectFields = document.querySelectorAll('.custom-form-pv select');
      let requestQuotePrice = document.querySelector('.customPrice');
      let addToCartButton = document.querySelector('.customPrice__add-to-cart');

      allRadioFields.forEach(radioFields => {
        radioFields.addEventListener('click', () => {
          if (requestQuotePrice.classList.contains('active')) {
            requestQuotePrice.classList.remove('active');
            addToCartButton.classList.remove('active');
          }
        });
      });

      allInputFields.forEach(inputFields => {
        inputFields.addEventListener('change', () => {
          if (requestQuotePrice.classList.contains('active')) {
            requestQuotePrice.classList.remove('active');
            addToCartButton.classList.remove('active');
          }
        });
      });

      allSelectFields.forEach(selectFields => {
        selectFields.addEventListener('change', () => {
          if (requestQuotePrice.classList.contains('active')) {
            requestQuotePrice.classList.remove('active');
            addToCartButton.classList.remove('active');
          }
        });
      });

      // start step one into two 
      stepOneRadios.forEach(stepOneRadio => {
        stepOneRadio.addEventListener('click', () => {
          materialTypes.forEach(options => {
            if (options.checked == true) {
              materialTypesParent.dataset.selected = true;
            }
          });
          mountingTypes.forEach(options => {
            if (options.checked == true) {
              mountingTypesParent.dataset.selected = true;      
            }
          });
          meshTypes.forEach(options => {
            if (options.checked == true) {
              meshTypesParent.dataset.selected = true;
            }
          });
          if (materialTypesParent.dataset.selected == 'true' && mountingTypesParent.dataset.selected == 'true' && meshTypesParent.dataset.selected == 'true') {
            stepOneContinueButton.disabled = false;
            stepOneContinueText.classList.add('hide-text')
          }

          // resets step two
          if (!stepTwoTitle.classList.contains('is-open')) {
            stepTwoTitle.disabled = true;
          }

          if (!stepThreeTitle.classList.contains('is-open')) {
            stepThreeTitle.disabled = true;
          }

          if (!stepFourTitle.classList.contains('is-open')) {
            stepFourTitle.disabled = true;
          }

          // resets step four
          stepFourContinueButton.disabled = true;
          stepFourContinueText.classList.remove('hide-text')
           if (!stepFourTitle.classList.contains('is-open')) {
            stepFourTitle.disabled = true;
           }
           stepFourTitle.click();
           stepFourTitle.disabled = true;
           stepFourInputs.forEach(stepFourInput => {
            stepFourInput.value = '';
            stepFourInput.dataset.selected = false;
           });

           stepFourSelectFields.forEach(stepFourSelectField => {
            stepFourSelectField.selectedIndex = 0;
           });

           stepFourSelectParents.forEach(stepFourSelectParent => {
            stepFourSelectParent.dataset.selected = false;
          });

          // resets step five 
          stepFiveTitle.click();
          stepFiveTitle.disabled = true;

        });
      });

      stepOneContinueButton.addEventListener('click', () => {
        if (stepOneContinueButton.disabled == false) {
          stepTwoTitle.disabled = false;
          stepOneTitle.click();
          if (!stepTwoTitle.classList.contains('is-open')) {
            stepTwoTitle.click();
          }
        }
      });

      mountingTypes.forEach(options => {
        options.addEventListener('click', () => {
          stepTwoContinueButton.disabled = true;
          stepTwoContinueText.classList.remove('hide-text')
          stepTwoTitle.click();
          stepTwoTitle.disabled = true;
          if (document.querySelector('[data-step-number="step-3"]').classList.contains('is-open')) {
            stepThreeTitle.click();
            stepThreeTitle.disabled = true;
            stepThreeContinueButton.disabled = true;
            stepThreeContinueText.classList.remove('hide-text')
          }
          powderCoatOptions.selectedIndex = 1
        });
      });
      // end step one into two 

      // start step two into three
      stepTwoRadios.forEach(stepTwoRadio => {
        stepTwoRadio.addEventListener('click', () => {
          stepTwoRadios.forEach(allStepTwoRadio => {
            allStepTwoRadio.disabled = false;
          });
          if (stepTwoRadio.checked == true) {

           capTypesParent.dataset.selected = true;

           // resets step three
           stepThreeContinueButton.disabled = true;
          //  stepThreeContinueText.classList.remove('hide-text')
           if (!stepThreeTitle.classList.contains('is-open')) {
             stepThreeTitle.disabled = true;
           }
           stepThreeTitle.click();
           stepThreeTitle.disabled = true;
           stepThreeSelectFields.forEach(stepThreeSelectField => {
            stepThreeSelectField.selectedIndex = 0;
           });

           // resets step four
           stepFourContinueButton.disabled = true;
           stepFourContinueText.classList.remove('hide-text')
           if (!stepFourTitle.classList.contains('is-open')) {
            stepFourTitle.disabled = true;
           }
           stepFourTitle.click();
           stepFourTitle.disabled = true;
           stepFourInputs.forEach(stepFourInput => {
            stepFourInput.value = '';
           });

           stepFourSelectFields.forEach(stepFourSelectField => {
            stepFourSelectField.selectedIndex = 0;
           });

           stepFourSelectParents.forEach(stepFourSelectParent => {
            stepFourSelectParent.dataset.selected = false;
          });

           // resets step five 
          stepFiveTitle.click();
          stepFiveTitle.disabled = true;
          } 

          // resets data-selected back to false for all form-fields in step three
          stepThreeFormFields.forEach(stepThreeFormField => {
            stepThreeFormField.dataset.selected = false;
          });
          if (capTypesParent.dataset.selected == 'true') {
            stepTwoContinueButton.disabled = false;
            stepTwoContinueText.classList.add('hide-text')
          }
        });
      });
      stepTwoContinueButton.addEventListener('click', () => {
        if (stepTwoContinueButton.disabled == false) {
          stepThreeTitle.disabled = false;
          stepTwoTitle.click();
          if (!stepThreeTitle.classList.contains('is-open')) {
            stepThreeTitle.click();
          }
            if (document.querySelector('.caps-no-options').classList.contains('chosen-one')) {
              stepThreeContinueButton.disabled = false;
              stepThreeContinueText.classList.add('hide-text')
            }
        }

        stepThreeSelects.forEach(stepThreeSelect => {
          stepThreeSelect.addEventListener('change', e => {
            if (lidPitchKnockdown.classList.contains('chosen-one')) {
                if (e.target.value != 'Choose Options') {
                  e.target.parentElement.dataset.selected = true;
                } else {
                  e.target.parentElement.dataset.selected = false;                
                }
                if (flangeTypeKnockdown.dataset.selected == 'true' && lidTypeKnockdown.dataset.selected == 'true' && lidPitchKnockdown.dataset.selected == 'true') {
                  stepThreeContinueButton.disabled = false;
                  stepThreeContinueText.classList.add('hide-text')
                } else {
                  stepThreeContinueButton.disabled = true;
                  stepThreeContinueText.classList.remove('hide-text')
                }
            } else if (lidPitchPreAssembled.classList.contains('chosen-one')) {
              if (e.target.value != 'Choose Options') {
                e.target.parentElement.dataset.selected = true;
              } else {
                e.target.parentElement.dataset.selected = false;                
              }
              if (flangeTypePreAssembled.dataset.selected == 'true' && lidTypePreAssembled.dataset.selected == 'true' && lidPitchPreAssembled.dataset.selected == 'true') {
                stepThreeContinueButton.disabled = false;
                stepThreeContinueText.classList.add('hide-text')
              } else {
                stepThreeContinueButton.disabled = true;
                stepThreeContinueText.classList.remove('hide-text')
              }
            } else if (lidPitchOutsideMount.classList.contains('chosen-one')) {
              if (e.target.value != 'Choose Options') {
                e.target.parentElement.dataset.selected = true;
              } else {
                e.target.parentElement.dataset.selected = false;                
              }
              if (dripEdgeOutsideMount.dataset.selected == 'true' && lidTypeOutsideMount.dataset.selected == 'true' && lidPitchOutsideMount.dataset.selected == 'true') {
                stepThreeContinueButton.disabled = false;
                stepThreeContinueText.classList.add('hide-text')
              } else {
                stepThreeContinueButton.disabled = true;
                stepThreeContinueText.classList.remove('hide-text')
              }
            } else if (lidPitchBigDripper.classList.contains('chosen-one')) {
              if (e.target.value != 'Choose Options') {
                e.target.parentElement.dataset.selected = true;
              } else {
                e.target.parentElement.dataset.selected = false;                
              }
              if (chimneyTypeBigDripper.dataset.selected == 'true' && skirtProfileBigDripper.dataset.selected == 'true' && lidTypeBigDripper.dataset.selected == 'true' && lidPitchBigDripper.dataset.selected == 'true') {
                stepThreeContinueButton.disabled = false;
                stepThreeContinueText.classList.add('hide-text')
              } else {
                stepThreeContinueButton.disabled = true;
                stepThreeContinueText.classList.remove('hide-text')
              }
            } else if (lidPitchMSFRectangle.classList.contains('chosen-one')) {
              if (e.target.value != 'Choose Options') {
                e.target.parentElement.dataset.selected = true;
              } else {
                e.target.parentElement.dataset.selected = false;                
              }
              if (lidTypeMSFRectangle.dataset.selected == 'true' && lidPitchMSFRectangle.dataset.selected == 'true') {
                stepThreeContinueButton.disabled = false;
                stepThreeContinueText.classList.add('hide-text')
              } else {
                stepThreeContinueButton.disabled = true;
                stepThreeContinueText.classList.remove('hide-text')
              }
            }
          });
        })
      });
      // end step two into three

      // start step three into step four
      stepThreeRadios.forEach(stepThreeRadio => {
        chimneyTypeBigDripperRadios.forEach(chimneyTypeBigDripperRadio => {
          chimneyTypeBigDripperRadio.addEventListener('click', e => {
            stepThreeRadios.forEach(stepThreeRadio => {
              stepThreeRadio.checked = false;
              stepThreeRadio.parentElement.parentElement.parentElement.parentElement.dataset.selected = 'false';
              e.target.checked = true;
              e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = 'true';
              stepThreeContinueButton.disabled = true;
              stepThreeContinueText.classList.remove('hide-text')
            });
            lidPitchBigDripperSelect.selectedIndex = 0;
          });
        });
        skirtProfileBigDripperRadios.forEach(skirtProfileBigDripperRadio => {
          skirtProfileBigDripperRadio.addEventListener('click', e => {
            lidTypeBigDripperRadios.forEach(lidTypeBigDripperRadio => {
              lidTypeBigDripperRadio.checked = false;
              lidTypeBigDripperRadio.parentElement.parentElement.parentElement.parentElement.dataset.selected = 'false';
              e.target.checked = true;
              e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = 'true';
              stepThreeContinueButton.disabled = true;
              stepThreeContinueText.classList.remove('hide-text')
            });
            lidPitchBigDripperSelect.selectedIndex = 0;
          });
        });
        dripEdgeOutsideMountRadios.forEach(dripEdgeOutsideMountRadio => {
          dripEdgeOutsideMountRadio.addEventListener('click', e => {
            stepThreeRadios.forEach(stepThreeRadio => {
              stepThreeRadio.checked = false;
              stepThreeRadio.parentElement.parentElement.parentElement.parentElement.dataset.selected = 'false';
              e.target.checked = true;
              e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = 'true';
            });
            lidPitchOutsideMountSelect.selectedIndex = 0;            
          });
        });
        flangeTypeKnockdownRadios.forEach(flangeTypeKnockdownRadio => {
          flangeTypeKnockdownRadio.addEventListener('click', e => {
            stepThreeRadios.forEach(stepThreeRadio => {
              stepThreeRadio.checked = false;
              stepThreeRadio.parentElement.parentElement.parentElement.parentElement.dataset.selected = 'false';
              e.target.checked = true;
              e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = 'true';
            });
            lidPitchKnockdownSelect.selectedIndex = 0;            
          });
        });
        stepThreeRadio.addEventListener('click', e => {
          stepThreeRadios.forEach(allStepThreeRadio => {
            allStepThreeRadio.disabled = false;
          });
          if (stepThreeRadio.checked == true) {
          //  stepThreeRadio.disabled = true;

           // resets step four
           stepFourContinueButton.disabled = true;
           stepFourContinueText.classList.remove('hide-text')
           if (!stepFourTitle.classList.contains('is-open')) {
            stepFourTitle.disabled = true;
           }
           stepFourTitle.click();
           stepFourTitle.disabled = true;
           stepFourInputs.forEach(stepFourInput => {
            stepFourInput.value = '';
           });

           stepFourSelectFields.forEach(stepFourSelectField => {
            stepFourSelectField.selectedIndex = 0;
           });

           stepFourSelectParents.forEach(stepFourSelectParent => {
            stepFourSelectParent.dataset.selected = false;
          });

           // resets step five 
          stepFiveTitle.click();
          stepFiveTitle.disabled = true;
          }

          // crown mounted -- animal guard
          if (flangeTypeAnimalGuard.classList.contains('chosen-one')) {
            e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = true;
          }

          // crown mounted -- knockdown
          if (flangeTypeKnockdown.classList.contains('chosen-one') && lidTypeKnockdown.classList.contains('chosen-one')) {
            e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = true;
          }

          // crown mounted -- pre-assembled
          if (flangeTypePreAssembled.classList.contains('chosen-one') && lidTypePreAssembled.classList.contains('chosen-one')) {
            e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = true;
          }

          // outside mounted -- outside mount 
          if (dripEdgeOutsideMount.classList.contains('chosen-one') && lidTypeOutsideMount.classList.contains('chosen-one')) {
            e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = true;            
          }

          // outside mounted -- big dripper
          if (chimneyTypeBigDripper.classList.contains('chosen-one') && skirtProfileBigDripper.classList.contains('chosen-one') && lidTypeBigDripper.classList.contains('chosen-one')) {
            e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = true;            
          }
          
          // terracotta mounted -- msf rectangle
          if (lidTypeMSFRectangle.classList.contains('chosen-one')) {
            e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = true;            
          }

          // terracotta mounted -- msf round
          if (lidTypeMSFRound.classList.contains('chosen-one')) {
            e.target.parentElement.parentElement.parentElement.parentElement.dataset.selected = true;            
          }

          if (e.target.parentElement.lastElementChild.textContent.includes('Basic')) {
            if (lidPitchKnockdown.classList.contains('chosen-one')) {
              if (flangeTypeKnockdown.dataset.selected == 'true' && lidTypeKnockdown.dataset.selected == 'true') {
                stepThreeContinueButton.disabled = false;
                stepThreeContinueText.classList.add('hide-text')
              }
          } else if (lidPitchPreAssembled.classList.contains('chosen-one')) {
            if (flangeTypePreAssembled.dataset.selected == 'true' && lidTypePreAssembled.dataset.selected == 'true') {
              stepThreeContinueButton.disabled = false;
              stepThreeContinueText.classList.add('hide-text')
            }
          } else if (lidPitchOutsideMount.classList.contains('chosen-one')) {
            if (dripEdgeOutsideMount.dataset.selected == 'true' && lidTypeOutsideMount.dataset.selected == 'true') {
              stepThreeContinueButton.disabled = false;
              stepThreeContinueText.classList.add('hide-text')
            }
          } else if (lidPitchBigDripper.classList.contains('chosen-one')) {
            if (chimneyTypeBigDripper.dataset.selected == 'true' && skirtProfileBigDripper.dataset.selected == 'true' && lidTypeBigDripper.dataset.selected == 'true') {
              stepThreeContinueButton.disabled = false;
              stepThreeContinueText.classList.add('hide-text')
            }
          } else if (lidPitchMSFRectangle.classList.contains('chosen-one')) {
            if (lidTypeMSFRectangle.dataset.selected == 'true') {
              stepThreeContinueButton.disabled = false;
              // stepThreeContinueText.classList.add('hide-text')
              stepThreeContinueText.classList.add('hide-text');
            }
          }


            document.querySelectorAll('.form-field.chosen-one select').forEach(selectField => {
              selectField.selectedIndex = 0;
              if (selectField.parentElement.dataset.labelname.includes('lid-pitch')) {
                selectField.disabled = true;
              }  
            })        
          } else {
            document.querySelectorAll('.form-field.chosen-one select').forEach(selectField => {
              if (selectField.parentElement.dataset.labelname.includes('lid-pitch')) {
                selectField.disabled = false;
              }  
            }) 
            stepThreeContinueButton.disabled = true;
            stepThreeContinueText.classList.remove('hide-text')
          }


          // ##### activate continue button #### \\
          if (flangeTypeAnimalGuard.dataset.selected == 'true') {
            stepThreeContinueButton.disabled = false;
            stepThreeContinueText.classList.add('hide-text')
          }

          if (lidTypeMSFRound.dataset.selected == 'true') {
            stepThreeContinueButton.disabled = false;
            stepThreeContinueText.classList.add('hide-text')
          }

        });
      });

      let activatedInputs;
      let activatedSelects;
      let selected = false;
      let filled = false;
      stepThreeContinueButton.addEventListener('click', () => {
        stepThreeTitle.click();
        if (stepFourTitle.classList.contains('is-open')) {
          stepFourTitle.click();
        }
        if (stepThreeContinueButton.disabled == false) {
          stepFourTitle.disabled = false;
          stepFourTitle.click();
        }

        activatedInputs = document.querySelectorAll('.caps-step__four .form-field.chosen-one .form-input');
        activatedSelects = document.querySelectorAll('.caps-step__four .form-field.chosen-one select');
        
        activatedInputs.forEach(stepFourInput => {
          stepFourInput.addEventListener('keyup', e => {
            if (length1Field.classList.contains('chosen-one')) {
              length1Field.dataset.selected = "true";
              length3Field.dataset.selected = "true";
              width2Field.dataset.selected = "true";
              width4Field.dataset.selected = "true";
            }

            if (e.target.value.length > 0) {
              e.target.parentElement.setAttribute('data-selected', 'true');
            } else {
              e.target.parentElement.dataset.selected = 'false';
            }

            if (activatedInputs.length == document.querySelectorAll('.caps-step__four [data-selected="true"] input').length) {
              filled = true;
            } else {
              filled = false;
            }


            if (activatedSelects.length == 0) {
              if (activatedInputs.length == document.querySelectorAll('.caps-step__four [data-selected="true"] input').length) {
                stepFourContinueButton.disabled = false;
                stepFourContinueText.classList.add('hide-text')
              } else {
                stepFourContinueButton.disabled = true;
                stepFourContinueText.classList.remove('hide-text')
              }
            } else {
              activatedSelects.forEach(stepFourSelect => {
                stepFourSelect.addEventListener('change', e => {
                  if (e.target.value != 'Choose Options') {
                    e.target.parentElement.setAttribute('data-selected', 'true');
                  } else {
                    e.target.parentElement.setAttribute('data-selected', 'false');   
                  }
                  if (activatedSelects.length == document.querySelectorAll('.caps-step__four [data-selected="true"] select').length && activatedInputs.length == document.querySelectorAll('.caps-step__four [data-selected="true"] input').length) {
                    selected = true;
                  } else {
                    selected = false;
                  }
      
                  if (!selected) {
                    stepFourContinueButton.disabled = true;
                    stepFourContinueText.classList.remove('hide-text')
                     stepFiveTitle.click();
                     stepFiveTitle.disabled = true;
                  } else {
                      stepFourContinueButton.disabled = false;
                      stepFourContinueText.classList.add('hide-text')
                  }
                });
              });
              if (!filled) {
                if (activatedSelects.length > 0) {
                  if (activatedSelects.length == document.querySelectorAll('.caps-step__four [data-selected="true"] select').length) {
                    stepFourContinueButton.disabled = true;
                    stepFourContinueText.classList.remove('hide-text')
                  }
                }
                
            } else {
              if (activatedSelects.length > 0) {
                if (activatedSelects.length == document.querySelectorAll('.caps-step__four [data-selected="true"] select').length) {
                  stepFourContinueButton.disabled = false;
                  stepFourContinueText.classList.add('hide-text')
                }
              }
            }
            }          
        });
        
        
        // input restrictions to only be numbers
        stepFourInput.addEventListener('keydown', (e) => {
          let key = e.keyCode ? e.keyCode : e.which;
          if (!( [8, 9, 13, 27, 46, 110, 190].indexOf(key) !== -1 ||
               (key == 65 && ( e.ctrlKey || e.metaKey  ) ) || 
               (key >= 35 && key <= 40) ||
               (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
               (key >= 96 && key <= 105)
             )) e.preventDefault();
            });

          // decimal point restrictions - only 3 decimal places
            stepFourInput.addEventListener('keyup', () => {
              let val = stepFourInput.value;
              let splitVal = val.split('.');
              if (splitVal.length == 2 && splitVal[1].length >= 3) {
                stepFourInput.value = splitVal[0] + '.' + splitVal[1].substr(0, 3);
              }
            });
      });
      });
      // end step three into step four

      stepFourContinueButton.addEventListener('click', () => {
        stepFiveTitle.disabled = false;
        stepFourTitle.click();
        if (!stepFiveTitle.classList.contains('is-open')) {
          stepFiveTitle.click();
        }
      });
    }

    loadConfig() {
      let mountingType = "";
      let capType = "";
      let capOptionOne = "";
      let capOptionTwo = "";
      let material  = "";
      let powderCoat = "no powder coat";
      let lidType  = "";
      let pitch  = "";
      let dripEdgeStyle = "";
      let chimneyType = "";
      let crated = "";
      let mesh = "";
      let flangeType = "";
      let skirtProfile = "";
      let mountType = "";
      let getLength;
      let length = null;
      let getLength1Whole;
      let length1Whole = null;
      let getLength1;
      let length1 = null;
      let getLength3Whole;
      let length3Whole = null;
      let getLength3;
      let length3 = null;
      let getWidth2Whole;
      let width2Whole = null;
      let getWidth2;
      let width2 = null;
      let getWidth4Whole;
      let width4Whole = null;
      let getWidth4;
      let width4 = null;
      let getWidth;
      let width = null;
      let getScreenHeight;
      let screenHeight = null;
      let getSkirtHeight;
      let skirtHeight = null;
      let getLidOverhang
      let lidOverhang = null;
      let getBuildTo;
      let buildTo = null;
      let gethorizontalSkirt;
      let horizontalSkirt = null;
      let getOutsideFlueTileLength;
      let outsideFlueTileLength = null;
      let getOutsideFlueTileWidth;
      let outsideFlueTileWidth = null;
      let getOutsideFlueTileDiameter;
      let outsideFlueTileDiameter = null;
      let getB1;
      let b1 = null;
      let getB2;
      let b2 = null;
      let getB3;
      let b3 = null;
      let getB4;
      let b4 = null;
      let getScreenInset;
      let screenInset = null;
      let getNailingFlange;
      let nailingFlange = null;
      let getR1
      let r1 = null;
      let getR2;
      let r2 = null;
      let getR3;
      let r3 = null;
      let getR4;
      let r4 = null;
      let getCTC;
      let ctc = null;

      // get all label names
      let mountingTypeLabel = document.querySelector('[data-labelname="mounting-type"] label').childNodes[0].textContent.split(':')[0].trim();      
      let materialTypeLabel = document.querySelector('[data-labelname="material-type"] label').childNodes[0].textContent.split(':')[0].trim();      
      let powderCoatLabel = document.querySelector('[data-labelname="powder-coat"] label').childNodes[0].textContent.split(':')[0].trim();      
      let meshTypeLabel = document.querySelector('[data-labelname="mesh-type"] label').childNodes[0].textContent.split(':')[0].trim();   
      let capTypeLabel = "";
      let flangeTypeLabel = "";
      let dripEdgeLabel = "";
      let chimneyTypeLabel = "";
      let lidTypeLabel = "";
      let lidPitchLabel = "";
      let skirtProfileLabel = "";
      let lengthLabel = "";
      let widthLabel = "";
      let screenHeightLabel = "";
      let lidOverhangLabel = "";
      let buildToLabel = "";
      let skirtHeightLabel = "";
      let horizontalSkirtLabel = "";
      let outsideFlueTileLengthLabel = "";
      let outsideFlueTileWidthLabel = "";
      let outsideFlueTileDiameterLabel = "";
      let b1Label = "";
      let b2Label = "";
      let b3Label = "";
      let b4Label = "";
      let screenInsetBLabel = "";
      let nailingFlangeCLabel = "";
      let r1Label = "";
      let r2Label = "";
      let r3Label = "";
      let r4Label = "";
      let ctcLabel = "";
      let length1Label = "";
      let length3Label = "";
      let width2Label = "";
      let width4Label = "";

      let mountingTypeOptions = document.querySelectorAll('[data-labelname="mounting-type"] .form-radio');
      let crownMounted = document.querySelector('[data-labelname="cap-type-crown-mounted"]');
      let outsideMounted = document.querySelector('[data-labelname="cap-type-outside-mounted"]');
      let terracottaMounted = document.querySelector('[data-labelname="cap-type-terracotta-mounted"]');
      let materialTypeOptions = document.querySelectorAll('[data-labelname="material-type"] .form-radio');
      let meshTypeOptions = document.querySelectorAll('[data-labelname="mesh-type"] .form-radio');
      let powderCoatOptions = document.querySelector('[data-labelname="powder-coat"] select');

      let stepTwoFormRadios = document.querySelectorAll('.caps-step__two .form-radio');
      let flangeTypeAnimalGuard = document.querySelector('[data-labelname="flange-type-animal-guard"]');
      let flangeTypeKnockdown = document.querySelector('[data-labelname="flange-type-knockdown"]');
      let lidTypeKnockdown = document.querySelector('[data-labelname="lid-type-knockdown"]');
      let lidPitchKnockdown = document.querySelector('[data-labelname="lid-pitch-knockdown"]');
      let flangeTypePreAssembled = document.querySelector('[data-labelname="flange-type-pre-assembled"]');
      let lidTypePreAssembled = document.querySelector('[data-labelname="lid-type-pre-assembled"]');
      let lidPitchPreAssembled = document.querySelector('[data-labelname="lid-pitch-pre-assembled"]');
      let dripEdgeOutsideMount = document.querySelector('[data-labelname="drip-edge-style-outside-mount"]');
      let lidTypeOutsideMount = document.querySelector('[data-labelname="lid-type-outside-mount"]');
      let lidPitchOutsideMount = document.querySelector('[data-labelname="lid-pitch-outside-mount"]');
      let chimneyTypeBigDripper = document.querySelector('[data-labelname="chimney-type-the-big-dripper"]');
      let skirtProfileBigDripper = document.querySelector('[data-labelname="skirt-profile-the-big-dripper"]');
      let lidTypeBigDripper = document.querySelector('[data-labelname="lid-type-the-big-dripper"]');
      let lidPitchBigDripper = document.querySelector('[data-labelname="lid-pitch-the-big-dripper"]');
      let lidTypeMSFRectangle = document.querySelector('[data-labelname="lid-type-msf-rectangle"]');
      let lidPitchMSFRectangle = document.querySelector('[data-labelname="lid-pitch-msf-rectangle"]');
      let lidTypeMSFRound = document.querySelector('[data-labelname="lid-type-msf-round"]');
      let noOptionsAvailable = document.querySelector('.caps-no-options');

      let stepThreeFormRadios = document.querySelectorAll('.caps-step__three .form-radio');
      let stepTwoFormFields = document.querySelectorAll('.caps-step__two .form-field');
      let stepThreeFormFields = document.querySelectorAll('.caps-step__three .form-field');
      let stepFourFormFields = document.querySelectorAll('.caps-step__four .form-field');
      let lengthField = document.querySelector('[data-labelname="length"]');
      let widthField = document.querySelector('[data-labelname="width"]');
      let screenHeightField = document.querySelector('[data-labelname="screen-height"]');
      let lidOverhangField = document.querySelector('[data-labelname="lid-overhang"]');
      let horizontalSkirtField = document.querySelector('[data-labelname="horizontal-skirt"]');
      let skirtHeightField = document.querySelector('[data-labelname="skirt-height"]');
      let buildToField = document.querySelector('[data-labelname="build-to"]');
      let B1field = document.querySelector('[data-labelname="b1-longest-crown-length"]');
      let B2field = document.querySelector('[data-labelname="b2-clockwise-from-b1"]');
      let B3field = document.querySelector('[data-labelname="b3-clockwise-from-b2"]');
      let B4field = document.querySelector('[data-labelname="b4-clockwise-from-b3"]');
      let skirtHeightA3point5Field = document.querySelector('[data-labelname="skirt-height-a-3-5-minimum"]');
      let skirtHeightA5Field = document.querySelector('[data-labelname="skirt-height-a-5-minimum"]');
      let skirtHeightA6Field = document.querySelector('[data-labelname="skirt-height-a-6-minimum"]');
      let outsideFlueTileLengthField = document.querySelector('[data-labelname="outside-flue-tile-length"]');
      let outsideFlueTileWidthField = document.querySelector('[data-labelname="outside-flue-tile-width"]');
      let outsideFlueTileDiameterField = document.querySelector('[data-labelname="outside-flue-tile-diameter"]');
      let screenInsetBField = document.querySelector('[data-labelname="screen-inset-b"]');
      let nailingFlangeCField = document.querySelector('[data-labelname="nailing-flange-c"]');
      let R1field = document.querySelector('[data-labelname="r1-same-side-as-b1"]');
      let R2field = document.querySelector('[data-labelname="r2-clockwise-from-r1"]');
      let R3field = document.querySelector('[data-labelname="r3-clockwise-from-r2"]');
      let R4field = document.querySelector('[data-labelname="r4-clockwise-from-r3"]');
      let CTC3point5Field = document.querySelector('[data-labelname="ctc-3-5-minimum"]');
      let CTC5Field = document.querySelector('[data-labelname="ctc-5-minimum"]');
      let CTC6Field = document.querySelector('[data-labelname="ctc-6-minimum"]');
      let length1Field = document.querySelector('[data-labelname="length-1-fractional"]');
      let width2Field = document.querySelector('[data-labelname="width-2-fractional"]');
      let length3Field = document.querySelector('[data-labelname="length-3-fractional"]');
      let width4Field = document.querySelector('[data-labelname="width-4-fractional"]');
      let length1WholeField = document.querySelector('[data-labelname="length-1"]');
      let width2WholeField = document.querySelector('[data-labelname="width-2"]');
      let length3WholeField = document.querySelector('[data-labelname="length-3"]');
      let width4WholeField = document.querySelector('[data-labelname="width-4"]');

      let stepThreeSelectFields = document.querySelectorAll('.caps-step__three select');
      let cratedOptions = document.querySelectorAll('[data-product-attribute="set-rectangle"] input');
      let stepFourContinueButton = document.querySelector('.caps-step__four .caps__continue-button');
      let quoteButton = document.querySelector('#customButton');

      let itemNotesInput = document.querySelector('.caps-step__five .form-field textarea');
      let itemNotes = 'N/A';

      lidOverhangField.firstElementChild.innerHTML += `<svg class="info-icon info-icon--lidOverhang"><use xlink:href="#icon-information-outline"></use></svg>`;
      skirtHeightField.firstElementChild.innerHTML += `<svg class="info-icon info-icon--skirtHeight"><use xlink:href="#icon-information-outline"></use></svg>`;
      length1Field.firstElementChild.innerHTML += `<svg class="info-icon info-icon--fractionsTable"><use xlink:href="#icon-information-outline"></use></svg>`;
      length3Field.firstElementChild.innerHTML += `<svg class="info-icon info-icon--fractionsTable"><use xlink:href="#icon-information-outline"></use></svg>`;
      width2Field.firstElementChild.innerHTML += `<svg class="info-icon info-icon--fractionsTable"><use xlink:href="#icon-information-outline"></use></svg>`;
      width4Field.firstElementChild.innerHTML += `<svg class="info-icon info-icon--fractionsTable"><use xlink:href="#icon-information-outline"></use></svg>`;

      length1Field.lastElementChild.selectedIndex = 1;
      length1Field.lastElementChild[0].remove();
      length3Field.lastElementChild.selectedIndex = 1;
      length3Field.lastElementChild[0].remove();
      width2Field.lastElementChild.selectedIndex = 1;
      width2Field.lastElementChild[0].remove();
      width4Field.lastElementChild.selectedIndex = 1;
      width4Field.lastElementChild[0].remove();

      // click "i" icon on length1 length3 width2 width4 to display table popup
      document.querySelectorAll('label .info-icon--fractionsTable').forEach(icon => {
        icon.addEventListener('click', e => {
          this.tablePopup();
        });
      });

      document.querySelector('.info-icon--lidOverhang').addEventListener('click', () => {
        swal.fire({
          icon: 'warning',
          html: '<p>Please enter a lid over hang (max of 8 inches)<p>'
        });
      });

      document.querySelector('.info-icon--skirtHeight').addEventListener('click', () => {
        swal.fire({
          icon: 'warning',
          html: '<p>Please enter a skirt height (max of 10 inches)<p>'
        });
      });

      // get crated -- yes or no
      cratedOptions.forEach(cratedOption => {
        cratedOption.addEventListener('click', e => {
          crated = e.target.nextElementSibling.firstElementChild.textContent          
        });
      });

      itemNotesInput.addEventListener('change', e => {
        itemNotes = e.target.value;
      });
      
      stepFourContinueButton.addEventListener('click', () => {
        let formFieldsActive = document.querySelectorAll('.caps-step__four .form-field.chosen-one');
        formFieldsActive.forEach(formFieldActive => {
          // get buildTo
          if (formFieldActive.dataset.labelname == 'build-to') {    
            buildToLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            buildTo = formFieldActive.lastElementChild.options[formFieldActive.lastElementChild.selectedIndex].textContent;
          }  
          // get length1Whole
          if (formFieldActive.dataset.labelname == 'length-1') {  
            length1Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getLength1Whole = parseFloat(formFieldActive.lastElementChild.value);
            length1Whole = Number(getLength1Whole);
          } 
          // get length1
          if (formFieldActive.dataset.labelname == 'length-1-fractional') {
            getLength1 = eval(formFieldActive.lastElementChild.options[formFieldActive.lastElementChild.selectedIndex].textContent).toFixed(4);
            length1 = parseFloat(getLength1);
          } 
          // get length3Whole
          if (formFieldActive.dataset.labelname == 'length-3') { 
            length3Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getLength3Whole = parseFloat(formFieldActive.lastElementChild.value);
            length3Whole = Number(getLength3Whole);
          } 
          // get length3
          if (formFieldActive.dataset.labelname == 'length-3-fractional') {    
            getLength3 = eval(formFieldActive.lastElementChild.options[formFieldActive.lastElementChild.selectedIndex].textContent).toFixed(4);
            length3 = parseFloat(getLength3);
          }   
          // get width2Whole
          if (formFieldActive.dataset.labelname == 'width-2') {   
            width2Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getWidth2Whole = parseFloat(formFieldActive.lastElementChild.value);
            width2Whole = Number(getWidth2Whole);
          }    
          // get width2 
          if (formFieldActive.dataset.labelname == 'width-2-fractional') {    
            getWidth2 = eval(formFieldActive.lastElementChild.options[formFieldActive.lastElementChild.selectedIndex].textContent).toFixed(4);
            width2 = parseFloat(getWidth2);
          }
           // get width4Whole
           if (formFieldActive.dataset.labelname == 'width-4') { 
            width4Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getWidth4Whole = parseFloat(formFieldActive.lastElementChild.value);
            width4Whole = Number(getWidth4Whole);
          } 
          // get width4
          if (formFieldActive.dataset.labelname == 'width-4-fractional') {  
            getWidth4 = eval(formFieldActive.lastElementChild.options[formFieldActive.lastElementChild.selectedIndex].textContent).toFixed(4);
            width4 = parseFloat(getWidth4);
          } 
          // get length
          if (formFieldActive.dataset.labelname == 'length') {
            lengthLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getLength = parseFloat(formFieldActive.lastElementChild.value);
            length = Number(getLength);
            // console.log('length: ', length);
          }
          // get width
          if (formFieldActive.dataset.labelname == 'width') {
            widthLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getWidth = parseFloat(formFieldActive.lastElementChild.value);
            width = Number(getWidth);
            // console.log('width: ', width);
          }
          // get screenHeight
          if (formFieldActive.dataset.labelname == 'screen-height') {
            screenHeightLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getScreenHeight = parseFloat(formFieldActive.lastElementChild.value);
            screenHeight = Number(getScreenHeight);
            // console.log('screen height: ', screenHeight)
          }
          // get lidOverhang
          if (formFieldActive.dataset.labelname == 'lid-overhang') {
            lidOverhangLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getLidOverhang = parseFloat(formFieldActive.lastElementChild.value);
            lidOverhang = Number(getLidOverhang);
            // console.log('lidOverHang: ', lidOverhang)
          }
          // get skirtHeight
          if (formFieldActive.dataset.labelname.includes('skirt-height')) {
            skirtHeightLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getSkirtHeight = parseFloat(formFieldActive.lastElementChild.value);
            skirtHeight = Number(getSkirtHeight);
            // console.log('skirtHeight: ', skirtHeight)
          }
          // get horizontalSkirt
          if (formFieldActive.dataset.labelname == 'horizontal-skirt') {
            horizontalSkirtLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            gethorizontalSkirt = parseFloat(formFieldActive.lastElementChild.value);
            horizontalSkirt = Number(gethorizontalSkirt);
            // console.log('horizontalSkirt: ', horizontalSkirt)
          }
          // get outsideFlueTileLength
          if (formFieldActive.dataset.labelname == 'outside-flue-tile-length') {
            outsideFlueTileLengthLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getOutsideFlueTileLength = parseFloat(formFieldActive.lastElementChild.value);
            outsideFlueTileLength = Number(getOutsideFlueTileLength);
            // console.log('outsideFlueTileLength: ', outsideFlueTileLength)
          }
          // get outsideFlueTileWidth
          if (formFieldActive.dataset.labelname == 'outside-flue-tile-width') {
            outsideFlueTileWidthLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getOutsideFlueTileWidth = parseFloat(formFieldActive.lastElementChild.value);
            outsideFlueTileWidth = Number(getOutsideFlueTileWidth);
            // console.log('outsideFlueTileWidth: ', outsideFlueTileWidth)
          }
          // get outsideFlueTileDiameter
          if (formFieldActive.dataset.labelname == 'outside-flue-tile-diameter') {
            outsideFlueTileDiameterLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getOutsideFlueTileDiameter = parseFloat(formFieldActive.lastElementChild.value);
            outsideFlueTileDiameter = Number(getOutsideFlueTileDiameter);
            // console.log('outsideFlueTileDiameter: ', outsideFlueTileDiameter)
          }
          // get B1
          if (formFieldActive.dataset.labelname == 'b1-longest-crown-length') {
            b1Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getB1 = parseFloat(formFieldActive.lastElementChild.value);
            b1 = Number(getB1);
            // console.log('b1: ', b1)
          }
          // get B2
          if (formFieldActive.dataset.labelname == 'b2-clockwise-from-b1') {
            b2Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getB2 = parseFloat(formFieldActive.lastElementChild.value);
            b2 = Number(getB2);
            // console.log('b2: ', b2)
          }
          // get B3
          if (formFieldActive.dataset.labelname == 'b3-clockwise-from-b2') {
            b3Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getB3 = parseFloat(formFieldActive.lastElementChild.value);
            b3 = Number(getB3);
            // console.log('b3: ', b3)
          }
          // get B4
          if (formFieldActive.dataset.labelname == 'b4-clockwise-from-b3') {
            b4Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getB4 = parseFloat(formFieldActive.lastElementChild.value);
            b4 = Number(getB4);
            // console.log('b4: ', b4)
          }
          // get screenInset
          if (formFieldActive.dataset.labelname.includes('screen-inset')) {
            screenInsetBLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getScreenInset = parseFloat(formFieldActive.lastElementChild.value);
            screenInset = Number(getScreenInset);
            // console.log('screenInset: ', screenInset)
          }
          // get nailing flange
          if (formFieldActive.dataset.labelname.includes('nailing-flange')) {
            nailingFlangeCLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getNailingFlange = parseFloat(formFieldActive.lastElementChild.value);
            nailingFlange = Number(getNailingFlange);
            // console.log('nailingFlange: ', nailingFlange)
          }
          // get R1
          if (formFieldActive.dataset.labelname == 'r1-same-side-as-b1') {
            r1Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getR1 = parseFloat(formFieldActive.lastElementChild.value);
            r1 = Number(getR1);
            // console.log('r1: ', r1)
          }
          // get R2
          if (formFieldActive.dataset.labelname == 'r2-clockwise-from-r1') {
            r2Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getR2 = parseFloat(formFieldActive.lastElementChild.value);
            r2 = Number(getR2);
            // console.log('r2: ', r2)
          }
          // get R3
          if (formFieldActive.dataset.labelname == 'r3-clockwise-from-r2') {
            r3Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getR3 = parseFloat(formFieldActive.lastElementChild.value);
            r3 = Number(getR3);
            // console.log('r3: ', r3)
          }
          // get R4
          if (formFieldActive.dataset.labelname == 'r4-clockwise-from-r3') {
            r4Label = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getR4 = parseFloat(formFieldActive.lastElementChild.value);
            r4 = Number(getR4);
            // console.log('r4: ', r4)
          }
          // get CTC
          if (formFieldActive.dataset.labelname.includes('ctc')) {
            ctcLabel = formFieldActive.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            getCTC = parseFloat(formFieldActive.lastElementChild.value);
            ctc = Number(getCTC);
            // console.log('ctc: ', ctc)
          }
        });
      });


      let capsImageContainer = document.querySelector('.caps__image-container');
      // crown mounted -- animal guard -- image
      let CMAnimalGuard = document.createElement('img');
      CMAnimalGuard.src = '/content/configurator-images/CM-Animal_Guard.jpg';
      CMAnimalGuard.classList.add('caps__image');

      // crown mounted -- knockdown -- image
      let CMKnockdown = document.createElement('img');
      CMKnockdown.src = '/content/configurator-images/CM-Knockdown.jpg';
      CMKnockdown.classList.add('caps__image');

      // crown mounted -- pre-assembled -- image
      let CMPreAssembled = document.createElement('img');
      CMPreAssembled.src = '/content/configurator-images/CM-Pre_Assembled.jpg';
      CMPreAssembled.classList.add('caps__image');

      // Outside mounted -- outside mount -- image
      let OMOutsideMounted = document.createElement('img');
      OMOutsideMounted.src = '/content/configurator-images/OM-Outside-Mount.jpg';
      OMOutsideMounted.classList.add('caps__image');
      
      // Outside mounted -- big dripper -- corbel -- single -- image
      let OMBD1CorbellSC = document.createElement('img');
      OMBD1CorbellSC.src = '/content/configurator-images/OM-BD1-Corbelled-SC.jpg';
      OMBD1CorbellSC.classList.add('caps__image');
      
      // Outside mounted -- big dripper -- corbel -- single -- 2nd image
      let OMBD2CorbellSC = document.createElement('img');
      OMBD2CorbellSC.src = '/content/configurator-images/OM-BD2-Corbelled-SC.jpg';
      OMBD2CorbellSC.classList.add('caps__image');

      // Outside mounted -- big dripper -- corbel -- double -- image
      let OMBD1CorbellDC = document.createElement('img');
      OMBD1CorbellDC.src = '/content/configurator-images/OM-BD1-Corbelled-DC.jpg';
      OMBD1CorbellDC.classList.add('caps__image');

      // Outside mounted -- big dripper -- corbel -- double -- 2nd image
      let OMBD2CorbellDC = document.createElement('img');
      OMBD2CorbellDC.src = '/content/configurator-images/OM-BD2-Corbelled-DC.jpg';
      OMBD2CorbellDC.classList.add('caps__image');

      // Outside mounted -- big dripper -- corbel -- sloped -- image
      let OMBD1CorbellSloped = document.createElement('img');
      OMBD1CorbellSloped.src = '/content/configurator-images/OM-BD1-Corbelled-Sloped.jpg';
      OMBD1CorbellSloped.classList.add('caps__image');

      // Outside mounted -- big dripper -- corbel -- sloped -- 2nd image
      let OMBD2CorbellSloped = document.createElement('img');
      OMBD2CorbellSloped.src = '/content/configurator-images/OM-BD2-Corbelled-Sloped.jpg';
      OMBD2CorbellSloped.classList.add('caps__image');

      // Outside mounted -- big dripper -- straight -- single -- image
      let OMBD1StraightSC = document.createElement('img');
      OMBD1StraightSC.src = '/content/configurator-images/OM-BD1-Straight-SC.jpg';
      OMBD1StraightSC.classList.add('caps__image');

      // Outside mounted -- big dripper -- straight -- double -- image
      let OMBD1StraightDC = document.createElement('img');
      OMBD1StraightDC.src = '/content/configurator-images/OM-BD1-Straight-DC.jpg';
      OMBD1StraightDC.classList.add('caps__image');

      // Outside mounted -- big dripper -- straight -- sloped -- image
      let OMBD1StraightSloped = document.createElement('img');
      OMBD1StraightSloped.src = '/content/configurator-images/OM-BD1-Straight-Sloped.jpg';
      OMBD1StraightSloped.classList.add('caps__image');

      // terracotta mounted -- MSF rectangle -- image
      let TMMSFRectangle = document.createElement('img');
      TMMSFRectangle.src = '/content/configurator-images/TM-MSF_Rectangle.jpg';
      TMMSFRectangle.classList.add('caps__image');

      // terracotta mounted -- MSF round -- image
      let TMMSFRound = document.createElement('img');
      TMMSFRound.src = '/content/configurator-images/TM-MSF_Round.jpg';
      TMMSFRound.classList.add('caps__image');

      // terracotta mounted -- animal guard -- image
      let TMAnimalGuard = document.createElement('img');
      TMAnimalGuard.src = '/content/configurator-images/TM-Animal_Guard.jpg';
      TMAnimalGuard.classList.add('caps__image');

      let capsImages;
      setTimeout(() => {
        capsImages = document.querySelectorAll('.caps__image');
      }, 500);
      capsImageContainer.append(CMAnimalGuard, CMKnockdown, CMPreAssembled, OMOutsideMounted, OMBD1StraightSC, OMBD1StraightDC, OMBD1StraightSloped, OMBD1CorbellSC, OMBD2CorbellSC, OMBD1CorbellDC, OMBD2CorbellDC, OMBD1CorbellSloped, OMBD2CorbellSloped, TMMSFRectangle, TMMSFRound, TMAnimalGuard);

      // get the material type
      materialTypeOptions.forEach(formRadio => {
        formRadio.addEventListener('click', () => {
          if (formRadio.checked == true) {
            material = formRadio.parentElement.dataset.optionName;
            if (material == 'Copper') {
              powderCoatOptions.disabled = true;
              powderCoatOptions.selectedIndex = 1
              powderCoat = powderCoatOptions.options[powderCoatOptions.selectedIndex].textContent;
            } else {
              powderCoatOptions.disabled = false;
            }
          }
        });
      });

      // get powder coat 
      powderCoatOptions.addEventListener('change', () => {
        powderCoat = powderCoatOptions.options[powderCoatOptions.selectedIndex].textContent;
      });

      // get mesh type
      meshTypeOptions.forEach(formRadio => {
        formRadio.addEventListener('click', () => {
          if (formRadio.checked == true) {
            mesh = formRadio.parentElement.dataset.optionName;
          }
        });
      });

      mountingTypeOptions.forEach(formRadio => {
        formRadio.addEventListener('click', () => {
          if (formRadio.checked == true) {
            mountingType = formRadio.parentElement.dataset.optionName;
            
            stepTwoFormRadios.forEach(formRadio => {
              formRadio.checked = false;
            });
            stepThreeFormFields.forEach(stepThreeFormField => {
              stepThreeFormField.classList.remove('chosen-one');
            });
            stepThreeFormRadios.forEach(formRadio => {
              formRadio.checked = false;
            });
            stepFourFormFields.forEach(stepFourFormField => {
              stepFourFormField.classList.remove('chosen-one');
            });

            // reset lid pitch
            if (document.querySelector('.caps-step__three .form-field').dataset.labelname.includes('Lid Pitch')) {
              powderCoatOptions.selectedIndex = 1              
            }

            // reset build to
            if (document.querySelector('.caps-step__four .form-field').dataset.labelname.includes('Build To')) {
              powderCoatOptions.selectedIndex = 1              
            }

            // reset field labels
            capTypeLabel = flangeTypeLabel = dripEdgeLabel = chimneyTypeLabel = lidTypeLabel = lidPitchLabel = skirtProfileLabel = lengthLabel = widthLabel = screenHeightLabel = lidOverhangLabel = buildToLabel = skirtHeightLabel = horizontalSkirtLabel = outsideFlueTileLengthLabel = outsideFlueTileWidthLabel = outsideFlueTileDiameterLabel = b1Label = b2Label = b3Label = b4Label = screenInsetBLabel = nailingFlangeCLabel = r1Label = r2Label = r3Label = r4Label = ctcLabel = length1Label = length3Label = width2Label = width4Label = "";

            // reset field values 
            capOptionOne = capOptionTwo = lidType = pitch = dripEdgeStyle = chimneyType = flangeType = skirtProfile = mountType = crated = "";
            length = width = screenHeight = skirtHeight = lidOverhang = buildTo = horizontalSkirt = outsideFlueTileLength = outsideFlueTileWidth = outsideFlueTileDiameter = b1 = b2 = b3 = b4 = screenInset = nailingFlange = r1 = r2 = r3 = r4 = ctc = length1 = length3 = width2 = width4 = length1Whole = length3Whole = width2Whole = width4Whole = null;
            powderCoat = "no powder coat";

            document.querySelectorAll("[data-labelname='crated'] input").forEach(createdInput => {
              createdInput.checked = false;
            });
          }
          // console.log(`step 1: ${mountingType}`);
          if (mountingType == 'Crown Mounted') {
            stepTwoFormFields.forEach(stepTwoFormField => {
              stepTwoFormField.classList.remove('chosen-one');
            });
            crownMounted.classList.add('chosen-one');
          } else if (mountingType == 'Outside Mounted') {
            stepTwoFormFields.forEach(stepTwoFormField => {
              stepTwoFormField.classList.remove('chosen-one');
            });
            outsideMounted.classList.add('chosen-one');
          } else if (mountingType == 'Terracotta Mounted') {
            stepTwoFormFields.forEach(stepTwoFormField => {
              stepTwoFormField.classList.remove('chosen-one');
            });
            terracottaMounted.classList.add('chosen-one');
          }
        });
      });

      stepTwoFormRadios.forEach(formRadio => {
        formRadio.addEventListener('click', e => {
          if (formRadio.checked == true) {
            stepThreeFormRadios.forEach(formRadio => {
              formRadio.checked = false;
            });
            stepFourFormFields.forEach(stepFourFormField => {
              stepFourFormField.classList.remove('chosen-one');
            });
            
            capsImages.forEach(capsImage => {
              capsImage.classList.remove('chosen-one');
            });

            // reset crated option (in step 5)
            document.querySelectorAll("[data-labelname='crated'] input").forEach(createdInput => {
              createdInput.checked = false;
            });

            // reset lid pitch
            if (document.querySelector('.caps-step__three .form-field').dataset.labelname.includes('Lid Pitch')) {
              powderCoatOptions.selectedIndex = 1              
            }

            // reset build to
            if (document.querySelector('.caps-step__four .form-field').dataset.labelname.includes('Build To')) {
              powderCoatOptions.selectedIndex = 1              
            }

             // reset field labels
             capTypeLabel = flangeTypeLabel = dripEdgeLabel = chimneyTypeLabel = lidTypeLabel = lidPitchLabel = skirtProfileLabel = lengthLabel = widthLabel = screenHeightLabel = lidOverhangLabel = buildToLabel = skirtHeightLabel = horizontalSkirtLabel = outsideFlueTileLengthLabel = outsideFlueTileWidthLabel = outsideFlueTileDiameterLabel = b1Label = b2Label = b3Label = b4Label = screenInsetBLabel = nailingFlangeCLabel = r1Label = r2Label = r3Label = r4Label = ctcLabel = length1Label = length3Label = width2Label = width4Label = "";

             // reset field values 
             capOptionOne = capOptionTwo = lidType = pitch = dripEdgeStyle = chimneyType = flangeType = skirtProfile = mountType = crated = "";
             length = width = screenHeight = skirtHeight = lidOverhang = buildTo = horizontalSkirt = outsideFlueTileLength = outsideFlueTileWidth = outsideFlueTileDiameter = b1 = b2 = b3 = b4 = screenInset = nailingFlange = r1 = r2 = r3 = r4 = ctc = length1 = length3 = width2 = width4 = length1Whole = length3Whole = width2Whole = width4Whole = null;

             capTypeLabel = e.target.parentElement.parentElement.parentElement.parentElement.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            //  console.log(capTypeLabel);
             capType = formRadio.parentElement.dataset.optionName;
            
          }
          // console.log(`step 1: ${mountingType} \nstep 2: ${capType}`);
          if (mountingType == 'Crown Mounted') {
            if (capType == 'Animal Guard') {
              // step three
              stepThreeFormFields.forEach(stepThreeFormField => {
                stepThreeFormField.classList.remove('chosen-one');
              });
              flangeTypeAnimalGuard.classList.add('chosen-one');

              // step four
              stepFourFormFields.forEach(stepFourFormField => {
                stepFourFormField.classList.remove('chosen-one');
              });
              length1WholeField.classList.add('chosen-one');
              length1Field.classList.add('chosen-one');
              length3WholeField.classList.add('chosen-one');
              length3Field.classList.add('chosen-one');
              width2WholeField.classList.add('chosen-one');
              width2Field.classList.add('chosen-one');
              width4WholeField.classList.add('chosen-one');
              width4Field.classList.add('chosen-one');
              screenHeightField.classList.add('chosen-one');

              // add image to step four
              CMAnimalGuard.classList.add('chosen-one');
            } else if (capType == 'Knockdown') {
              // step three
              stepThreeFormFields.forEach(stepThreeFormField => {
                stepThreeFormField.classList.remove('chosen-one');
              });
              flangeTypeKnockdown.classList.add('chosen-one');
              lidTypeKnockdown.classList.add('chosen-one');
              lidPitchKnockdown.classList.add('chosen-one');

              // step four
              stepFourFormFields.forEach(stepFourFormField => {
                stepFourFormField.classList.remove('chosen-one');
              });
              length1WholeField.classList.add('chosen-one');
              length1Field.classList.add('chosen-one');
              length3WholeField.classList.add('chosen-one');
              length3Field.classList.add('chosen-one');
              width2WholeField.classList.add('chosen-one');
              width2Field.classList.add('chosen-one');
              width4WholeField.classList.add('chosen-one');
              width4Field.classList.add('chosen-one');
              screenHeightField.classList.add('chosen-one');
              lidOverhangField.classList.add('chosen-one');

              // add image to step four
              CMKnockdown.classList.add('chosen-one');
            } else if (capType == 'Pre-Assembled') {
              // step three
              stepThreeFormFields.forEach(stepThreeFormField => {
                stepThreeFormField.classList.remove('chosen-one');
              });
              flangeTypePreAssembled.classList.add('chosen-one');
              lidTypePreAssembled.classList.add('chosen-one');
              lidPitchPreAssembled.classList.add('chosen-one');

              // step four
              stepFourFormFields.forEach(stepFourFormField => {
                stepFourFormField.classList.remove('chosen-one');
              });
              length1WholeField.classList.add('chosen-one');
              length1Field.classList.add('chosen-one');
              length3WholeField.classList.add('chosen-one');
              length3Field.classList.add('chosen-one');
              width2WholeField.classList.add('chosen-one');
              width2Field.classList.add('chosen-one');
              width4WholeField.classList.add('chosen-one');
              width4Field.classList.add('chosen-one');
              screenHeightField.classList.add('chosen-one');
              lidOverhangField.classList.add('chosen-one');

              // add image to step four
              CMPreAssembled.classList.add('chosen-one');
            }
          }

          if (mountingType == 'Outside Mounted') {
            if (capType == 'Outside Mount') {
              // step three
              stepThreeFormFields.forEach(stepThreeFormField => {
                stepThreeFormField.classList.remove('chosen-one');
              });
              dripEdgeOutsideMount.classList.add('chosen-one');
              lidTypeOutsideMount.classList.add('chosen-one');
              lidPitchOutsideMount.classList.add('chosen-one');

              // step four 
              stepFourFormFields.forEach(stepFourFormField => {
                stepFourFormField.classList.remove('chosen-one');
              });
              buildToField.classList.add('chosen-one');
              length1WholeField.classList.add('chosen-one');
              length1Field.classList.add('chosen-one');
              length3WholeField.classList.add('chosen-one');
              length3Field.classList.add('chosen-one');
              width2WholeField.classList.add('chosen-one');
              width2Field.classList.add('chosen-one');
              width4WholeField.classList.add('chosen-one');
              width4Field.classList.add('chosen-one');
              skirtHeightField.classList.add('chosen-one');
              horizontalSkirtField.classList.add('chosen-one');
              screenHeightField.classList.add('chosen-one');
              lidOverhangField.classList.add('chosen-one');

              // add image to step four 
              OMOutsideMounted.classList.add('chosen-one');
            } else if (capType == 'The Big Dripper') {
              // step three 
              stepThreeFormFields.forEach(stepThreeFormField => {
                stepThreeFormField.classList.remove('chosen-one');
              });
              chimneyTypeBigDripper.classList.add('chosen-one');
              skirtProfileBigDripper.classList.add('chosen-one');
              lidTypeBigDripper.classList.add('chosen-one');
              lidPitchBigDripper.classList.add('chosen-one');
            }
          }

          if (mountingType == 'Terracotta Mounted') {
            if (capType == 'Modified Single Flue - Rectangle') {
              // step three
              stepThreeFormFields.forEach(stepThreeFormField => {
                stepThreeFormField.classList.remove('chosen-one');
              });
              lidTypeMSFRectangle.classList.add('chosen-one');

              // step four
              stepFourFormFields.forEach(stepFourFormField => {
                stepFourFormField.classList.remove('chosen-one');
              });
              outsideFlueTileLengthField.classList.add('chosen-one');
              outsideFlueTileWidthField.classList.add('chosen-one');
              screenHeightField.classList.add('chosen-one');
              lidOverhangField.classList.add('chosen-one');
              lidPitchMSFRectangle.classList.add('chosen-one');

              // add image to step four
              TMMSFRectangle.classList.add('chosen-one');
            } else if (capType == 'Modified Single Flue - Round') {
              // step three
              stepThreeFormFields.forEach(stepThreeFormField => {
                stepThreeFormField.classList.remove('chosen-one');
              });
              lidTypeMSFRound.classList.add('chosen-one');

              // step four              
              stepFourFormFields.forEach(stepFourFormField => {
                stepFourFormField.classList.remove('chosen-one');
              });
              outsideFlueTileDiameterField.classList.add('chosen-one');
              screenHeightField.classList.add('chosen-one');
              lidOverhangField.classList.add('chosen-one');

              // add image to step four
              TMMSFRound.classList.add('chosen-one');
              TMMSFRound.classList.add('caps__image--long');
            } else if (capType == 'Animal Guard') {
              // step three
              stepThreeFormFields.forEach(stepThreeFormField => {
                stepThreeFormField.classList.remove('chosen-one');
              });
              noOptionsAvailable.classList.add('chosen-one');

              // step four              
              stepFourFormFields.forEach(stepFourFormField => {
                stepFourFormField.classList.remove('chosen-one');
              });
              outsideFlueTileLengthField.classList.add('chosen-one');
              outsideFlueTileWidthField.classList.add('chosen-one');
              screenHeightField.classList.add('chosen-one');

              // add image to step four
              TMAnimalGuard.classList.add('chosen-one');
            }
          }
        });
      });

      let chimneyTypeBigDripperOptions = document.querySelectorAll('[data-labelname="chimney-type-the-big-dripper"] .form-radio');
      let skirtProfileOptions = document.querySelectorAll('[data-labelname="skirt-profile-the-big-dripper"] .form-radio');

      // get chimney type
      stepThreeFormRadios.forEach(stepThreeRadio => {
        stepThreeRadio.addEventListener('click', e => {
          if (e.target.parentElement.parentElement.parentElement.parentElement.dataset.labelname.includes('flange-type')) {
            flangeType = stepThreeRadio.parentElement.dataset.optionName;
            // console.log('flangeType: ', flangeType);
            flangeTypeLabel = e.target.parentElement.parentElement.parentElement.parentElement.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
          }
          if (e.target.parentElement.parentElement.parentElement.parentElement.dataset.labelname.includes('drip-edge')) {
            dripEdgeStyle = stepThreeRadio.parentElement.dataset.optionName;
            // console.log('dripEdgeStyle: ', dripEdgeStyle);              
            dripEdgeLabel = e.target.parentElement.parentElement.parentElement.parentElement.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
          }
          if (e.target.parentElement.parentElement.parentElement.parentElement.dataset.labelname.includes('chimney-type')) {
            chimneyType = stepThreeRadio.parentElement.dataset.optionName;
            chimneyTypeLabel = e.target.parentElement.parentElement.parentElement.parentElement.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
          }
          if (e.target.parentElement.parentElement.parentElement.parentElement.dataset.labelname.includes('skirt-profile')) {
            skirtProfileLabel = e.target.parentElement.parentElement.parentElement.parentElement.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
          }
          if (e.target.parentElement.parentElement.parentElement.parentElement.dataset.labelname.includes('lid-type')) {
            lidType = stepThreeRadio.parentElement.dataset.optionName;
            lidTypeLabel = e.target.parentElement.parentElement.parentElement.parentElement.firstElementChild.childNodes[0].textContent.split(':')[0].trim();
            // console.log('lidType: ', lidType);
          }

          // reset crated option (in step 5)
          document.querySelectorAll("[data-labelname='crated'] input").forEach(createdInput => {
            createdInput.checked = false;
          });
        }); 
      });

      // get lid pitch
      stepThreeSelectFields.forEach(stepThreeSelectField => {
        stepThreeSelectField.addEventListener('change', e => {
          if (e.target.parentElement.dataset.labelname.includes('lid-pitch')) {
            pitch = stepThreeSelectField.options[stepThreeSelectField.selectedIndex].textContent;
            // console.log('pitch: ', pitch);
            lidPitchLabel = e.target.parentElement.firstElementChild.childNodes[0].textContent.trim();
          }
        });
      });

      chimneyTypeBigDripperOptions.forEach(formRadio => {
        formRadio.addEventListener('click', () => {
          if (formRadio.checked == true) {
            capOptionOne = formRadio.parentElement.dataset.optionName;
            skirtProfileOptions.forEach(formRadio => {
              formRadio.checked = false;
            });
            stepFourFormFields.forEach(stepFourFormField => {
              stepFourFormField.classList.remove('chosen-one');
            });
          }
          // console.log(`step 1: ${mountingType} \nstep 2: ${capType} \nstep 3: ${capOptionOne}`);
        });
      });

      skirtProfileOptions.forEach(formRadio => {
        formRadio.addEventListener('click', () => {
          if (formRadio.checked == true) {
            capOptionTwo = formRadio.parentElement.dataset.optionName;
            capsImages.forEach(capsImage => {
              capsImage.classList.remove('chosen-one');
            });
          }
          // console.log(`step 1: ${mountingType} \nstep 2: ${capType} \nstep 3: ${capOptionOne} - ${capOptionTwo}`);
          if (mountingType == 'Outside Mounted') {
            if (capType == 'The Big Dripper') {
              if (capOptionOne == 'Straight-Sided' && capOptionTwo == 'Single Corbelled') {
                stepFourFormFields.forEach(stepFourFormField => {
                  stepFourFormField.classList.remove('chosen-one');
                });
                buildToField.classList.add('chosen-one');
                B1field.classList.add('chosen-one');
                B2field.classList.add('chosen-one');
                B3field.classList.add('chosen-one');
                B4field.classList.add('chosen-one');
                skirtHeightA3point5Field.classList.add('chosen-one');
                screenInsetBField.classList.add('chosen-one');
                nailingFlangeCField.classList.add('chosen-one');
                screenHeightField.classList.add('chosen-one');
                lidOverhangField.classList.add('chosen-one');

                // add image to step four
                OMBD1StraightSC.classList.add('chosen-one');
              } else if (capOptionOne == 'Straight-Sided' && capOptionTwo == 'Double Corbelled') {
                stepFourFormFields.forEach(stepFourFormField => {
                  stepFourFormField.classList.remove('chosen-one');
                });
                buildToField.classList.add('chosen-one');
                B1field.classList.add('chosen-one');
                B2field.classList.add('chosen-one');
                B3field.classList.add('chosen-one');
                B4field.classList.add('chosen-one');
                skirtHeightA6Field.classList.add('chosen-one');
                screenInsetBField.classList.add('chosen-one');
                nailingFlangeCField.classList.add('chosen-one');
                screenHeightField.classList.add('chosen-one');
                lidOverhangField.classList.add('chosen-one');

                // add image to step four
                OMBD1StraightDC.classList.add('chosen-one');
              } else if (capOptionOne == 'Straight-Sided' && capOptionTwo == 'Sloped') {
                stepFourFormFields.forEach(stepFourFormField => {
                  stepFourFormField.classList.remove('chosen-one');
                });
                buildToField.classList.add('chosen-one');
                B1field.classList.add('chosen-one');
                B2field.classList.add('chosen-one');
                B3field.classList.add('chosen-one');
                B4field.classList.add('chosen-one');
                skirtHeightA5Field.classList.add('chosen-one');
                screenInsetBField.classList.add('chosen-one');
                nailingFlangeCField.classList.add('chosen-one');
                screenHeightField.classList.add('chosen-one');
                lidOverhangField.classList.add('chosen-one');

                // add image to step four
                OMBD1StraightSloped.classList.add('chosen-one');
              } else if (capOptionOne == 'Corbel-Sided' && capOptionTwo == 'Single Corbelled') {
                stepFourFormFields.forEach(stepFourFormField => {
                  stepFourFormField.classList.remove('chosen-one');
                });
                buildToField.classList.add('chosen-one');
                B1field.classList.add('chosen-one');
                B2field.classList.add('chosen-one');
                B3field.classList.add('chosen-one');
                B4field.classList.add('chosen-one');
                R1field.classList.add('chosen-one');
                R2field.classList.add('chosen-one');
                R3field.classList.add('chosen-one');
                R4field.classList.add('chosen-one');
                CTC3point5Field.classList.add('chosen-one');
                screenInsetBField.classList.add('chosen-one');
                nailingFlangeCField.classList.add('chosen-one');
                screenHeightField.classList.add('chosen-one');
                lidOverhangField.classList.add('chosen-one');

                // add image to step four
                OMBD1CorbellSC.classList.add('chosen-one');
                OMBD2CorbellSC.classList.add('chosen-one');
              } else if (capOptionOne == 'Corbel-Sided' && capOptionTwo == 'Double Corbelled') {
                stepFourFormFields.forEach(stepFourFormField => {
                  stepFourFormField.classList.remove('chosen-one');
                });
                buildToField.classList.add('chosen-one');
                B1field.classList.add('chosen-one');
                B2field.classList.add('chosen-one');
                B3field.classList.add('chosen-one');
                B4field.classList.add('chosen-one');
                R1field.classList.add('chosen-one');
                R2field.classList.add('chosen-one');
                R3field.classList.add('chosen-one');
                R4field.classList.add('chosen-one');
                CTC6Field.classList.add('chosen-one');
                screenInsetBField.classList.add('chosen-one');
                nailingFlangeCField.classList.add('chosen-one');
                screenHeightField.classList.add('chosen-one');
                lidOverhangField.classList.add('chosen-one');

                // add image to step four
                OMBD1CorbellDC.classList.add('chosen-one');
                OMBD2CorbellDC.classList.add('chosen-one');
              } else if (capOptionOne == 'Corbel-Sided' && capOptionTwo == 'Sloped') {
                stepFourFormFields.forEach(stepFourFormField => {
                  stepFourFormField.classList.remove('chosen-one');
                });
                buildToField.classList.add('chosen-one');
                B1field.classList.add('chosen-one');
                B2field.classList.add('chosen-one');
                B3field.classList.add('chosen-one');
                B4field.classList.add('chosen-one');
                R1field.classList.add('chosen-one');
                R2field.classList.add('chosen-one');
                R3field.classList.add('chosen-one');
                R4field.classList.add('chosen-one');
                CTC5Field.classList.add('chosen-one');
                screenInsetBField.classList.add('chosen-one');
                nailingFlangeCField.classList.add('chosen-one');
                screenHeightField.classList.add('chosen-one');
                lidOverhangField.classList.add('chosen-one');

                // add image to step four
                OMBD1CorbellSloped.classList.add('chosen-one');
                OMBD2CorbellSloped.classList.add('chosen-one');
              }
            }
          }
        });
      });

      let loyaltyLevel = "";
      let shippingTerms = "";
      let loyaltyTierId = this.context.loyalty_tier_id;
      let shippingTermsId = this.context.shipping_terms_id;
      fetch("/graphql", {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.context.storefront_api}`,
        },
        body: JSON.stringify({
          query: `
                    query {
                      loyaltyProgram: customer {
                        attributes {
                          attribute (entityId: ${loyaltyTierId}) {
                            value
                          }
                        }
                      }
                      shippingTerms: customer {
                        attributes {
                          attribute (entityId: ${shippingTermsId}) {
                            value
                          }
                        }
                      }
                    }`,
        }),
      })
        .then((response) => response.json())
        .then((res) => {
          if (res.data.loyaltyProgram.attributes.attribute.value != null) {
            loyaltyLevel = res.data.loyaltyProgram.attributes.attribute.value;
            shippingTerms = res.data.shippingTerms.attributes.attribute.value;
          } else {
            $.ajax({
              type: "GET",
              url: "/account.php?action=account_details",
              dataType: "html",
              success: response => {
                loyaltyLevel = $(response).find(`#FormField_${this.context.account_details_loyaltyTier_ID} option:selected`).text();
                shippingTerms = $(response).find(`#FormField_${this.context.account_details_shippingTerms_ID} option:selected`).text();
              }
            })
          }
        });

      quoteButton.addEventListener('click', () => {
        this.customForm(mountingType, capType, capOptionTwo, material, powderCoat, mesh, flangeType, pitch, lidType, dripEdgeStyle, chimneyType, crated, screenHeight, lidOverhang, buildTo, skirtHeight, horizontalSkirt, outsideFlueTileWidth, outsideFlueTileLength, outsideFlueTileDiameter, b1, b2, b3, b4, screenInset, nailingFlange, r1, r2, r3, r4, ctc, length1, length3, width2, width4, mountingTypeLabel, materialTypeLabel, powderCoatLabel, meshTypeLabel, screenHeightLabel, lidOverhangLabel, buildToLabel, skirtHeightLabel, horizontalSkirtLabel, outsideFlueTileLengthLabel, outsideFlueTileWidthLabel, outsideFlueTileDiameterLabel, b1Label, b2Label, b3Label, b4Label, screenInsetBLabel, nailingFlangeCLabel, r1Label, r2Label, r3Label, r4Label, capTypeLabel, chimneyTypeLabel, skirtProfileLabel, lidTypeLabel, lidPitchLabel, flangeTypeLabel, dripEdgeLabel, ctcLabel, length1Label, length3Label, width2Label, width4Label, length1Whole, length3Whole, width2Whole, width4Whole, loyaltyLevel, shippingTerms, itemNotes);
      });

      let stepFourParentContainer = document.querySelector('.caps__image-container');
      let specialFieldsContainer = document.createElement('div');
      specialFieldsContainer.classList.add('special-fields-container');
      specialFieldsContainer.append(length1WholeField, length1Field, width2WholeField, width2Field, length3WholeField, length3Field, width4WholeField, width4Field);
      this.insertAfter(stepFourParentContainer, specialFieldsContainer);


    }

    insertAfter(referenceNode, newNode) {
      referenceNode.parentNode.insertBefore(newNode, referenceNode.nextElementSibling);
    }
    
    //Custom AE Form Submission
    customForm(mountingType, capType, capOptionTwo, material, powderCoat, mesh, flangeType, pitch, lidType, dripEdgeStyle, chimneyType, crated, screenHeight, lidOverhang, buildTo, skirtHeight, horizontalSkirt, outsideFlueTileWidth, outsideFlueTileLength, outsideFlueTileDiameter, b1, b2, b3, b4, screenInset, nailingFlange, r1, r2, r3, r4, ctc, length1, length3, width2, width4, mountingTypeLabel, materialTypeLabel, powderCoatLabel, meshTypeLabel, screenHeightLabel, lidOverhangLabel, buildToLabel, skirtHeightLabel, horizontalSkirtLabel, outsideFlueTileLengthLabel, outsideFlueTileWidthLabel, outsideFlueTileDiameterLabel, b1Label, b2Label, b3Label, b4Label, screenInsetBLabel, nailingFlangeCLabel, r1Label, r2Label, r3Label, r4Label, capTypeLabel, chimneyTypeLabel, skirtProfileLabel, lidTypeLabel, lidPitchLabel, flangeTypeLabel, dripEdgeLabel, ctcLabel, length1Label, length3Label, width2Label, width4Label, length1Whole, length3Whole, width2Whole, width4Whole, loyaltyLevel, shippingTerms, itemNotes) {
              const postBody = {
                "material_type": {
                  "display_name": materialTypeLabel,
                  "option_value": material
                },
                "powder_coat": {
                    "display_name": powderCoatLabel,
                    "option_value": powderCoat
                },
                "mounting_type": {
                    "display_name": mountingTypeLabel,
                    "option_value": mountingType
                },
                "mesh_type": {
                    "display_name": meshTypeLabel,
                    "option_value": mesh
                },
                "cap_type": {
                    "display_name": capTypeLabel,
                    "option_value": capType
                },
                "flange_type": {
                    "display_name": flangeTypeLabel,
                    "option_value": flangeType
                },
                "lid_type": {
                    "display_name": lidTypeLabel,
                    "option_value": lidType
                },
                "lid_pitch": {
                    "display_name": lidPitchLabel,
                    "option_value": pitch
                },
                "drip_edge_style": {
                    "display_name": dripEdgeLabel,
                    "option_value": dripEdgeStyle
                },
                "chimney_type": {
                    "display_name": chimneyTypeLabel,
                    "option_value": chimneyType
                },
                "skirt_profile": {
                    "display_name": skirtProfileLabel,
                    "option_value": capOptionTwo
                },
                "length1": {
                  "display_name": length1Label,
                  "option_value": length1Whole + length1
                },
                "length3": {
                  "display_name": length3Label,
                  "option_value": length3Whole + length3
                },
                "width2": {
                  "display_name": width2Label,
                  "option_value": width2Whole + width2
                },
                "width4": {
                  "display_name": width4Label,
                  "option_value": width4Whole + width4
                },
                "screen_height": {
                    "display_name": screenHeightLabel,
                    "option_value": screenHeight
                },
                "lid_overhang": {
                    "display_name": lidOverhangLabel,
                    "option_value": lidOverhang
                },
                "build_to": {
                    "display_name": buildToLabel,
                    "option_value": buildTo
                },
                "skirt_height": {
                    "display_name": skirtHeightLabel,
                    "option_value": skirtHeight
                },
                "horizontal_Skirt": {
                    "display_name": horizontalSkirtLabel,
                    "option_value": horizontalSkirt
                },
                "outside_flue_tile_length": {
                    "display_name": outsideFlueTileLengthLabel,
                    "option_value": outsideFlueTileLength
                },
                "outside_flue_tile_width": {
                    "display_name": outsideFlueTileWidthLabel,
                    "option_value": outsideFlueTileWidth
                },
                "outside_flue_tile_diameter": {
                    "display_name": outsideFlueTileDiameterLabel,
                    "option_value": outsideFlueTileDiameter
                },
                "b1": {
                    "display_name": b1Label,
                    "option_value": b1
                },
                "b2": {
                    "display_name": b2Label,
                    "option_value": b2
                },
                "b3": {
                    "display_name": b3Label,
                    "option_value": b3
                },
                "b4": {
                    "display_name": b4Label,
                    "option_value": b4
                },
                "screen_inset": {
                    "display_name": screenInsetBLabel,
                    "option_value": screenInset
                },
                "nailing_flange": {
                    "display_name": nailingFlangeCLabel,
                    "option_value": nailingFlange
                },
                "r1": {
                    "display_name": r1Label,
                    "option_value": r1
                },
                "r2": {
                    "display_name": r2Label,
                    "option_value": r2
                },
                "r3": {
                    "display_name": r3Label,
                    "option_value": r3
                },
                "r4": {
                    "display_name": r4Label,
                    "option_value": r4
                },
                "ctc": {
                    "display_name": ctcLabel,
                    "option_value": ctc
                },
                "crated": {
                    "display_name": "Crated",
                    "option_value": crated
                },
                "item_notes": {
                    "display_name": "Item Notes",
                    "option_value": itemNotes
                },
                "loyalty_level": {
                  "display_name": "Loyalty Level",
                  "option_value": loyaltyLevel
                },
                "shipping_terms": {
                  "display_name": "Shipping Terms",
                  "option_value": shippingTerms
                }
              }
              let jsonPostBody = JSON.stringify(postBody);



              var requestOptions = {
              method: 'GET',
              redirect: 'follow'
              };
              

              fetch(`/customer/current.jwt?app_client_id=${this.context.middleware_client_id_v2}&random=${Math.random().toString(36)}`, requestOptions)
              .then(response => {
                  if (response.ok) {
                    // console.log('response under response.ok: ', response);
                      return response.text();
                  } else {
                    // console.log('some error')
                      return undefined;
                  }
              })
              .then(result => {
                  let formJwt = result;
                  var xhr = new XMLHttpRequest();
                  let outsideThis = this
                  let jsonResponse;
                  // console.log('result: ', result);
                  if (result == undefined) {
                    swal.fire({
                      title: 'please login to continue!',
                      showCancelButton: true,
                      showCloseButton: true,
                      confirmButtonText: 'Login'
                    }).then((result) => {
                      if (result.isConfirmed) {
                        window.location.href = "/login.php";
                      }
                    }); 
                  } else {
                    xhr.addEventListener("readystatechange", function() {
                      // console.log('this: ', this);
                      jsonResponse = JSON.parse(this.responseText);
                      // console.log('jsonResponse: ', jsonResponse);
                    if(jsonResponse.Success == true) {
                        // console.log('res: ', res);
                        let price = parseFloat(jsonResponse.Price).toFixed(2);
                        // console.log('price: ', price);
                        $('.customPrice__text').html(`The price for your custom cap is: $${price}`);
                        $('.customPrice').addClass('active');
                        $('.customPrice__add-to-cart').addClass('active');
                    } 
                    else {
                        let parsedJSON = JSON.parse(this.responseText)
                        let errorArray = Array.from(parsedJSON.Errors);
                        let htmlArray = [];
                        errorArray.forEach(err => {
                            htmlArray.push(`<p style='margin-bottom: .5rem' >${err}</p>`)
                        })
                        let errors = htmlArray.join(" ")
                        swal.fire({
                            html: errors,
                            icon: 'error',
                            onClose: outsideThis.hideLoader
                        });
                    }
                    });
                  }

                  // ############# add to cart functionality ############### \\
                  document.querySelector('.customPrice__add-to-cart').addEventListener('click', function() {
  
                    outsideThis.isCartFetch(data => {
                        let cartId = data;
                        // console.log('cardid: ', cartId)


                        if (cartId == false) {
                          console.log('create a cart')
                            outsideThis.isLoggedIn(jwt => {
                                outsideThis.createCart(jwt, jsonPostBody)
                            })
                        } else {
                          console.log('cart is already created - just add to cart')
                            outsideThis.isLoggedIn(jwt => {
                                outsideThis.addToCart(cartId, jwt, jsonPostBody)
                            })
                        }
                    })
                })
                // $('.loadingOverlay').hide();
                  
                  xhr.open("POST", `${this.context.middleware_url_v2}/api/olympia/quote`);

                  xhr.setRequestHeader("Content-Type", "application/json");
                  if (formJwt) {
                      // console.log('hit here')
                      xhr.setRequestHeader("Authorization", `Bearer ${formJwt}`);
                  }
                  
                  xhr.send(jsonPostBody);
                  })
                  .catch(error => console.log('error', error));
                  
             
  }

       //does cart exist
       isCartFetch(callback) {
        console.log('isCartFetch()');
        var data = "";
        var xhr = new XMLHttpRequest();

        xhr.addEventListener("readystatechange", function() {
        if(this.readyState === 4) {
            // console.log('here',this.responseText)
            if (this.responseText == '[]') {
                // console.log('hit here')
                callback(false)
            } else {
                callback(JSON.parse(this.responseText)[0].id)
            }
        }
        });

        xhr.open("GET", "/api/storefront/carts");

        xhr.send(data);
    }

    /* -------------------------------------------------------------------------- */
    isLoggedIn(callback) {
      var data = "";

      var xhr = new XMLHttpRequest();

      xhr.addEventListener("readystatechange", function() {
      let jwt = ''
      if (this.readyState === 4) {
          if (this.status == 200) {
              jwt = this.responseText
              callback(jwt)
          };
      }
      });

      xhr.open("GET", `/customer/current.jwt?app_client_id=${this.context.middleware_client_id_v2}&random=${Math.random().toString(36)}`);

      xhr.send(data);
  }
  /* -------------------------------------------------------------------------- */
      createCart(jwt, jsonPostBody) {
          var xhr = new XMLHttpRequest();
          
          xhr.addEventListener("readystatechange", function() {
            // console.log('this: ', this);
              if(this.readyState === 4) {
                  console.log('created', this.responseText)
                  let rez = JSON.parse(this.responseText);
                  let xhrStatus = this.status
                  if (rez.Success == false) {
                    let parsedJSON = JSON.parse(this.responseText)
                        let errorArray = Array.from(parsedJSON.Errors);
                        let htmlArray = [];
                        errorArray.forEach(err => {
                            htmlArray.push(`<p style='margin-bottom: .5rem' >${err}</p>`)
                        })
                        let errors = htmlArray.join(" ")
                        swal.fire({
                            html: errors,
                            icon: 'error'
                        });
                  } else {
                    setTimeout(function(){
                      $('.loadingOverlay').hide();
                      if (xhrStatus == 200 && rez.Success == true) {
                        $('#add-to-cart-success').addClass('is-visible');
                        window.location = rez.data.redirect_urls.cart_url;
                          setInterval(() => {
                              $('#add-to-cart-success').removeClass('is-visible');
                          }, 4000);
                      }
                    }, 1000);
                  }  
              } 
            
          });
          
          xhr.open("POST", `${this.context.middleware_url_v2}/api/olympia/cart`);
          xhr.setRequestHeader("Content-Type", "application/json");
          if (jwt != '') {
              xhr.setRequestHeader("Authorization", `Bearer ${jwt}`);
          }
          
          xhr.send(jsonPostBody);
      }
  /* -------------------------------------------------------------------------- */
      addToCart(cartId, jwt, jsonPostBody) {
        console.log('addToCart()');
          var xhr = new XMLHttpRequest();
          
          xhr.addEventListener("readystatechange", function() {
            // console.log('this: ', this);
              if(this.readyState === 4) {
                $('.loadingOverlay').show();
                let rez = JSON.parse(this.responseText);
                  console.log('this.responseText: ', this.responseText);
                  console.log('rez: ', rez);
                  let xhrStatus = this.status
                  setTimeout(function(){
                    if (xhrStatus == 200 && rez.Success == true) {
                      $('.loadingOverlay').hide();
                        $('#add-to-cart-success').addClass('is-visible');
                        window.location = rez.data.redirect_urls.cart_url;
                          setInterval(() => {
                              $('#add-to-cart-success').removeClass('is-visible');
                          }, 4000);
                      } else {
                      $('.loadingOverlay').hide();
                        swal.fire({
                          icon: "error",
                          title: 'There was an error',
                          text: 'Item not added to cart.'
                        })
                      }
                    }, 1000);
              }
            
          });
          
          xhr.open("POST", `${this.context.middleware_url_v2}/api/olympia/cart?cartId=${cartId}`);
          xhr.setRequestHeader("Content-Type", "application/json");
          if (jwt != '') {
              xhr.setRequestHeader("Authorization", `Bearer ${jwt}`);
          }
          
            
          xhr.send(jsonPostBody);
      }
  /* -------------------------------------------------------------------------- */



  minLength(errorString) {
      let flue = document.querySelector('#ddlCapType')
      let length = document.querySelector('#txtLongLength')
      if ((length.value.trim() == "" || length.value < 9) && (flue.options[flue.selectedIndex].value != 'MFSRnd')) {
          swal.fire({
              text: errorString,
              icon: 'error',
          });
      }
  };
  /* -------------------------------------------------------------------------- */
  minWidth(errorString) {
      let flue = document.querySelector('#ddlCapType')
      let width = document.querySelector('#txtLongWidth')
      if ((width.value.trim() == "" || width.value < 9) && (flue.options[flue.selectedIndex].value != 'MFSRnd')) {
          swal.fire({
              text: errorString,
              icon: 'error',
          });
      }
  };

}
