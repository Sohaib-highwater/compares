import utils from '@bigcommerce/stencil-utils';
import ProductDetailsBase, { optionChangeDecorator } from './product-details-base';
import 'foundation-sites/js/foundation/foundation';
import 'foundation-sites/js/foundation/foundation.reveal';
import ImageGallery from '../product/image-gallery';
import modalFactory, { showAlertModal, modalTypes } from '../global/modal';
import { isEmpty, isPlainObject } from 'lodash';
import { normalizeFormData } from './utils/api';
import { isBrowserIE, convertIntoArray } from './utils/ie-helpers';
import bannerUtils from './utils/banner-utils';

export default class ProductDetails extends ProductDetailsBase {
    constructor($scope, context, productAttributesData = {}) {
        super($scope, context);

        this.$overlay = $('[data-cart-item-add] .loadingOverlay');
        this.imageGallery = new ImageGallery($('[data-image-gallery]', this.$scope));
        this.imageGallery.init();
        this.listenQuantityChange();
        this.$swatchOptionMessage = $('.swatch-option-message');
        this.swatchOptionMessageInitText = this.$swatchOptionMessage.text();

        const $form = $('form[data-cart-item-add]', $scope);
        const $productOptionsElement = $('[data-product-option-change]', $form);
        const hasOptions = $productOptionsElement.html().trim().length;
        const hasDefaultOptions = $productOptionsElement.find('[data-default]').length;
        const $productSwatchGroup = $('[id*="attribute_swatch"]', $form);

        // Update product attributes. Also update the initial view in case items are oos
    // or have default variant properties that change the view
    if ((isEmpty(productAttributesData) || hasDefaultOptions) && hasOptions) {
      const $productId = $('[name="product_id"]', $form).val();
      const optionChangeCallback = optionChangeDecorator.call(this, hasDefaultOptions);

      utils.api.productAttributes.optionChange($productId, $form.serialize(), 'products/bulk-discount-rates', optionChangeCallback);
    } else {
      this.updateProductAttributes(productAttributesData);
      bannerUtils.dispatchProductBannerEvent(productAttributesData);
    }
        
        $productOptionsElement.on('change', event => {
            this.productOptionsChanged(event);
            this.setProductVariant();
        });

        $productOptionsElement.show();

        this.previewModal = modalFactory('#previewModal')[0];


    let thumbnailLink = document.querySelector('.productView-thumbnail-link');
    if (typeof thumbnailLink != 'undefined' && thumbnailLink != null) {
      this.activeImage();
    }

    let wishlistSelect = document.querySelector('.form-wishlist');
    if (typeof wishlistSelect != 'undefined' && wishlistSelect != null) {
      this.wishlistParent();
    }

  }

  customAjax() {
    $.ajax({
      type: "GET",
      url: "/account.php?action=account_details",
      dataType: "html",
      success: response => {
        const ajaxLoyaltyTier = $(response).find(`#FormField_${this.context.account_details_loyaltyTier_ID} option:selected`).text().toLowerCase();
        const ajaxShippingTerms = $(response).find(`#FormField_${this.context.account_details_shippingTerms_ID} option:selected`).text().toLowerCase();
        console.log('loyaltyTier:', ajaxLoyaltyTier);
        console.log('shipping terms:', ajaxShippingTerms);
      }
    })
  }

  wishlistParent() {
    let wishlistSelect = document.querySelector('.form-wishlist');
    document.querySelector('.productView').addEventListener('click', e => {
      if (e.target.parentElement.classList.contains('form-wishlist')) {
        e.target.parentElement.classList.toggle('is-open');
      } else {
        wishlistSelect.classList.remove('is-open');
      }
    });
  }

  activeImage() {
    document.querySelector('.productView-thumbnail-link').classList.add('is-active');
  }

  countPillChecker() {
    // console.log('countPillChecker()')
    let countPill = document.querySelector('.countPill');
    // console.log(countPill)
    if (countPill.classList.contains('countPill--positive')) {
      let countPillPositive = document.querySelector('.countPill--positive');
      // console.log('countPillPositive', countPillPositive.textContent)
    }
  }

  setProductVariant() {
    const unsatisfiedRequiredFields = [];
    const options = [];

    $.each($('[data-product-attribute]'), (index, value) => {
      const optionLabel = value.children[0].innerText;
      const optionTitle = optionLabel.split(':')[0].trim();
      const required = optionLabel.toLowerCase().includes('required');
      const type = value.getAttribute('data-product-attribute');

      if ((type === 'input-file' || type === 'input-text' || type === 'input-number') && value.querySelector('input').value === '' && required) {
        unsatisfiedRequiredFields.push(value);
      }

      if (type === 'textarea' && value.querySelector('textarea').value === '' && required) {
        unsatisfiedRequiredFields.push(value);
      }

      if (type === 'date') {
        const isSatisfied = Array.from(value.querySelectorAll('select')).every((select) => select.selectedIndex !== 0);

        if (isSatisfied) {
          const dateString = Array.from(value.querySelectorAll('select')).map((x) => x.value).join('-');
          options.push(`${optionTitle}:${dateString}`);

          return;
        }

        if (required) {
          unsatisfiedRequiredFields.push(value);
        }
      }

      if (type === 'set-select') {
        const select = value.querySelector('select');
        const selectedIndex = select.selectedIndex;

        if (selectedIndex !== 0) {
          options.push(`${optionTitle}:${select.options[selectedIndex].innerText}`);

          return;
        }

        if (required) {
          unsatisfiedRequiredFields.push(value);
        }
      }

      if (type === 'set-rectangle' || type === 'set-radio' || type === 'swatch' || type === 'input-checkbox' || type === 'product-list') {
        const checked = value.querySelector(':checked');
        if (checked) {
          const getSelectedOptionLabel = () => {
            const productVariantslist = convertIntoArray(value.children);
            const matchLabelForCheckedInput = inpt => inpt.dataset.productAttributeValue === checked.value;
            return productVariantslist.filter(matchLabelForCheckedInput)[0];
          };
          if (type === 'set-rectangle' || type === 'set-radio' || type === 'product-list') {
            const label = isBrowserIE ? getSelectedOptionLabel().innerText.trim() : checked.labels[0].innerText;
            if (label) {
              options.push(`${optionTitle}:${label}`);
            }
          }

          if (type === 'swatch') {
            const label = isBrowserIE ? getSelectedOptionLabel().children[0] : checked.labels[0].children[0];
            if (label) {
              options.push(`${optionTitle}:${label.title}`);
            }
          }

          if (type === 'input-checkbox') {
            options.push(`${optionTitle}:Yes`);
          }

          return;
        }

        if (type === 'input-checkbox') {
          options.push(`${optionTitle}:No`);
        }

        if (required) {
          unsatisfiedRequiredFields.push(value);
        }
      }
    });

    let productVariant = unsatisfiedRequiredFields.length === 0 ? options.sort().join(', ') : 'unsatisfied';
    const view = $('.productView');

    if (productVariant) {
      productVariant = productVariant === 'unsatisfied' ? '' : productVariant;
      if (view.attr('data-event-type')) {
        view.attr('data-product-variant', productVariant);
      } else {
        const productName = view.find('.productView-title')[0].innerText.replace(/"/g, '\\$&');
        const card = $(`[data-name="${productName}"]`);
        card.attr('data-product-variant', productVariant);
      }
    }
  }

  /**
   * Checks if the current window is being run inside an iframe
   * @returns {boolean}
   */
  isRunningInIframe() {
    try {
      return window.self !== window.top;
    } catch (e) {
      return true;
    }
  }

  /**
   *
   * Handle product options changes
   *
   */
  productOptionsChanged(event) {
    const $changedOption = $(event.target);
    const $form = $changedOption.parents('form');
    const productId = $('[name="product_id"]', $form).val();

    // Do not trigger an ajax request if it's a file or if the browser doesn't support FormData
    if ($changedOption.attr('type') === 'file' || window.FormData === undefined) {
      return;
    }

    utils.api.productAttributes.optionChange(productId, $form.serialize(), 'products/bulk-discount-rates', (err, response) => {
      const productAttributesData = response.data || {};
      const productAttributesContent = response.content || {};
      this.updateProductAttributes(productAttributesData);
      this.updateView(productAttributesData, productAttributesContent);
      bannerUtils.dispatchProductBannerEvent(productAttributesData);
    });
  }

  /**
   * if this setting is enabled in Page Builder
   * show name for swatch option
   */
  showSwatchNameOnOption($swatch) {
    const swatchName = $swatch.attr('aria-label');

    // $('[data-product-attribute="swatch"] [data-option-value]').text(swatchName);
    this.$swatchOptionMessage.text(`${this.swatchOptionMessageInitText} ${swatchName}`);
    this.setLiveRegionAttributes(this.$swatchOptionMessage, 'status', 'assertive');
  }

  setLiveRegionAttributes($element, roleType, ariaLiveStatus) {
    $element.attr({
      role: roleType,
      'aria-live': ariaLiveStatus,
    });
  }

  showProductImage(image) {
    if (isPlainObject(image)) {
      const zoomImageUrl = utils.tools.imageSrcset.getSrcset(
        image.data,
        { '1x': this.context.zoomSize },
        /*
            Should match zoom size used for data-zoom-image in
            components/products/product-view.html

            Note that this will only be used as a fallback image for browsers that do not support srcset

            Also note that getSrcset returns a simple src string when exactly one size is provided
        */
      );

      const mainImageUrl = utils.tools.imageSrcset.getSrcset(
        image.data,
        { '1x': this.context.productSize },
        /*
            Should match fallback image size used for the main product image in
            components/products/product-view.html

            Note that this will only be used as a fallback image for browsers that do not support srcset

            Also note that getSrcset returns a simple src string when exactly one size is provided
        */
      );

      const mainImageSrcset = utils.tools.imageSrcset.getSrcset(image.data);

      this.imageGallery.setAlternateImage({
        mainImageUrl,
        zoomImageUrl,
        mainImageSrcset,
      });
    } else {
      this.imageGallery.restoreImage();
    }
  }

  /**
   *
   * Handle action when the shopper clicks on + / - for quantity
   *
   */
  listenQuantityChange() {
    this.$scope.on('click', '[data-quantity-change] button', event => {
      event.preventDefault();
      const $target = $(event.currentTarget);
      const viewModel = this.getViewModel(this.$scope);
      const $input = viewModel.quantity.$input;
      const quantityMin = parseInt($input.data('quantityMin'), 10);
      const quantityMax = parseInt($input.data('quantityMax'), 10);

      let qty = parseInt($input.val(), 10);

      // If action is incrementing
      if ($target.data('action') === 'inc') {
        // If quantity max option is set
        if (quantityMax > 0) {
          // Check quantity does not exceed max
          if ((qty + 1) <= quantityMax) {
            qty++;
          }
        } else {
          qty++;
        }
      } else if (qty > 1) {
        // If quantity min option is set
        if (quantityMin > 0) {
          // Check quantity does not fall below min
          if ((qty - 1) >= quantityMin) {
            qty--;
          }
        } else {
          qty--;
        }
      }

      // update hidden input
      viewModel.quantity.$input.val(qty);
      // update text
      viewModel.quantity.$text.text(qty);
    });

    // Prevent triggering quantity change when pressing enter
    this.$scope.on('keypress', '.form-input--incrementTotal', event => {
      // If the browser supports event.which, then use event.which, otherwise use event.keyCode
      const x = event.which || event.keyCode;
      if (x === 13) {
        // Prevent default
        event.preventDefault();
      }
    });
  }

  /**
   * Get cart contents
   *
   * @param {String} cartItemId
   * @param {Function} onComplete
   */
  getCartContent(cartItemId, onComplete) {
    const options = {
      template: 'cart/preview',
      params: {
        suggest: cartItemId,
      },
      config: {
        cart: {
          suggestions: {
            limit: 4,
          },
        },
      },
    };

    utils.api.cart.getContent(options, onComplete);
  }

  /**
   * Redirect to url
   *
   * @param {String} url
   */
  redirectTo(url) {
    if (this.isRunningInIframe() && !window.iframeSdk) {
      window.top.location = url;
    } else {
      window.location = url;
    }
  }

  customCounter() {
    let allQuantsTotal;
    fetch('/api/storefront/cart', { credentials: 'include' })
      .then((res) => { return res.json(); })
      .then((cart) => {
        let PquantArr = [];
        let physicalItems = cart[0].lineItems.physicalItems;
        let specialSkus = ['LP-PLATINUM', 'LP-SILVER', 'LP-BRONZE', 'LP-COPPER', 'ETAILER', 'LP-DIAMOND'];
        let PskuArr = [];
        physicalItems.forEach(physical => {
          PskuArr.push(physical.sku);
          PquantArr.push(physical.quantity)
        });
        let alreadyInCart = specialSkus.filter(sku => PskuArr.includes(sku));
        allQuantsTotal = PquantArr.reduce((a, b) => a + b, 0);
        let cartQuantity = document.querySelector('.cart-quantity');
        cartQuantity.classList.add('countPill--positive');
        if (alreadyInCart.length > 0) {
          cartQuantity.innerHTML = allQuantsTotal - alreadyInCart.length;
        } else {
          cartQuantity.innerHTML = allQuantsTotal;
        }

        let countPill = document.querySelector('.countPill');
        let countPillPositive = document.querySelector('.countPill--positive');
        if (parseInt(countPillPositive.textContent) > 99) {
          countPill.classList.add('countPill--large');
        } else {
          countPill.classList.remove('countPill--large');
        }
        // console.log(parseInt(countPillPositive.textContent))

      });
  }

  /**
   * Hide or mark as unavailable out of stock attributes if enabled
   * @param  {Object} data Product attribute data
   */
  updateProductAttributes(data) {
    super.updateProductAttributes(data);
    this.showProductImage(data.image);
  }

}
