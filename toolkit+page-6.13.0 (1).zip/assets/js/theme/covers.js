import PageManager from "./page-manager";
import swal from "./global/sweet-alert";

export default class covers extends PageManager {
  constructor(context) {
    super(context);
  }

  onReady() {
    this.holeShapes();
    this.holePositions();
    this.infoIcons();
    this.chaseQuoteInfo();
  }

  fieldsAreGood() {
    swal.fire({
      "icon": "success",
      "html": "Fields look good!"
    });
    document.querySelector('#customButton').classList.remove('is-hidden');
  }

  chaseQuoteInfo() {
    let materialSelect = document.querySelector('[data-labelname="material"] select');
    let material;
    let colorSelect = document.querySelector('[data-labelname="powder-coat"] select');
    colorSelect.selectedIndex = 1;
    let color = "No Powder Coat";
    let buildToSelect = document.querySelector('[data-labelname="build-to"] select');
    let buildTo;
    let length1Input = document.querySelector('[data-labelname="length-1-cover"] input');
    let getLength1Whole;
    let length1Whole;
    let length1Select = document.querySelector('[data-labelname="length-1-cover"] select');
    let getLength1;
    let length1 = 0;
    let length2Input = document.querySelector('[data-labelname="length-2-cover"] input');
    let getLength2Whole;
    let length2Whole;
    let length2Select = document.querySelector('[data-labelname="length-2-cover"] select');
    let getLength2;
    let length2 = 0;
    let length3Input = document.querySelector('[data-labelname="length-3-cover"] input');
    let getLength3Whole;
    let length3Whole;
    let length3Select = document.querySelector('[data-labelname="length-3-cover"] select');
    let getLength3;
    let length3 = 0;
    let length4Input = document.querySelector('[data-labelname="length-4-cover"] input');
    let getLength4Whole;
    let length4Whole;
    let length4Select = document.querySelector('[data-labelname="length-4-cover"] select');
    let getLength4;
    let length4 = 0;
    let crossbreakSelect = document.querySelector('[data-labelname="crossbreak"] select');
    let crossbreak;
    let sideSkirtHeightInput = document.querySelector('[data-labelname="side-skirt-height"] input');
    let getSideSkirtHeight;
    let sideSkirtHeight;
    let itemNotesInput = document.querySelector('[data-labelname="item-notes"] textarea');
    let itemNotes;
    let dripEdgeSelect = document.querySelector('[data-labelname="drip-edge"] select');
    let dripEdge;
    let cratedSelect = document.querySelector('[data-labelname="crated"] select');
    let crated;
    let numberOfHolesSelect = document.querySelector('[data-labelname="number-of-holes"] select');
    let getNumberOfHoles;
    let numberOfHoles;

    let holes = [];
    let holeOne = {};
    let holeTwo = {};
    let holeThree = {};
    let holeFour = {};
    let holeOneShapeSelect = document.querySelector('#custom-hole-1 [data-labelname="shape"] select');
    let holeOneShape = "";
    let holeOneCenterSelect = document.querySelector('#custom-hole-1 [data-labelname="center"] select');
    let holeOneCenter = "";
    let holeOneDiameterInput = document.querySelector('#custom-hole-1 [data-labelname="diameter"] input');
    let getHoleOneDiameter;
    let holeOneDiameter = null;
    let holeOneMinorInput = document.querySelector('#custom-hole-1 [data-labelname="minor-dimension"] input');
    let getHoleOneMinor;
    let holeOneMinor = null;
    let holeOneMajorInput = document.querySelector('#custom-hole-1 [data-labelname="major-dimension"] input');
    let getHoleOneMajor;
    let holeOneMajor = null;
    let holeOneA1Input = document.querySelector('#custom-hole-1 [data-labelname="a1"] input');
    let getHoleOneA1;
    let holeOneA1 = null;
    let holeOneA2Input = document.querySelector('#custom-hole-1 [data-labelname="a2"] input');
    let getHoleOneA2;
    let holeOneA2 = null;
    let holeOneA3Input = document.querySelector('#custom-hole-1 [data-labelname="a3"] input');
    let getHoleOneA3;
    let holeOneA3 = null;
    let holeOneA4Input = document.querySelector('#custom-hole-1 [data-labelname="a4"] input');
    let getHoleOneA4;
    let holeOneA4 = null;
    let holeOneFlexCollarSelect = document.querySelector('#custom-hole-1 [data-labelname="flex-collar"] select');
    let holeOneFlexCollar = "";
    let holeOneCollarHeightInput = document.querySelector('#custom-hole-1 [data-labelname="collar-height"] input');
    let getHoleOneCollarHeight;
    let holeOneCollarHeight = null;
    let holeOneStormCollarSelect = document.querySelector('#custom-hole-1 [data-labelname="storm-collar"] select');
    let holeOneStormCollar = "";

    let holeTwoShapeSelect = document.querySelector('#custom-hole-2 [data-labelname="shape"] select');
    let holeTwoShape = "";
    let holeTwoDiameterInput = document.querySelector('#custom-hole-2 [data-labelname="diameter"] input');
    let getHoleTwoDiameter;
    let holeTwoDiameter = null;
    let holeTwoMinorInput = document.querySelector('#custom-hole-2 [data-labelname="minor-dimension"] input');
    let getHoleTwoMinor;
    let holeTwoMinor = null;
    let holeTwoMajorInput = document.querySelector('#custom-hole-2 [data-labelname="major-dimension"] input');
    let getHoleTwoMajor;
    let holeTwoMajor = null;
    let holeTwoB1Input = document.querySelector('#custom-hole-2 [data-labelname="b1"] input');
    let getHoleTwoB1;
    let holeTwoB1 = null;
    let holeTwoB2Input = document.querySelector('#custom-hole-2 [data-labelname="b2"] input');
    let getHoleTwoB2;
    let holeTwoB2 = null;
    let holeTwoB3Input = document.querySelector('#custom-hole-2 [data-labelname="b3"] input');
    let getHoleTwoB3;
    let holeTwoB3 = null;
    let holeTwoB4Input = document.querySelector('#custom-hole-2 [data-labelname="b4"] input');
    let getHoleTwoB4;
    let holeTwoB4 = null;
    let holeTwoFlexCollarSelect = document.querySelector('#custom-hole-2 [data-labelname="flex-collar"] select');
    let holeTwoFlexCollar = "";
    let holeTwoCollarHeightInput = document.querySelector('#custom-hole-2 [data-labelname="collar-height"] input');
    let getHoleTwoCollarHeight;
    let holeTwoCollarHeight = null;
    let holeTwoStormCollarSelect = document.querySelector('#custom-hole-2 [data-labelname="storm-collar"] select');
    let holeTwoStormCollar = "";

    let holeThreeShapeSelect = document.querySelector('#custom-hole-3 [data-labelname="shape"] select');
    let holeThreeShape = "";
    let holeThreeDiameterInput = document.querySelector('#custom-hole-3 [data-labelname="diameter"] input');
    let getHoleThreeDiameter;
    let holeThreeDiameter = null;
    let holeThreeMinorInput = document.querySelector('#custom-hole-3 [data-labelname="minor-dimension"] input');
    let getHoleThreeMinor;
    let holeThreeMinor = null;
    let holeThreeMajorInput = document.querySelector('#custom-hole-3 [data-labelname="major-dimension"] input');
    let getHoleThreeMajor;
    let holeThreeMajor = null;
    let holeThreeC1Input = document.querySelector('#custom-hole-3 [data-labelname="c1"] input');
    let getHoleThreeC1;
    let holeThreeC1 = null;
    let holeThreeC2Input = document.querySelector('#custom-hole-3 [data-labelname="c2"] input');
    let getHoleThreeC2;
    let holeThreeC2 = null;
    let holeThreeC3Input = document.querySelector('#custom-hole-3 [data-labelname="c3"] input');
    let getHoleThreeC3;
    let holeThreeC3 = null;
    let holeThreeC4Input = document.querySelector('#custom-hole-3 [data-labelname="c4"] input');
    let getHoleThreeC4;
    let holeThreeC4 = null;
    let holeThreeFlexCollarSelect = document.querySelector('#custom-hole-3 [data-labelname="flex-collar"] select');
    let holeThreeFlexCollar = "";
    let holeThreeCollarHeightInput = document.querySelector('#custom-hole-3 [data-labelname="collar-height"] input');
    let getHoleThreeCollarHeight;
    let holeThreeCollarHeight = null;
    let holeThreeStormCollarSelect = document.querySelector('#custom-hole-3 [data-labelname="storm-collar"] select');
    let holeThreeStormCollar = "";

    let holeFourShapeSelect = document.querySelector('#custom-hole-4 [data-labelname="shape"] select');
    let holeFourShape = "";
    let holeFourDiameterInput = document.querySelector('#custom-hole-4 [data-labelname="diameter"] input');
    let getHoleFourDiameter;
    let holeFourDiameter = null;
    let holeFourMinorInput = document.querySelector('#custom-hole-4 [data-labelname="minor-dimension"] input');
    let getHoleFourMinor;
    let holeFourMinor = null;
    let holeFourMajorInput = document.querySelector('#custom-hole-4 [data-labelname="major-dimension"] input');
    let getHoleFourMajor;
    let holeFourMajor = null;
    let holeFourD1Input = document.querySelector('#custom-hole-4 [data-labelname="d1"] input');
    let getHoleFourD1;
    let holeFourD1 = null;
    let holeFourD2Input = document.querySelector('#custom-hole-4 [data-labelname="d2"] input');
    let getHoleFourD2;
    let holeFourD2 = null;
    let holeFourD3Input = document.querySelector('#custom-hole-4 [data-labelname="d3"] input');
    let getHoleFourD3;
    let holeFourD3 = null;
    let holeFourD4Input = document.querySelector('#custom-hole-4 [data-labelname="d4"] input');
    let getHoleFourD4;
    let holeFourD4 = null;
    let holeFourFlexCollarSelect = document.querySelector('#custom-hole-4 [data-labelname="flex-collar"] select');
    let holeFourFlexCollar = "";
    let holeFourCollarHeightInput = document.querySelector('#custom-hole-4 [data-labelname="collar-height"] input');
    let getHoleFourCollarHeight;
    let holeFourCollarHeight = null;
    let holeFourStormCollarSelect = document.querySelector('#custom-hole-4 [data-labelname="storm-collar"] select');
    let holeFourStormCollar = "";

    let getMaterial = document.querySelector('[data-labelname="material"] select');
    let activeMaterial;

    let stepTwoMaxLength;
    let stepTwoMaxWidth;

    let allRadioFields = document.querySelectorAll('.custom-form-pv .form-radio input');
      let allInputFields = document.querySelectorAll('.custom-form-pv input');
      let allSelectFields = document.querySelectorAll('.custom-form-pv select');
      let allTextAreas = document.querySelectorAll('.custom-form-pv textarea');
      let requestQuotePrice = document.querySelector('.customPrice');
      let addToCartButton = document.querySelector('.customPrice__add-to-cart');

      allRadioFields.forEach(radioFields => {
        radioFields.addEventListener('click', () => {
          if (requestQuotePrice.classList.contains('active')) {
            requestQuotePrice.classList.remove('active');
            addToCartButton.classList.remove('active');
          }
        });
      });

      allInputFields.forEach(inputFields => {
        inputFields.addEventListener('change', () => {
          if (requestQuotePrice.classList.contains('active')) {
            requestQuotePrice.classList.remove('active');
            addToCartButton.classList.remove('active');
          }
        });
      });

      allSelectFields.forEach(selectFields => {
        selectFields.addEventListener('change', () => {
          if (requestQuotePrice.classList.contains('active')) {
            requestQuotePrice.classList.remove('active');
            addToCartButton.classList.remove('active');
          }
        });
      });

      allTextAreas.forEach(textAreas => {
        textAreas.addEventListener('change', () => {
          if (requestQuotePrice.classList.contains('active')) {
            requestQuotePrice.classList.remove('active');
            addToCartButton.classList.remove('active');
          }
        });
      });

    materialSelect.addEventListener('change', e => {
      material = e.target.options[e.target.selectedIndex].textContent;
    });

    colorSelect.addEventListener('change', e => {
      color = e.target.options[e.target.selectedIndex].textContent;
    });

    getMaterial.addEventListener('change', e => {
      activeMaterial = e.target.value;
      if (activeMaterial == 'stainless steel') {
        colorSelect.disabled = false;
      } else {
        colorSelect.disabled = true;
        color = 'no powder coat';
        colorSelect.selectedIndex = 1;
      }
    });

    buildToSelect.addEventListener('change', e => {
      buildTo = e.target.options[e.target.selectedIndex].textContent;
    });

    length1Input.addEventListener('change', e => {
      getLength1Whole = e.target.value;
      length1Whole = parseInt(getLength1Whole);
      let maxLength = Math.max((length1Whole + length1), (length2Whole + length2));
      let maxWidth = Math.max((length3Whole + length3), (length4Whole + length4));
      if ((maxLength + 6) * (maxWidth + 6) > 3100) {
        cratedSelect.selectedIndex = 2;
        crated = cratedSelect.value;
        cratedSelect.disabled = true;
      } else {
        cratedSelect.disabled = false;
      }
    });

    length1Select.addEventListener('change', e => {
      getLength1 = eval(e.target.options[e.target.selectedIndex].textContent).toFixed(4);
      length1 = parseFloat(getLength1);
      Number(length1);
      let maxLength = Math.max((length1Whole + length1), (length2Whole + length2));
      let maxWidth = Math.max((length3Whole + length3), (length4Whole + length4));
      if ((maxLength + 6) * (maxWidth + 6) > 3100) {
        cratedSelect.selectedIndex = 2;
        crated = cratedSelect.value;
        cratedSelect.disabled = true;
      } else {
        cratedSelect.disabled = false;
      }
    });

    length2Input.addEventListener('change', e => {
      getLength2Whole = e.target.value;
      length2Whole = parseInt(getLength2Whole);
      let maxLength = Math.max((length1Whole + length1), (length2Whole + length2));
      let maxWidth = Math.max((length3Whole + length3), (length4Whole + length4));
      if ((maxLength + 6) * (maxWidth + 6) > 3100) {
        cratedSelect.selectedIndex = 2;
        crated = cratedSelect.value;
        cratedSelect.disabled = true;
      } else {
        cratedSelect.disabled = false;
      }
      if ((length2 + length2Whole) > (length1 +length1Whole)) {
        swal.fire({
          title: 'Please start with the longest length and go clockwise'
        });
        length3Input.disabled = true;
        length3Select.disabled = true;
      } else {
        length3Input.disabled = false;
        length3Select.disabled = false;
      }
    });

    length2Select.addEventListener('change', e => {
      getLength2 = eval(e.target.options[e.target.selectedIndex].textContent).toFixed(4);
      length2 = parseFloat(getLength2);
      Number(length2);
      let maxLength = Math.max((length1Whole + length1), (length2Whole + length2));
      let maxWidth = Math.max((length3Whole + length3), (length4Whole + length4));
      if ((maxLength + 6) * (maxWidth + 6) > 3100) {
        cratedSelect.selectedIndex = 2;
        crated = cratedSelect.value;
        cratedSelect.disabled = true;
      } else {
        cratedSelect.disabled = false;
      }

      if ((length2 + length2Whole) > (length1 +length1Whole)) {
        swal.fire({
          title: 'Please start with the longest length and go clockwise'
        });
        length3Input.disabled = true;
        length3Select.disabled = true;
      } else {
        length3Input.disabled = false;
        length3Select.disabled = false;
      }
    });

    length3Input.addEventListener('change', e => {
      getLength3Whole = e.target.value;
      length3Whole = parseInt(getLength3Whole);
      let maxLength = Math.max((length1Whole + length1), (length2Whole + length2));
      let maxWidth = Math.max((length3Whole + length3), (length4Whole + length4));
      if ((maxLength + 6) * (maxWidth + 6) > 3100) {
        cratedSelect.selectedIndex = 2;
        crated = cratedSelect.value;
        cratedSelect.disabled = true;
      } else {
        cratedSelect.disabled = false;
      }

      if ((length3 + length3Whole) > (length1 +length1Whole)) {
        swal.fire({
          title: 'Please start with the longest length and go clockwise'
        });
        length4Input.disabled = true;
        length4Select.disabled = true;
      } else {
        length4Input.disabled = false;
        length4Select.disabled = false;
      }
    });

    length3Select.addEventListener('change', e => {
      getLength3 = eval(e.target.options[e.target.selectedIndex].textContent).toFixed(4);
      length3 = parseFloat(getLength3);
      Number(length3);
      let maxLength = Math.max((length1Whole + length1), (length2Whole + length2));
      let maxWidth = Math.max((length3Whole + length3), (length4Whole + length4));
      if ((maxLength + 6) * (maxWidth + 6) > 3100) {
        cratedSelect.selectedIndex = 2;
        crated = cratedSelect.value;
        cratedSelect.disabled = true;
      } else {
        cratedSelect.disabled = false;
      }

      if ((length3 + length3Whole) > (length1 +length1Whole)) {
        swal.fire({
          title: 'Please start with the longest length and go clockwise'
        });
        length4Input.disabled = true;
        length4Select.disabled = true;
      } else {
        length4Input.disabled = false;
        length4Select.disabled = false;
      }
    });

    length4Input.addEventListener('change', e => {
      getLength4Whole = e.target.value;
      length4Whole = parseInt(getLength4Whole);
      let maxLength = Math.max((length1Whole + length1), (length2Whole + length2));
      let maxWidth = Math.max((length3Whole + length3), (length4Whole + length4));
      if ((maxLength + 6) * (maxWidth + 6) > 3100) {
        cratedSelect.selectedIndex = 2;
        crated = cratedSelect.value;
        cratedSelect.disabled = true;
      } else {
        cratedSelect.disabled = false;
      }

      if ((length4 + length4Whole) > (length1 +length1Whole)) {
        swal.fire({
          title: 'Please start with the longest length and go clockwise'
        });
        document.querySelector('#customButton').disabled = true
      } else {
        document.querySelector('#customButton').disabled = false
      }
    });

    length4Select.addEventListener('change', e => {
      getLength4 = eval(e.target.options[e.target.selectedIndex].textContent).toFixed(4);
      length4 = parseFloat(getLength4);
      Number(length4);
      let maxLength = Math.max((length1Whole + length1), (length2Whole + length2));
      let maxWidth = Math.max((length3Whole + length3), (length4Whole + length4));
      if ((maxLength + 6) * (maxWidth + 6) > 3100) {
        cratedSelect.selectedIndex = 2;
        crated = cratedSelect.value;
        cratedSelect.disabled = true;
      } else {
        cratedSelect.disabled = false;
      }

      if ((length4 + length4Whole) > (length1 +length1Whole)) {
        swal.fire({
          title: 'Please start with the longest length and go clockwise'
        });
        document.querySelector('#customButton').disabled = true
      } else {
        document.querySelector('#customButton').disabled = false
      }
    });

    crossbreakSelect.addEventListener('change', e => {
      crossbreak = e.target.options[e.target.selectedIndex].value;
    });

    sideSkirtHeightInput.addEventListener('change', e => {
      getSideSkirtHeight = parseFloat(e.target.value);
      sideSkirtHeight = Number(getSideSkirtHeight);
    });

    itemNotesInput.addEventListener('change', e => {
      itemNotes = e.target.value;
    });

    dripEdgeSelect.addEventListener('change', e => {
      dripEdge = e.target.options[e.target.selectedIndex].textContent;
    });

    cratedSelect.addEventListener('change', e => {
      crated = e.target.options[e.target.selectedIndex].textContent;
    });

    numberOfHolesSelect.addEventListener('change', e => {
      getNumberOfHoles = e.target.options[e.target.selectedIndex].textContent;
      numberOfHoles = parseFloat(getNumberOfHoles);
      Number(numberOfHoles);
    });

    // start hole 1
    holeOneShapeSelect.addEventListener('change', e => {
      holeOneShape = e.target.options[e.target.selectedIndex].textContent;
    });

    holeOneCenterSelect.addEventListener('change', e => {
      holeOneCenter = e.target.options[e.target.selectedIndex].textContent;
    });

    holeOneDiameterInput.addEventListener('change', e => {
      getHoleOneDiameter = e.target.value;
      holeOneDiameter = parseFloat(getHoleOneDiameter);
      Number(holeOneDiameter);
    });

    holeOneA1Input.addEventListener('change', e => {
      getHoleOneA1 = e.target.value;
      holeOneA1 = parseFloat(getHoleOneA1);
      Number(holeOneA1);
    });

    holeOneA2Input.addEventListener('change', e => {
      getHoleOneA2 = e.target.value;
      holeOneA2 = parseFloat(getHoleOneA2);
      Number(holeOneA2);
    });

    holeOneA3Input.addEventListener('change', e => {
      getHoleOneA3 = e.target.value;
      holeOneA3 = parseFloat(getHoleOneA3);
      Number(holeOneA3);
    });

    holeOneA4Input.addEventListener('change', e => {
      getHoleOneA4 = e.target.value;
      holeOneA4 = parseFloat(getHoleOneA4);
      Number(holeOneA4);
    });

    holeOneMinorInput.addEventListener('change', e => {
      getHoleOneMinor = e.target.value;
      holeOneMinor = parseFloat(getHoleOneMinor);
      Number(holeOneMinor);
    });

    holeOneMajorInput.addEventListener('change', e => {
      getHoleOneMajor = e.target.value;
      holeOneMajor = parseFloat(getHoleOneMajor);
      Number(holeOneMajor);
    });

    holeOneFlexCollarSelect.addEventListener('change', e => {
      holeOneFlexCollar = e.target.options[e.target.selectedIndex].textContent;
    });

    holeOneCollarHeightInput.addEventListener('change', e => {
      getHoleOneCollarHeight = e.target.value;
      holeOneCollarHeight = parseFloat(getHoleOneCollarHeight);
      Number(holeOneCollarHeight);
    });

    holeOneStormCollarSelect.addEventListener('change', e => {
      holeOneStormCollar = e.target.options[e.target.selectedIndex].textContent;
    });


    // start hole 2 
    holeTwoShapeSelect.addEventListener('change', e => {
      holeTwoShape = e.target.options[e.target.selectedIndex].textContent;
    });

    holeTwoDiameterInput.addEventListener('change', e => {
      getHoleTwoDiameter = e.target.value;
      holeTwoDiameter = parseFloat(getHoleTwoDiameter);
      Number(holeTwoDiameter);
    });

    holeTwoB1Input.addEventListener('change', e => {
      getHoleTwoB1 = e.target.value;
      holeTwoB1 = parseFloat(getHoleTwoB1);
      Number(holeTwoB1);
    });

    holeTwoB2Input.addEventListener('change', e => {
      getHoleTwoB2 = e.target.value;
      holeTwoB2 = parseFloat(getHoleTwoB2);
      Number(holeTwoB2);
    });

    holeTwoB3Input.addEventListener('change', e => {
      getHoleTwoB3 = e.target.value;
      holeTwoB3 = parseFloat(getHoleTwoB3);
      Number(holeTwoB3);
    });

    holeTwoB4Input.addEventListener('change', e => {
      getHoleTwoB4 = e.target.value;
      holeTwoB4 = parseFloat(getHoleTwoB4);
      Number(holeTwoB4);
    });

    holeTwoMinorInput.addEventListener('change', e => {
      getHoleTwoMinor = e.target.value;
      holeTwoMinor = parseFloat(getHoleTwoMinor);
      Number(holeTwoMinor);
    });

    holeTwoMajorInput.addEventListener('change', e => {
      getHoleTwoMajor = e.target.value;
      holeTwoMajor = parseFloat(getHoleTwoMajor);
      Number(holeTwoMajor);
    });

    holeTwoFlexCollarSelect.addEventListener('change', e => {
      holeTwoFlexCollar = e.target.options[e.target.selectedIndex].textContent;
    });

    holeTwoCollarHeightInput.addEventListener('change', e => {
      getHoleTwoCollarHeight = e.target.value;
      holeTwoCollarHeight = parseFloat(getHoleTwoCollarHeight);
      Number(holeTwoCollarHeight);
    });

    holeTwoStormCollarSelect.addEventListener('change', e => {
      holeTwoStormCollar = e.target.options[e.target.selectedIndex].textContent;
    });

    // start hole 3
    holeThreeShapeSelect.addEventListener('change', e => {
      holeThreeShape = e.target.options[e.target.selectedIndex].textContent;
    });

    holeThreeDiameterInput.addEventListener('change', e => {
      getHoleThreeDiameter = e.target.value;
      holeThreeDiameter = parseFloat(getHoleThreeDiameter);
      Number(holeThreeDiameter);
    });

    holeThreeC1Input.addEventListener('change', e => {
      getHoleThreeC1 = e.target.value;
      holeThreeC1 = parseFloat(getHoleThreeC1);
      Number(holeThreeC1);
    });

    holeThreeC2Input.addEventListener('change', e => {
      getHoleThreeC2 = e.target.value;
      holeThreeC2 = parseFloat(getHoleThreeC2);
      Number(holeThreeC2);
    });

    holeThreeC3Input.addEventListener('change', e => {
      getHoleThreeC3 = e.target.value;
      holeThreeC3 = parseFloat(getHoleThreeC3);
      Number(holeThreeC3);
    });

    holeThreeC4Input.addEventListener('change', e => {
      getHoleThreeC4 = e.target.value;
      holeThreeC4 = parseFloat(getHoleThreeC4);
      Number(holeThreeC4);
    });

    holeThreeMinorInput.addEventListener('change', e => {
      getHoleThreeMinor = e.target.value;
      holeThreeMinor = parseFloat(getHoleThreeMinor);
      Number(holeThreeMinor);
    });

    holeThreeMajorInput.addEventListener('change', e => {
      getHoleThreeMajor = e.target.value;
      holeThreeMajor = parseFloat(getHoleThreeMajor);
      Number(holeThreeMajor);
    });

    holeThreeFlexCollarSelect.addEventListener('change', e => {
      holeThreeFlexCollar = e.target.options[e.target.selectedIndex].textContent;
    });

    holeThreeCollarHeightInput.addEventListener('change', e => {
      getHoleThreeCollarHeight = e.target.value;
      holeThreeCollarHeight = parseFloat(getHoleThreeCollarHeight);
      Number(holeThreeCollarHeight);
    });

    holeThreeStormCollarSelect.addEventListener('change', e => {
      holeThreeStormCollar = e.target.options[e.target.selectedIndex].textContent;
    });

    // start hole 4
    holeFourShapeSelect.addEventListener('change', e => {
      holeFourShape = e.target.options[e.target.selectedIndex].textContent;
    });

    holeFourDiameterInput.addEventListener('change', e => {
      getHoleFourDiameter = e.target.value;
      holeFourDiameter = parseFloat(getHoleFourDiameter);
      Number(holeFourDiameter);
    });

    holeFourD1Input.addEventListener('change', e => {
      getHoleFourD1 = e.target.value;
      holeFourD1 = parseFloat(getHoleFourD1);
      Number(holeFourD1);
    });

    holeFourD2Input.addEventListener('change', e => {
      getHoleFourD2 = e.target.value;
      holeFourD2 = parseFloat(getHoleFourD2);
      Number(holeFourD2);
    });

    holeFourD3Input.addEventListener('change', e => {
      getHoleFourD3 = e.target.value;
      holeFourD3 = parseFloat(getHoleFourD3);
      Number(holeFourD3);
    });

    holeFourD4Input.addEventListener('change', e => {
      getHoleFourD4 = e.target.value;
      holeFourD4 = parseFloat(getHoleFourD4);
      Number(holeFourD4);
    });

    holeFourMinorInput.addEventListener('change', e => {
      getHoleFourMinor = e.target.value;
      holeFourMinor = parseFloat(getHoleFourMinor);
      Number(holeFourMinor);
    });

    holeFourMajorInput.addEventListener('change', e => {
      getHoleFourMajor = e.target.value;
      holeFourMajor = parseFloat(getHoleFourMajor);
      Number(holeFourMajor);
    });

    holeFourFlexCollarSelect.addEventListener('change', e => {
      holeFourFlexCollar = e.target.options[e.target.selectedIndex].textContent;
    });

    holeFourCollarHeightInput.addEventListener('change', e => {
      getHoleFourCollarHeight = e.target.value;
      holeFourCollarHeight = parseFloat(getHoleFourCollarHeight);
      Number(holeFourCollarHeight);
    });

    holeFourStormCollarSelect.addEventListener('change', e => {
      holeFourStormCollar = e.target.options[e.target.selectedIndex].textContent;
    });

    let loyaltyLevel = "";
    let shippingTerms = "";
    let loyaltyTierId = this.context.loyalty_tier_id;
    let shippingTermsId = this.context.shipping_terms_id;
    fetch("/graphql", {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.context.storefront_api}`,
      },
      body: JSON.stringify({
        query: `
                  query {
                    loyaltyProgram: customer {
                      attributes {
                        attribute (entityId: ${loyaltyTierId}) {
                          value
                        }
                      }
                    }
                    shippingTerms: customer {
                      attributes {
                        attribute (entityId: ${shippingTermsId}) {
                          value
                        }
                      }
                    }
                  }`,
      }),
    })
      .then((response) => response.json())
      .then((res) => {
        if (res.data.loyaltyProgram.attributes.attribute.value != null) {
          loyaltyLevel = res.data.loyaltyProgram.attributes.attribute.value;
          shippingTerms = res.data.shippingTerms.attributes.attribute.value;
        } else {
          $.ajax({
            type: "GET",
            url: "/account.php?action=account_details",
            dataType: "html",
            success: response => {
              loyaltyLevel = $(response).find(`#FormField_${this.context.account_details_loyaltyTier_ID} option:selected`).text();
              shippingTerms = $(response).find(`#FormField_${this.context.account_details_shippingTerms_ID} option:selected`).text();
            }
          })
        }
      });

      numberOfHolesSelect.addEventListener('change', () => {
        document.querySelector('#customButton').classList.add('is-hidden');
      });

      document.querySelector('#validate-fields').addEventListener('click', () => {
        stepTwoMaxWidth = Math.max((length2Whole + length2), (length4Whole + length4));
        stepTwoMaxLength = Math.max((length1Whole + length1), (length3Whole + length3));

        if (numberOfHoles == 0) {
          this.fieldsAreGood();
        } else if (numberOfHoles == 1) {
          console.log('1 hole');
          // start hole 1
          if (holeOneShape == 'Round' && holeOneCenter == 'No') {
            if (holeOneA1 + holeOneDiameter + holeOneA3 != stepTwoMaxWidth) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
              });
            } else if (holeOneA2 + holeOneDiameter + holeOneA4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            } else {
              this.fieldsAreGood();
            }
          } else if (holeOneShape == 'Round' && holeOneCenter == 'Yes') {
            document.querySelector('#customButton').classList.remove('is-hidden');
          } else if (holeOneShape == 'Square' && holeOneCenter == 'No') {
            if (holeOneMajor != holeOneMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, major and minor dimensions are not equal."
              });
            } else if (holeOneA1 + holeOneMinor + holeOneA3 != stepTwoMaxWidth || holeOneA2 + holeOneMajor + holeOneA4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width).<br><br><strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            } else {
              this.fieldsAreGood();
            }
            } else if (holeOneShape == 'Square' && holeOneCenter == 'Yes') {
            if (holeOneMajor != holeOneMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, major and minor dimensions are not equal."
              });
            } else {
              this.fieldsAreGood();
            }
            } else if (holeOneShape == 'Parallel Oval' && holeOneCenter == 'No' || holeOneShape == 'Parallel Rectangle' && holeOneCenter == 'No') {
              if (holeOneA1 + holeOneMinor + holeOneA3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeOneA2 + holeOneMajor + holeOneA4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              } else {
                this.fieldsAreGood();                
              }
            } else if (holeOneShape == 'Parallel Oval' && holeOneCenter == 'Yes' || holeOneShape == 'Parallel Rectangle' && holeOneCenter == 'Yes') {
              document.querySelector('#customButton').classList.remove('is-hidden');                
            } else if (holeOneShape == 'Perpendicular Oval' && holeOneCenter == 'No' || holeOneShape == 'Perpendicular Rectangle' && holeOneCenter == 'No') {
              if (holeOneA1 + holeOneMajor + holeOneA3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeOneA2 + holeOneMinor + holeOneA4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              } else {
                this.fieldsAreGood();                
              }
            } else if (holeOneShape == 'Perpendicular Oval' && holeOneCenter == 'Yes' || holeOneShape == 'Perpendicular Rectangle' && holeOneCenter == 'Yes') {
              document.querySelector('#customButton').classList.remove('is-hidden');                
            }
            // end hole 1
        } else if (numberOfHoles == 2) {
          console.log('2 holes selected')
            
            // start hole 2
            if (holeTwoShape == 'Round') {
              if (holeTwoB1 + holeTwoDiameter + holeTwoB3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeTwoB2 + holeTwoDiameter + holeTwoB4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              } else {
                this.fieldsAreGood();
              }
            } else if (holeTwoShape == 'Square') {
              if (holeTwoMajor != holeTwoMinor) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, major and minor dimensions are not equal."
                });
              } else if (holeTwoB1 + holeTwoMinor + holeTwoB3 != stepTwoMaxWidth || holeTwoB2 + holeTwoMajor + holeTwoB4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width).<br><br><strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              } else {
                this.fieldsAreGood();
              }
              } else if (holeTwoShape == 'Parallel Oval' || holeTwoShape == 'Parallel Rectangle') {
                if (holeTwoB1 + holeTwoMinor + holeTwoB3 != stepTwoMaxWidth) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                  });
                } else if (holeTwoB2 + holeTwoMajor + holeTwoB4 != stepTwoMaxLength) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                  });
                } else {
                  this.fieldsAreGood();               
                }
              } else if (holeTwoShape == 'Perpendicular Oval' || holeTwoShape == 'Perpendicular Rectangle') {
                if (holeTwoB1 + holeTwoMajor + holeTwoB3 != stepTwoMaxWidth) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                  });
                } else if (holeTwoB2 + holeTwoMinor + holeTwoB4 != stepTwoMaxLength) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                  });
                } else {
                  this.fieldsAreGood();               
                }
              }
              // end hole 2

              // start hole 1
          if (holeOneShape == 'Round' && holeOneCenter == 'No') {
            if (holeOneA1 + holeOneDiameter + holeOneA3 != stepTwoMaxWidth) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
              });
            } else if (holeOneA2 + holeOneDiameter + holeOneA4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            }
          } else if (holeOneShape == 'Square' && holeOneCenter == 'No') {
            if (holeOneMajor != holeOneMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, major and minor dimensions are not equal."
              });
            } else if (holeOneA1 + holeOneMinor + holeOneA3 != stepTwoMaxWidth || holeOneA2 + holeOneMajor + holeOneA4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width).<br><br><strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            }
            } else if (holeOneShape == 'Square' && holeOneCenter == 'Yes') {
            if (holeOneMajor != holeOneMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, major and minor dimensions are not equal."
              });
            }
            } else if (holeOneShape == 'Parallel Oval' && holeOneCenter == 'No' || holeOneShape == 'Parallel Rectangle' && holeOneCenter == 'No') {
              if (holeOneA1 + holeOneMinor + holeOneA3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeOneA2 + holeOneMajor + holeOneA4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
            } else if (holeOneShape == 'Perpendicular Oval' && holeOneCenter == 'No' || holeOneShape == 'Perpendicular Rectangle' && holeOneCenter == 'No') {
              if (holeOneA1 + holeOneMajor + holeOneA3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeOneA2 + holeOneMinor + holeOneA4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
            }
            // end hole 1


        } else if (numberOfHoles == 3) {
          console.log('holes 3 are selected')
           // start hole 3
           if (holeThreeShape == 'Round') {
            if (holeThreeC1 + holeThreeDiameter + holeThreeC3 != stepTwoMaxWidth) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A1 & A3 (width)."
              });
            } else if (holeThreeC2 + holeThreeDiameter + holeThreeC4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            } else {
              this.fieldsAreGood();
            }
          } else if (holeThreeShape == 'Square') {
            if (holeThreeMajor != holeThreeMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 3</strong>, major and minor dimensions are not equal."
              });
            } else if (holeThreeC1 + holeThreeMinor + holeThreeC3 != stepTwoMaxWidth || holeThreeC2 + holeThreeMajor + holeThreeC4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A1 & A3 (width).<br><br><strong>For hole 3</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            } else {
              this.fieldsAreGood();
            }
            } else if (holeThreeShape == 'Parallel Oval' || holeThreeShape == 'Parallel Rectangle') {
              if (holeThreeC1 + holeThreeMinor + holeThreeC3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeThreeC2 + holeThreeMajor + holeThreeC4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              } else {
                this.fieldsAreGood();               
              }
            } else if (holeThreeShape == 'Perpendicular Oval' || holeThreeShape == 'Perpendicular Rectangle') {
              if (holeThreeC1 + holeThreeMajor + holeThreeC3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeThreeC2 + holeThreeMinor + holeThreeC4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              } else {
                this.fieldsAreGood();               
              }
            }
            // end hole 3

            // start hole 2
            if (holeTwoShape == 'Round') {
              if (holeTwoB1 + holeTwoDiameter + holeTwoB3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeTwoB2 + holeTwoDiameter + holeTwoB4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
            } else if (holeTwoShape == 'Square') {
              if (holeTwoMajor != holeTwoMinor) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, major and minor dimensions are not equal."
                });
              } else if (holeTwoB1 + holeTwoMinor + holeTwoB3 != stepTwoMaxWidth || holeTwoB2 + holeTwoMajor + holeTwoB4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width).<br><br><strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
              } else if (holeTwoShape == 'Parallel Oval' || holeTwoShape == 'Parallel Rectangle') {
                if (holeTwoB1 + holeTwoMinor + holeTwoB3 != stepTwoMaxWidth) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                  });
                } else if (holeTwoB2 + holeTwoMajor + holeTwoB4 != stepTwoMaxLength) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                  });
                }
              } else if (holeTwoShape == 'Perpendicular Oval' || holeTwoShape == 'Perpendicular Rectangle') {
                if (holeTwoB1 + holeTwoMajor + holeTwoB3 != stepTwoMaxWidth) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                  });
                } else if (holeTwoB2 + holeTwoMinor + holeTwoB4 != stepTwoMaxLength) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                  });
                }
              }
              // end hole 2

          // start hole 1
          if (holeOneShape == 'Round' && holeOneCenter == 'No') {
            if (holeOneA1 + holeOneDiameter + holeOneA3 != stepTwoMaxWidth) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
              });
            } else if (holeOneA2 + holeOneDiameter + holeOneA4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            }
          } else if (holeOneShape == 'Square' && holeOneCenter == 'No') {
            if (holeOneMajor != holeOneMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, major and minor dimensions are not equal."
              });
            } else if (holeOneA1 + holeOneMinor + holeOneA3 != stepTwoMaxWidth || holeOneA2 + holeOneMajor + holeOneA4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width).<br><br><strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            }
            } else if (holeOneShape == 'Square' && holeOneCenter == 'Yes') {
            if (holeOneMajor != holeOneMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, major and minor dimensions are not equal."
              });
            }
            } else if (holeOneShape == 'Parallel Oval' && holeOneCenter == 'No' || holeOneShape == 'Parallel Rectangle' && holeOneCenter == 'No') {
              if (holeOneA1 + holeOneMinor + holeOneA3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeOneA2 + holeOneMajor + holeOneA4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
            } else if (holeOneShape == 'Perpendicular Oval' && holeOneCenter == 'No' || holeOneShape == 'Perpendicular Rectangle' && holeOneCenter == 'No') {
              if (holeOneA1 + holeOneMajor + holeOneA3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeOneA2 + holeOneMinor + holeOneA4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
            }
            // end hole 1
            
        } else if (numberOfHoles == 4) {
          console.log('4 holes selected')

          // start hole 4
          if (holeFourShape == 'Round') {
            if (holeFourD1 + holeFourDiameter + holeFourD3 != stepTwoMaxWidth) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 4</strong>, Measurements do not add up. Please check A1 & A3 (width)."
              });
            } else if (holeFourD2 + holeFourDiameter + holeFourD4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 4</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            } else {
              this.fieldsAreGood();
            }
          } else if (holeFourShape == 'Square') {
            if (holeFourMajor != holeFourMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 4</strong>, major and minor dimensions are not equal."
              });
            } else if (holeFourD1 + holeFourMinor + holeFourD3 != stepTwoMaxWidth || holeFourD2 + holeFourMajor + holeFourD4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 4</strong>, Measurements do not add up. Please check A1 & A3 (width).<br><br><strong>For hole 4</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            } else {
              this.fieldsAreGood();
            }
            } else if (holeFourShape == 'Parallel Oval' || holeFourShape == 'Parallel Rectangle') {
              if (holeFourD1 + holeFourMinor + holeFourD3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 4</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeFourD2 + holeFourMajor + holeFourD4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 4</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              } else {
                this.fieldsAreGood();                
              }
            } else if (holeFourShape == 'Perpendicular Oval' || holeFourShape == 'Perpendicular Rectangle') {
              if (holeFourD1 + holeFourMajor + holeFourD3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 4</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeFourD2 + holeFourMinor + holeFourD4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 4</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              } else {
                this.fieldsAreGood();               
              }
            }
          // end hole 4

           // start hole 3
           if (holeThreeShape == 'Round') {
            if (holeThreeC1 + holeThreeDiameter + holeThreeC3 != stepTwoMaxWidth) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A1 & A3 (width)."
              });
            } else if (holeThreeC2 + holeThreeDiameter + holeThreeC4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            }
          } else if (holeThreeShape == 'Square') {
            if (holeThreeMajor != holeThreeMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 3</strong>, major and minor dimensions are not equal."
              });
            } else if (holeThreeC1 + holeThreeMinor + holeThreeC3 != stepTwoMaxWidth || holeThreeC2 + holeThreeMajor + holeThreeC4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A1 & A3 (width).<br><br><strong>For hole 3</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            }
            } else if (holeThreeShape == 'Parallel Oval' || holeThreeShape == 'Parallel Rectangle') {
              if (holeThreeC1 + holeThreeMinor + holeThreeC3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeThreeC2 + holeThreeMajor + holeThreeC4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
            } else if (holeThreeShape == 'Perpendicular Oval' || holeThreeShape == 'Perpendicular Rectangle') {
              if (holeThreeC1 + holeThreeMajor + holeThreeC3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeThreeC2 + holeThreeMinor + holeThreeC4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 3</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
            }
            // end hole 3

            // start hole 2
            if (holeTwoShape == 'Round') {
              if (holeTwoB1 + holeTwoDiameter + holeTwoB3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeTwoB2 + holeTwoDiameter + holeTwoB4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
            } else if (holeTwoShape == 'Square') {
              if (holeTwoMajor != holeTwoMinor) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, major and minor dimensions are not equal."
                });
              } else if (holeTwoB1 + holeTwoMinor + holeTwoB3 != stepTwoMaxWidth || holeTwoB2 + holeTwoMajor + holeTwoB4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width).<br><br><strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
              } else if (holeTwoShape == 'Parallel Oval' || holeTwoShape == 'Parallel Rectangle') {
                if (holeTwoB1 + holeTwoMinor + holeTwoB3 != stepTwoMaxWidth) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                  });
                } else if (holeTwoB2 + holeTwoMajor + holeTwoB4 != stepTwoMaxLength) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                  });
                }
              } else if (holeTwoShape == 'Perpendicular Oval' || holeTwoShape == 'Perpendicular Rectangle') {
                if (holeTwoB1 + holeTwoMajor + holeTwoB3 != stepTwoMaxWidth) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                  });
                } else if (holeTwoB2 + holeTwoMinor + holeTwoB4 != stepTwoMaxLength) {
                  swal.fire({
                    "icon": "error",
                    "html": "<strong>For hole 2</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                  });
                }
              }
              // end hole 2

          // start hole 1
          if (holeOneShape == 'Round' && holeOneCenter == 'No') {
            if (holeOneA1 + holeOneDiameter + holeOneA3 != stepTwoMaxWidth) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
              });
            } else if (holeOneA2 + holeOneDiameter + holeOneA4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            }
          } else if (holeOneShape == 'Square' && holeOneCenter == 'No') {
            if (holeOneMajor != holeOneMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, major and minor dimensions are not equal."
              });
            } else if (holeOneA1 + holeOneMinor + holeOneA3 != stepTwoMaxWidth || holeOneA2 + holeOneMajor + holeOneA4 != stepTwoMaxLength) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width).<br><br><strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
              });
            }
            } else if (holeOneShape == 'Square' && holeOneCenter == 'Yes') {
            if (holeOneMajor != holeOneMinor) {
              swal.fire({
                "icon": "error",
                "html": "<strong>For hole 1</strong>, major and minor dimensions are not equal."
              });
            }
            } else if (holeOneShape == 'Parallel Oval' && holeOneCenter == 'No' || holeOneShape == 'Parallel Rectangle' && holeOneCenter == 'No') {
              if (holeOneA1 + holeOneMinor + holeOneA3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeOneA2 + holeOneMajor + holeOneA4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
            } else if (holeOneShape == 'Perpendicular Oval' && holeOneCenter == 'No' || holeOneShape == 'Perpendicular Rectangle' && holeOneCenter == 'No') {
              if (holeOneA1 + holeOneMajor + holeOneA3 != stepTwoMaxWidth) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A1 & A3 (width)."
                });
              } else if (holeOneA2 + holeOneMinor + holeOneA4 != stepTwoMaxLength) {
                swal.fire({
                  "icon": "error",
                  "html": "<strong>For hole 1</strong>, Measurements do not add up. Please check A2 & A4 (length)."
                });
              }
            }
            // end hole 1

        }

      });

    document.querySelector('#customButton').addEventListener('click', () => {
      holeOne = {
        "shape": holeOneShape,
        "center": holeOneCenter,
        "a1": holeOneA1,
        "a2": holeOneA2,
        "a3": holeOneA3,
        "a4": holeOneA4,
        "diameter": holeOneDiameter,
        "minor_dimension": holeOneMinor,
        "major_diameter": holeOneMajor,
        "flex_colar": holeOneFlexCollar,
        "collar_height": holeOneCollarHeight,
        "storm_collar": holeOneStormCollar
      };

      holeTwo = {
        "shape": holeTwoShape,
        "center": "no",
        "a1": holeTwoB1,
        "a2": holeTwoB2,
        "a3": holeTwoB3,
        "a4": holeTwoB4,
        "diameter": holeTwoDiameter,
        "minor_dimension": holeTwoMinor,
        "major_diameter": holeTwoMajor,
        "flex_colar": holeTwoFlexCollar,
        "collar_height": holeTwoCollarHeight,
        "storm_collar": holeTwoStormCollar
      };

      holeThree = {
        "shape": holeThreeShape,
        "center": "no",
        "a1": holeThreeC1,
        "a2": holeThreeC2,
        "a3": holeThreeC3,
        "a4": holeThreeC4,
        "diameter": holeThreeDiameter,
        "minor_dimension": holeThreeMinor,
        "major_diameter": holeThreeMajor,
        "flex_colar": holeThreeFlexCollar,
        "collar_height": holeThreeCollarHeight,
        "storm_collar": holeThreeStormCollar
      };

      holeFour = {
        "shape": holeFourShape,
        "center": "no",
        "a1": holeFourD1,
        "a2": holeFourD2,
        "a3": holeFourD3,
        "a4": holeFourD4,
        "diameter": holeFourDiameter,
        "minor_dimension": holeFourMinor,
        "major_diameter": holeFourMajor,
        "flex_colar": holeFourFlexCollar,
        "collar_height": holeFourCollarHeight,
        "storm_collar": holeFourStormCollar
      };
      if (holes.length == 0) {
        if (numberOfHoles == 1) {
          holes.push(holeOne);
        } else if (numberOfHoles == 2) {
          holes.push(holeOne, holeTwo)
        } else if (numberOfHoles == 3) {
          holes.push(holeOne, holeTwo, holeThree)
        } else if (numberOfHoles == 4) {
          holes.push(holeOne, holeTwo, holeThree, holeFour);
        }
      } else {
        holes = [];
        if (numberOfHoles == 1) {
          holes.push(holeOne);
        } else if (numberOfHoles == 2) {
          holes.push(holeOne, holeTwo)
        } else if (numberOfHoles == 3) {
          holes.push(holeOne, holeTwo, holeThree)
        } else if (numberOfHoles == 4) {
          holes.push(holeOne, holeTwo, holeThree, holeFour);
        }
      }

        if ((length1Whole + length1) > 100 || (length2Whole + length2) > 52 || (length3Whole + length3) > 100 || (length4Whole + length4) > 52) {
        swal.fire({
          icon: 'error', 
          html: '<strong>Error at Step 2: Overall Size</strong><br><br>A & C have a threshold of 100<br>B & D have a threshold of 52. <br><br> Please adjust and try again.'
        });
        } else if (buildToSelect.selectedIndex == 0) {
        swal.fire({
          icon: 'error',
          html: '<strong>Error at Step 2: Overall Size</strong><br><br>Build To is required.'
        })
        } else if (document.querySelector('.agreeance__wrap input').checked == false) {
        swal.fire({
          icon: 'error',
          html: '<strong>The checkbox must be selected in order to continue.'          
        });
        } else {
        this.chaseQuote(material, color, buildTo, length1, length2, length3, length4, crossbreak, sideSkirtHeight, itemNotes, dripEdge, crated, numberOfHoles, holes, length1Whole, length2Whole, length3Whole, length4Whole, loyaltyLevel, shippingTerms);
      }
    });
  }

  chaseQuote(material, color, buildTo, length1, length2, length3, length4, crossbreak, sideSkirtHeight, itemNotes, dripEdge, crated, numberOfHoles, holes, length1Whole, length2Whole, length3Whole, length4Whole, loyaltyLevel, shippingTerms) {
    const postBody = {
      "material": material,
      "color": color,
      "build_to": buildTo,
      "a": length1Whole + length1,
      "b": length2Whole + length2,
      "c": length3Whole + length3,
      "d": length4Whole + length4,
      "cross_break": crossbreak,
      "side_skirt_height": sideSkirtHeight,
      "item_notes": itemNotes,
      "drip_edge": dripEdge,
      "number_of_holes": numberOfHoles,
      "crated": crated,
      "holes": holes,
      "loyalty_level": loyaltyLevel,
      "shipping_terms": shippingTerms
    };

    let jsonPostBody = JSON.stringify(postBody);

    let requestOptions = {
      method: 'GET',
      redirect: 'follow'
    };

    fetch(`/customer/current.jwt?app_client_id=${this.context.middleware_client_id_v2}&random=${Math.random().toString(36)}`, requestOptions)
      .then(response => {
        if (response.ok) {
          return response.text();
        } else {
          return undefined;
        }
      })
      .then(result => {
        let formJwt = result;
        var xhr = new XMLHttpRequest();
        let outsideThis = this
        let jsonResponse;
        // console.log('result: ', result);
        if (result == undefined) {
          swal.fire({
            title: 'please login to continue!'
          });
        } else {
          xhr.addEventListener("readystatechange", function () {
            // console.log('this: ', this);
            jsonResponse = JSON.parse(this.responseText);
            // console.log('jsonResponse: ', jsonResponse);
            if (jsonResponse.Success == true) {
              // console.log('res: ', res);
              let price = parseFloat(jsonResponse.Price).toFixed(2);
              // console.log('price: ', price);
              $('.customPrice__text').html(`The price for your custom chase cover is: $${price}`);
              $('.customPrice').addClass('active');
              $('.customPrice__add-to-cart').addClass('active');
            }
            else {
              let parsedJSON = JSON.parse(this.responseText)
              let errorArray = Array.from(parsedJSON.Errors);
              let htmlArray = [];
              errorArray.forEach(err => {
                htmlArray.push(`<p style='margin-bottom: .5rem' >${err}</p>`)
              })
              let errors = htmlArray.join(" ")
              swal.fire({
                html: errors,
                icon: 'error',
                onClose: outsideThis.hideLoader
              });
            }
          });
        }

        // ############# add to cart functionality ############### \\
        document.querySelector('.customPrice__add-to-cart').addEventListener('click', function () {

          outsideThis.isCartFetch(data => {
            let cartId = data;
            // console.log('cardid: ', cartId)


            if (cartId == false) {
              outsideThis.isLoggedIn(jwt => {
                outsideThis.createCart(jwt, jsonPostBody)
              })
            } else {
              outsideThis.isLoggedIn(jwt => {
                outsideThis.addToCart(cartId, jwt, jsonPostBody)
              })
            }
          })
        })

        xhr.open("POST", `${this.context.middleware_url_v2}/api/chase/quote`);

        xhr.setRequestHeader("Content-Type", "application/json");
        if (formJwt) {
          // console.log('hit here')
          xhr.setRequestHeader("Authorization", `Bearer ${formJwt}`);
        }

        xhr.send(jsonPostBody);
      })
      .catch(error => console.log('error', error));
  }

  //does cart exist
  isCartFetch(callback) {
    var data = "";
    var xhr = new XMLHttpRequest();

    xhr.addEventListener("readystatechange", function () {
      if (this.readyState === 4) {
        // console.log('here',this.responseText)
        if (this.responseText == '[]') {
          // console.log('hit here')
          callback(false)
        } else {
          callback(JSON.parse(this.responseText)[0].id)
        }
      }
    });

    xhr.open("GET", "/api/storefront/carts");

    xhr.send(data);
  }

  /* -------------------------------------------------------------------------- */
  isLoggedIn(callback) {
    var data = "";

    var xhr = new XMLHttpRequest();

    xhr.addEventListener("readystatechange", function () {
      let jwt = ''
      if (this.readyState === 4) {
        if (this.status == 200) {
          jwt = this.responseText
          callback(jwt)
        };
      }
    });

    xhr.open("GET", `/customer/current.jwt?app_client_id=${this.context.middleware_client_id_v2}&random=${Math.random().toString(36)}`);

    xhr.send(data);
  }
  /* -------------------------------------------------------------------------- */
  createCart(jwt, jsonPostBody) {
    var xhr = new XMLHttpRequest();

    xhr.addEventListener("readystatechange", function () {
      // console.log('this: ', this);
      if (this.readyState === 4) {
        // console.log('created', this.responseText)
        let rez = JSON.parse(this.responseText);
        let xhrStatus = this.status
        // console.log(rez);
        if (rez.Success == false) {
          let parsedJSON = JSON.parse(this.responseText)
          let errorArray = Array.from(parsedJSON.Errors);
          let htmlArray = [];
          errorArray.forEach(err => {
            htmlArray.push(`<p style='margin-bottom: .5rem' >${err}</p>`)
          })
          let errors = htmlArray.join(" ")
          swal.fire({
            html: errors,
            icon: 'error'
          });
        } else {
          setTimeout(function () {
            $('.loadingOverlay').hide();
            if (xhrStatus == 200 && rez.Success == true) {
              $('#add-to-cart-success').addClass('is-visible');
              window.location = rez.data.redirect_urls.cart_url;
              setInterval(() => {
                $('#add-to-cart-success').removeClass('is-visible');
              }, 4000);
            }
          }, 1000);
        }

      } else {
        $('.loadingOverlay').show();
      }

    });

    xhr.open("POST", `${this.context.middleware_url_v2}/api/chase/cart`);
    xhr.setRequestHeader("Content-Type", "application/json");
    if (jwt != '') {
      xhr.setRequestHeader("Authorization", `Bearer ${jwt}`);
    }

    xhr.send(jsonPostBody);
  }
  /* -------------------------------------------------------------------------- */
  addToCart(cartId, jwt, jsonPostBody) {

    var xhr = new XMLHttpRequest();

    xhr.addEventListener("readystatechange", function () {
      // console.log('this: ', this);
      if (this.readyState === 4) {
        let rez = JSON.parse(this.responseText);
        // console.log('this.responseText: ', this.responseText);
        // console.log('rez: ', rez);
        let xhrStatus = this.status
        setTimeout(function () {
          $('.loadingOverlay').hide();
          if (xhrStatus == 200 && rez.Success == true) {
            $('#add-to-cart-success').addClass('is-visible');
            window.location = rez.data.redirect_urls.cart_url;
            setInterval(() => {
              $('#add-to-cart-success').removeClass('is-visible');
            }, 4000);
          } else {
            swal.fire({
              icon: "error",
              title: 'There was an error',
              text: 'Item not added to cart.'
            })
          }
        }, 1000);
      } else {
        $('.loadingOverlay').show();
      }

    });

    xhr.open("POST", `${this.context.middleware_url_v2}/api/chase/cart?cartId=${cartId}`);
    xhr.setRequestHeader("Content-Type", "application/json");
    if (jwt != '') {
      xhr.setRequestHeader("Authorization", `Bearer ${jwt}`);
    }


    xhr.send(jsonPostBody);
  }
  /* -------------------------------------------------------------------------- */



  minLength(errorString) {
    let flue = document.querySelector('#ddlCapType')
    let length = document.querySelector('#txtLongLength')
    if ((length.value.trim() == "" || length.value < 9) && (flue.options[flue.selectedIndex].value != 'MFSRnd')) {
      swal.fire({
        text: errorString,
        icon: 'error',
      });
    }
  };
  /* -------------------------------------------------------------------------- */
  minWidth(errorString) {
    let flue = document.querySelector('#ddlCapType')
    let width = document.querySelector('#txtLongWidth')
    if ((width.value.trim() == "" || width.value < 9) && (flue.options[flue.selectedIndex].value != 'MFSRnd')) {
      swal.fire({
        text: errorString,
        icon: 'error',
      });
    }
  };

  infoIcons() {
    document.querySelectorAll('.info-icon--chase').forEach(chaseInfoIcon => {
      chaseInfoIcon.addEventListener('click', () => {
        this.chaseTablePopup();
      })
    })
  }

  chaseTablePopup() {
    swal.fire({
      customClass: {
        container: 'caps--table-popup',
        popup: 'caps--table-popup-content',
        confirmButton: 'button button--primary'
      },
      showCloseButton: true,
      html: `<table class="swal-table">
          <thead>
          <tr>
          <th colspan="4">Fraction/Decimal</th>
          </tr>
          </thead>
          <tbody>
          <tr>
          <td>1/64 <span>0.0156</span></td>
          <td>17/64 <span>0.265</span></td>
          <td>33/64 <span>0.5156</span></td>
          <td>49/64 <span>0.7656</span></td>
          </tr>
          <tr>
          <td>1/32 <span>0.0313</span></td>
          <td>9/32 <span>0.2812</span></td>
          <td>17/32 <span>0.5312</span></td>
          <td>25/32 <span>0.7812</span></td>
          </tr>
          <tr>
          <td>3/64 <span>0.0469</span></td>
          <td>19/64 <span>0.2969</span></td>
          <td>35/64 <span>0.5469</span></td>
          <td>51/64 <span>0.7969</span></td>
          </tr>
          <tr>
          <td>1/16 <span>0.0625</span></td>
          <td>5/16 <span>0.3125</span></td>
          <td>9/16 <span>0.5625</span></td>
          <td>13/16 <span>0.8125</span></td>
          </tr>
          <tr>
          <td>5/64 <span>0.0781</span></td>
          <td>21/64 <span>0.3281</span></td>
          <td>37/64 <span>0.5781</span></td>
          <td>53/64 <span>0.8281</span></td>
          </tr>
          <tr>
          <td>3/32 <span>0.0937</span></td>
          <td>11/32 <span>0.3437</span></td>
          <td>19/32 <span>0.5937</span></td>
          <td>27/32 <span>0.8437</span></td>
          </tr>
          <tr>
          <td>7/64 <span>0.1094</span></td>
          <td>23/64 <span>0.3594</span></td>
          <td>39/64 <span>0.6094</span></td>
          <td>55/64 <span>0.8594</span></td>
          </tr>
          <tr>
          <td>1/8 <span>0.1250</span></td>
          <td>3/8 <span>0.3750</span></td>
          <td>5/8 <span>0.6250</span></td>
          <td>7/8 <span>0.8750</span></td>
          </tr>
          <tr>
          <td>9/64 <span>0.1406</span></td>
          <td>25/64 <span>0.3906</span></td>
          <td>41/64 <span>0.6406</span></td>
          <td>57/64 <span>0.8906</span></td>
          </tr>
          <tr>
          <td>5/32 <span>0.1562</span></td>
          <td>13/32 <span>0.4062</span></td>
          <td>21/32 <span>0.6562</span></td>
          <td>29/32 <span>0.9062</span></td>
          </tr>
          <tr>
          <td>11/64 <span>0.1719</span></td>
          <td>27/64 <span>0.4219</span></td>
          <td>43/64 <span>0.6719</span></td>
          <td>59/64 <span>0.9219</span></td>
          </tr>
          <tr>
          <td>3/16 <span>0.1875</span></td>
          <td>7/16 <span>0.4375</span></td>
          <td>11/16 <span>0.6875</span></td>
          <td>15/16 <span>0.9375</span></td>
          </tr>
          <tr>
          <td>13/64 <span>0.2031</span></td>
          <td>29/64 <span>0.4531</span></td>
          <td>45/64 <span>0.7031</span></td>
          <td>61/64 <span>0.9531</span></td>
          </tr>
          <tr>
          <td>7/32 <span>0.2187</span></td>
          <td>15/32 <span>0.4687</span></td>
          <td>23/32 <span>0.7187</span></td>
          <td>31/32 <span>0.9687</span></td>
          </tr>
          <tr>
          <td>15/64 <span>0.2344</span></td>
          <td>31/64 <span>0.4844</span></td>
          <td>47/64 <span>0.7344</span></td>
          <td>63/64 <span>0.9844</span></td>
          </tr>
          <tr>
          <td>1/4 <span>0.250</span></td>
          <td>1/2 <span>0.5000</span></td>
          <td>3/4 <span>0.7500</span></td>
          <td>1 <span>1.0000</span></td>
          </tr>
          </tbody>
          </table>`
    });
  }

  holeShapes() {
    let holeShapeOneSelect = document.querySelector('#custom-hole-1 [data-labelname="shape"] select');
    let holeShapeOne;
    let holeOneDiameter = document.querySelector('#custom-hole-1 [data-labelname="diameter"]');
    let holeOneMinor = document.querySelector('#custom-hole-1 [data-labelname="minor-dimension"]');
    let holeOneMajor = document.querySelector('#custom-hole-1 [data-labelname="major-dimension"]');

    let holeShapeTwoSelect = document.querySelector('#custom-hole-2 [data-labelname="shape"] select');
    let holeShapeTwo;
    let holeTwoDiameter = document.querySelector('#custom-hole-2 [data-labelname="diameter"]');
    let holeTwoMinor = document.querySelector('#custom-hole-2 [data-labelname="minor-dimension"]');
    let holeTwoMajor = document.querySelector('#custom-hole-2 [data-labelname="major-dimension"]');

    let holeShapeThreeSelect = document.querySelector('#custom-hole-3 [data-labelname="shape"] select');
    let holeShapeThree;
    let holeThreeDiameter = document.querySelector('#custom-hole-3 [data-labelname="diameter"]');
    let holeThreeMinor = document.querySelector('#custom-hole-3 [data-labelname="minor-dimension"]');
    let holeThreeMajor = document.querySelector('#custom-hole-3 [data-labelname="major-dimension"]');

    let holeShapeFourSelect = document.querySelector('#custom-hole-4 [data-labelname="shape"] select');
    let holeShapeFour;
    let holeFourDiameter = document.querySelector('#custom-hole-4 [data-labelname="diameter"]');
    let holeFourMinor = document.querySelector('#custom-hole-4 [data-labelname="minor-dimension"]');
    let holeFourMajor = document.querySelector('#custom-hole-4 [data-labelname="major-dimension"]');

    // hole 1
    holeShapeOneSelect.addEventListener('change', e => {
      holeShapeOne = e.target.value;
      if (holeShapeOne == "Round") {
        holeOneDiameter.classList.add('show-field');
        holeOneMajor.classList.remove('show-field');
        holeOneMinor.classList.remove('show-field');
      } else if (holeShapeOne == "") {
        holeOneDiameter.classList.remove('show-field');
        holeOneMajor.classList.remove('show-field');
        holeOneMinor.classList.remove('show-field');
      } else {
        holeOneDiameter.classList.remove('show-field');
        holeOneMajor.classList.add('show-field');
        holeOneMinor.classList.add('show-field');
      }
    });

    // hole 2
    holeShapeTwoSelect.addEventListener('change', e => {
      holeShapeTwo = e.target.value;
      if (holeShapeTwo == "Round") {
        holeTwoDiameter.classList.add('show-field');
        holeTwoMajor.classList.remove('show-field');
        holeTwoMinor.classList.remove('show-field');
      } else if (holeShapeTwo == "") {
        holeTwoDiameter.classList.remove('show-field');
        holeTwoMajor.classList.remove('show-field');
        holeTwoMinor.classList.remove('show-field');
      } else {
        holeTwoDiameter.classList.remove('show-field');
        holeTwoMajor.classList.add('show-field');
        holeTwoMinor.classList.add('show-field');
      }
    });
    // hole 3
    holeShapeThreeSelect.addEventListener('change', e => {
      holeShapeThree = e.target.value;
      if (holeShapeThree == "Round") {
        holeThreeDiameter.classList.add('show-field');
        holeThreeMajor.classList.remove('show-field');
        holeThreeMinor.classList.remove('show-field');
      } else if (holeShapeThree == "") {
        holeThreeDiameter.classList.remove('show-field');
        holeThreeMajor.classList.remove('show-field');
        holeThreeMinor.classList.remove('show-field');
      } else {
        holeThreeDiameter.classList.remove('show-field');
        holeThreeMajor.classList.add('show-field');
        holeThreeMinor.classList.add('show-field');
      }
    });

    // hole 4
    holeShapeFourSelect.addEventListener('change', e => {
      holeShapeFour = e.target.value;
      if (holeShapeFour == "Round") {
        holeFourDiameter.classList.add('show-field');
        holeFourMajor.classList.remove('show-field');
        holeFourMinor.classList.remove('show-field');
      } else if (holeShapeFour == "") {
        holeFourDiameter.classList.remove('show-field');
        holeFourMajor.classList.remove('show-field');
        holeFourMinor.classList.remove('show-field');
      } else {
        holeFourDiameter.classList.remove('show-field');
        holeFourMajor.classList.add('show-field');
        holeFourMinor.classList.add('show-field');
      }
    });
  }

  holePositions() {
    let centerSelect = document.querySelector('#custom-hole-1 [data-labelname="center"] select');
    let centered;
    let holePositionTitle = document.querySelector('#custom-hole-1 .custom-hole-information');
    let holePositionFields = document.querySelector('#custom-hole-1 .custom-four-block');

    centerSelect.addEventListener('change', e => {
      centered = e.target.value;
      if (centered == "No") {
        holePositionTitle.classList.add('show-field');
        holePositionFields.classList.add('show-field--flex');
      } else {
        holePositionTitle.classList.remove('show-field');
        holePositionFields.classList.remove('show-field--flex');
      }
    })
  }

}
