import 'focus-within-polyfill';
import 'datatables.net-dt';

import './global/jquery-migrate';
import './common/select-option-plugin';
import PageManager from './page-manager';
import quickSearch from './global/quick-search';
import currencySelector from './global/currency-selector';
import mobileMenuToggle from './global/mobile-menu-toggle';
import menu from './global/menu';
import foundation from './global/foundation';
import quickView from './global/quick-view';
import cartPreview from './global/cart-preview';
import privacyCookieNotification from './global/cookieNotification';
import adminBar from './global/adminBar';
import carousel from './common/carousel';
import loadingProgressBar from './global/loading-progress-bar';
import svgInjector from './global/svg-injector';
import matchHeight from 'jquery-match-height';

export default class Global extends PageManager {
    onReady() {
        const {
            channelId, cartId, productId, categoryId, secureBaseUrl, maintenanceModeSettings, adminBarLanguage, showAdminBar,
        } = this.context;
        cartPreview(secureBaseUrl, cartId);
        quickSearch();
        currencySelector(cartId);
        foundation($(document));
        quickView(this.context);
        carousel();
        menu();
        mobileMenuToggle();
        privacyCookieNotification();
        if (showAdminBar) {
            adminBar(secureBaseUrl, channelId, maintenanceModeSettings, JSON.parse(adminBarLanguage), productId, categoryId);
        }
        loadingProgressBar();
        svgInjector();
        this.slickBrandsCarousel();
        this.threeColumnCardMatchHeight();
        this.redirectAfterLogin();
        if (window.location.pathname == '/invoice-details/') {
          this.invoiceDetails();
        }
        let accountLoyaltyContainer = document.querySelector('.account__loyalty-container');
        if (typeof accountLoyaltyContainer != 'undefined' && accountLoyaltyContainer != null) {
          this.customerInfo();
        }
        this.showSuccessfulLogin();
    }

    customerInfo() {
      let loyaltyTierId = this.context.loyalty_tier_id;
      fetch("/graphql", {
        method: "POST",
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${this.context.storefront_api}`,
    },
    body: JSON.stringify({
        query: `
        query  {
            customer {
                attributes {
                    attribute(entityId: ${loyaltyTierId}) {
                        name
                        value
                    }
                }
            }
        }`,
    }),
})
    .then((response) => response.json())
    .then((data) => {                        
        let loyaltyAtt = data.data.customer.attributes.attribute
        let loyaltyValue = loyaltyAtt.value
        let spendToDateId = this.context.spend_to_date_id;

        if (loyaltyValue != "N/A") {
            fetch("/graphql", {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${this.context.storefront_api}`,
            },
            body: JSON.stringify({
                query: `
                query  {
                    customer {
                        attributes {
                            attribute(entityId: ${spendToDateId}) {
                                name
                                value
                            }
                        }
                    }
                }`,
            }),
        })
            .then((response) => response.json())
            .then((data) => {   
                let spentAtt = data.data.customer.attributes.attribute
                let spentValue = () => {
                  if (spentAtt.value == null) {
                    return '0';
                  } else {
                    return spentAtt.value
                  }
                }

                document.querySelector('.account__loyalty-container').innerHTML = `
                <div class='account__loyalty-level--${loyaltyValue.toLowerCase()}'>${loyaltyValue} Member</div>
                <div class='account__loyalty-info'>
                    <div class='account__loyalty-col'>
                        <p class='account__loyalty-info-top'>Welcome Back,</p>
                        <p class='account__loyalty-info-bottom'>${this.context.customer.name}</p>
                    </div>
                    <div class='account__loyalty-col'>
                      <p class='account__loyalty-info-top'>Loyalty Program</p>
                        <p class='account__loyalty-info-bottom'>${loyaltyValue}</p>
                    </div>
                    <div class='account__loyalty-col'>
                    <div class='account__icon-description-container--top-aligned'><p class='account__info-box'>Year-to-date spend reflects invoiced sales only.</p><svg class="info-icon"><use xlink:href="#icon-information-outline"></use></svg></div>
                        <p class='account__loyalty-info-top'>Spent to Date</p>
                        <p class='account__loyalty-info-bottom'>$${spentValue().toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</p>
                    </div>

                </div>
                `
            });
        }
    });
        this.heroBannerArrows();
        let accountDropdown = document.querySelector('.account-orderStatus-label'); 
        if (typeof accountDropdown != 'undefined' && accountDropdown != null) {
          this.accountNav();
        }
    }

    accountNav() {
      document.querySelector('.navBar-account__button').addEventListener('click', (e) => {
        document.querySelector('.navBar-section').classList.toggle('account-navActive');
        e.currentTarget.parentElement.classList.toggle('account-active')
      })
    }

    heroBannerArrows() {
      let jsNextArrow = document.querySelector('.js-hero-next-arrow');
        if (typeof jsNextArrow != 'undefined' && jsNextArrow != null) {
          let pausePlayBtn = document.querySelector('.heroCarousel-play-pause-button');
          let jsNextArrows = document.querySelectorAll('.js-hero-next-arrow');
          let jsPrevArrows = document.querySelectorAll('.js-hero-prev-arrow');
          jsNextArrows.forEach(jsNextArr => {
            jsNextArr.addEventListener('click', () => {
              pausePlayBtn.click();
              setTimeout(() => {
                pausePlayBtn.click();              
              }, 500);
            });
          });
  
          jsPrevArrows.forEach(jsPrevArr => {
            jsPrevArr.addEventListener('click', () => {
              pausePlayBtn.click();
              setTimeout(() => {
                pausePlayBtn.click();              
              }, 500);
            });
          });
        }

        let equalHeights = (selector) => {
          var elms = document.querySelectorAll(selector);
          var len = elms.length;
          var tallest = 0;
          var elm, elmHeight, x;
        
          for (x = 0; x < len; x++) {
            elms[x].style.height = 'auto';
          }
        
          for (x = 0; len > x; x++) {
            elm = elms[x];
            elmHeight = elm.offsetHeight;
            tallest = (elmHeight > tallest) ? elmHeight : tallest;
          }
        
          for (x = 0; len > x; x++) {
            elms[x].style.height = tallest + 'px';
          }
        }
        
        const debounce = (callback, wait) => {
          let timeout;
          return (...args) => {
            const context = this;
            clearTimeout(timeout);
            timeout = setTimeout(() => callback.apply(context, args), wait);
          };
        };
        
        const debounceResize = debounce(() => {
          equalHeights('.productCarousel-slide');
          equalHeights('.productCarousel-slide .card-title');
        }, 250);
        
        window.addEventListener('resize', debounceResize);
        window.dispatchEvent(new Event('resize'));
    }

    printPage() {
      window.print();
    } 

    moneyRounder(num) {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
      }).format(num);
    }

    invoiceDetails() {
          let jwt = '';
          let invoiceNumber = window.location.search.split('=')[1];
          fetch(`/customer/current.jwt?app_client_id=${this.context.middleware_client_id_v2}&random=${Math.random().toString(36)}`)
          .then(response => response.text())
          .then(result => {
              jwt = result;
              console.log(result)
              let invoiceDetailsBody = document.querySelector('.invoice-details__body');
              if (jwt == '') {
                invoiceDetailsBody.style.background = '#F7F7F7';                  
                invoiceDetailsBody.innerHTML = '<p class="page-content--centered">API error, please refresh and try again.</p>';
              } else {
              var myHeaders = new Headers();
              myHeaders.append("Content-Type", "application/json");
              myHeaders.append("Referer", "https://copperfield-sandbox.mybigcommerce.com");
              myHeaders.append("Authorization", `Bearer ${jwt}`);
              
              var raw = JSON.stringify({
                "ReferenceNbr": invoiceNumber
              });

              var requestOptions = {
                method: 'POST',
                headers: myHeaders,
                body: raw,
                redirect: 'follow'
              };
            
              fetch(`${this.context.middleware_url_v2}/api/acumatica/InvoiceDetails`, requestOptions)
                .then(response => response.json())
                .then(result => {
                  console.log(result)
                  invoiceDetailsBody.style.background = '#F7F7F7';                  
                  let aePath = result.AEInvoices.AEMyAccountInvoicesByInvcDetails[0];
                  let invoicesPath = result.Invoices[0];
                  let invoiceNum = aePath.InvoiceNumber.value;
                  let paidDate = new Date(aePath.PaymentDate.value).toLocaleDateString();
                  let billingAddress = invoicesPath.BillingSettings.BillToAddress.AddressLine1.value;
                  let billingCity = invoicesPath.BillingSettings.BillToAddress.City.value;
                  let billingCountry = invoicesPath.BillingSettings.BillToAddress.Country.value;
                  let billingZip = invoicesPath.BillingSettings.BillToAddress.PostalCode.value;
                  let billingState = invoicesPath.BillingSettings.BillToAddress.State.value;
                  let billingAttentionTo = invoicesPath.BillingSettings.BillToContact.Attention.value;
                  let billingCompany = invoicesPath.BillingSettings.BillToContact.BusinessName.value;
                  let billingEmail = invoicesPath.BillingSettings.BillToContact.Email.value;
                  let billingPhone = invoicesPath.BillingSettings.BillToContact.Phone1.value;
                  let orderNumber = invoicesPath.Details[0].OrderNbr.value;
                  let paymentMethod = invoicesPath.Details[0].BranchID.value;
                  let getShippingMethod = aePath.Carrier.value;
                  let shippingAttentionTo = invoicesPath.ShipToAddress.Attention.value;
                  let shippingCompany = invoicesPath.ShipToAddress.CompanyName.value;
                  let shippingAddress = invoicesPath.ShipToAddress.AddressLine1.value;
                  let shippingCity = invoicesPath.ShipToAddress.City.value;
                  let shippingState = invoicesPath.ShipToAddress.State.value;
                  let shippingZip = invoicesPath.ShipToAddress.PostalCode.value;
                  let shippingCountry = invoicesPath.ShipToAddress.Country.value;
                  let shippingEmail = invoicesPath.ShipToAddress.Email.value;
                  let shippingPhone = invoicesPath.ShipToAddress.Phone1.value;
                  let orderDate = new Date(aePath.OrderDate.value).toLocaleDateString();
                  let invoiceDate = new Date(invoicesPath.Date.value).toLocaleDateString();
                  let shippingDate = new Date(aePath.ShipDate.value).toLocaleDateString();
                  let trackingActualNumber = aePath.TrackingNumber.value;
                  let shippingTotal = invoicesPath.FreightPrice?.value ?? 0;
                  let subTotal = this.moneyRounder(invoicesPath.DetailTotal.value - shippingTotal);
                  let taxTotal = this.moneyRounder(invoicesPath.TaxTotal.value);
                  let grandTotal = this.moneyRounder(aePath.InvoiceAmount.value);
                  shippingTotal = shippingTotal > 0 ? this.moneyRounder(shippingTotal) : "Free Shipping";
                  let invoiceItems = invoicesPath.Details;
                  let shippingMethod = () => {
                    if (getShippingMethod == null) {
                      return 'No Shipping Method Available'
                    } else if (getShippingMethod == 'FEDEX' || getShippingMethod == 'FED EX') {
                      return 'FEDEX'
                    } else if (getShippingMethod == 'UPS') {
                      return 'UPS'
                    }
                  }
                  let trackingNumber = () => {
                    if (getShippingMethod == null) {
                      return 'No Tracking Number';
                    } else if (getShippingMethod == 'FEDEX' || getShippingMethod == 'FED EX') {
                      return `<span><a href='https://www.fedex.com/fedextrack/?trknbr=${trackingActualNumber}' target='_blank' class='account__invoice-link'>${trackingActualNumber}</a></span>`;
                    } else if (getShippingMethod == 'UPS') {
                      return `<span><a href='https://www.ups.com/track?tracknum=${trackingActualNumber}' target='_blank' class='account__invoice-link'>${trackingActualNumber}</a></span>`;
                    } else {
                      return `<span>${trackingActualNumber}</span>`;
                    }
                  }
                  let invoiceMainWrapper = `
  
<div class="invoice-main-wrapper">
<p class="invoice-details__section-title">Invoice Items:</p>
<div class="invoice-item-grid">
  <div class="invoice-details__items">
    `;
invoiceItems.forEach(ii => {
    invoiceMainWrapper += ` 
    <div class="invoice-details__single-item">
      <div class="invoice-details__item-info">
        <p class="invoice-details__item-info-title">Qty</p>
        <p class="invoice-details__item-info-data">${ii.Qty.value}</p>
      </div>
      <div class="invoice-details__item-info">
        <p class="invoice-details__item-info-title">Code/SKU</p>
        <p class="invoice-details__item-info-data">#${ii.InventoryID.value}</p>
      </div>
      <div class="invoice-details__item-info">
        <p class="invoice-details__item-info-title">Product Name</p>
        <p class="invoice-details__item-info-data">${ii.Description.value}</p>
      </div>
      <div class="invoice-details__item-info">
        <p class="invoice-details__item-info-title">Unit Price</p>
        <p class="invoice-details__item-info-data">${this.moneyRounder(ii.UnitPrice.value)}</p>
      </div>
      <div class="invoice-details__item-info">
        <p class="invoice-details__item-info-title">Total</p>
        <p class="invoice-details__item-info-data">${this.moneyRounder(ii.Amount.value)}</p>
      </div>
    </div>`;
});
invoiceMainWrapper += `
  </div>
  <div class="invoice-details__totals">
    <dl class="invoice-details__totals-wrap">
    <dl class="invoice-details__totals-single">  
      <dt class="invoice-details__totals-title">Subtotal:</dt>
      <dd class="invoice-details__totals-data">${subTotal}</dd>
      </dl>
      
    <dl class="invoice-details__totals-single">  
      <dt class="invoice-details__totals-title">Shipping:</dt>
      <dd class="invoice-details__totals-data">${shippingTotal}</dd>
      </dl>
    <dl class="invoice-details__totals-single">  
      <dt class="invoice-details__totals-title">Tax:</dt>
      <dd class="invoice-details__totals-data">${taxTotal}</dd>
      </dl>
    
      <dl class="invoice-details__total-wrap-bottom">
        <dt class="invoice-details__totals-title">Grand Total:</dt>
        <dd class="invoice-details__totals-data">${grandTotal}</dd>
      </dl>
    </dl>
  </div>
  </div>
</div>`;

                  let invoiceDetailsBodyTop = `<div class="invoice-details__body-top">
                  <div class="invoice-details__info-top">
                      <div class="invoice-details__top-left">
                          <p class="invoice-details__invoice-num">Copperfield Invoice #${invoiceNum}</p>
                      </div>
                      <div class="invoice-details__top-right">
                          <div class="invoice-details__inner">
                              <div class="invoice-details__inner-left">
                                  <dl>
                                      <dt>Paid Date:</dt>
                                      <dd>${paidDate}</dd>
                                  </dl>
                              </div>
                              <div class="invoice-details__inner-right">
                                  <a class="account__invoice-button" href="#">Print Invoice</a>
                              </div>
                          </div>
                      </div>
                  </div>
              
                  <div class="invoice-details__customer-info">
                      <div class="invoice-details__customer-info-left">
                          <p class="invoice-details__section-title">Bill To:</p>
                          <div class="invoice-details__customer-content">
              
                              <div class="invoice-customer-info-left">
                                  <div class="invoice-details__info-piece">
                                      <p class="invoice-shipping-title">Shipping Address</p>
                                      <p class="invoice-details__customer-name">${billingAttentionTo}</p>
                                      <p class="invoice-details__customer__address">
                                          ${billingCompany}<br>${billingAddress}<br>${billingCity}, ${billingState}
                                          ${billingZip}<br>${billingCountry}</p>
                                  </div>
                                  <dl class="invoice-details__info-piece">
                                      <dt class="invoice-details__info-piece-title">Phone:</dt>
                                      <dd class="invoice-details__info-piece-data">${billingPhone}</dd>
                                      <dt class="invoice-details__info-piece-title">Email:</dt>
                                      <dd class="invoice-details__info-piece-data">${billingEmail}</dd>
                                  </dl>
              
              
                              </div>
              
                              <div class="invoice-customer-order-info-left">
                                  <dl class="invoice-details__info-piece">
                                      <dt class="invoice-details__info-piece-title">Order:</dt>
                                      <dd class="invoice-details__info-piece-data">#${orderNumber}</dd>
                                  </dl>
              
                                  <dl class="invoice-details__info-piece">
                                      <dt class="invoice-details__info-piece-title">Payment Method:</dt>
                                      <dd class="invoice-details__info-piece-data">${paymentMethod} <span
                                              class="invoice-details__total">(${grandTotal})</span></dd>
                                  </dl>
                                  <dl class="invoice-details__info-piece">
                                      <dt class="invoice-details__info-piece-title">Shipping Method:</dt>
                                      <dd class="invoice-details__info-piece-data">${shippingMethod()}</dd>
                                  </dl>
                              </div>
              
                          </div>
                      </div>
                      <div class="invoice-details__customer-info-right">
                          <p class="invoice-details__section-title">Ship To:</p>
                          <div class="invoice-details__customer-content">
              
                              <div class="invoice-customer-info-right">
                                  <div class="invoice-details__info-piece">
                                  <p class="invoice-shipping-title">Shipping Address</p>
                                      <p class="invoice-details__customer-name">${shippingAttentionTo}</p>
                                      <p class="invoice-details__customer__address">
                                          ${shippingCompany}<br>${shippingAddress}<br>${shippingCity}, ${shippingState}
                                          ${shippingZip}<br>${shippingCountry}</p>
                                  </div>
                                  <dl class="invoice-details__info-piece">
                                      <dt class="invoice-details__info-piece-title">Phone:</dt>
                                      <dd class="invoice-details__info-piece-data">${shippingPhone}</dd>
                                      <dt class="invoice-details__info-piece-title">Email:</dt>
                                      <dd class="invoice-details__info-piece-data">${shippingEmail}</dd>
                                  </dl>
                              </div>
              
                              <div class="invoice-customer-order-info-right">
                                  <dl class="invoice-details__info-piece">
                                      <dt class="invoice-details__info-piece-title">Order Date:</dt>
                                      <dd class="invoice-details__info-piece-data">${orderDate}</dd>
                                  </dl>
                                  <dl class="invoice-details__info-piece">
                                      <dt class="invoice-details__info-piece-title">Invoice Date:</dt>
                                      <dd class="invoice-details__info-piece-data">${invoiceDate}</dd>
                                  </dl>
                                  <dl class="invoice-details__info-piece">
                                      <dt class="invoice-details__info-piece-title">Shipping Date:</dt>
                                      <dd class="invoice-details__info-piece-data">${shippingDate}</dd>
                                  </dl>
                                  <dl class="invoice-details__info-piece">
                                      <dt class="invoice-details__info-piece-title">Tracking Number:</dt>
                                      <dd class="invoice-details__info-piece-data">${trackingNumber()}</dd>
                                  </dl>
                              </div>
              
                          </div>
                      </div>
                  </div>
              </div>`;
                
                document.querySelector('.invoice-details__body').innerHTML = invoiceDetailsBodyTop + invoiceMainWrapper;
                document.querySelector('.account__invoice-button').addEventListener('click', e => {
                  e.preventDefault();
                  this.printPage();
                })
                })
                .catch(error => console.log('error', error));
              }
                  })
    }       

    redirectAfterLogin() {
      if (document.referrer != '') {
        let prevURL = new URL(document.referrer);
        let redirectInput = document.querySelector('#redirect_to');
        if (typeof redirectInput != 'undefined' && redirectInput != null) {
          redirectInput.value = prevURL.pathname + '?successfulLogin=true';
        }
      }
    }  
    
    showSuccessfulLogin() {
      if (window.location.search == '?successfulLogin=true') {
        document.querySelector('.header__login-successful').classList.add('active');
        setTimeout(() => {
          document.querySelector('.header__login-successful').classList.remove('active');
        }, 3000);
      }
    }


    slickBrandsCarousel() {
        const brandCarousel = $('.brands-carousel');

        if (brandCarousel.length > 0) {
            brandCarousel.slick({
                dots: true,
                infinite: true,
                mobileFirst: true,
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: true,
                responsive: [
                    {
                        breakpoint: 400,
                        settings: {
                            slidesToShow: 2
                        }
                    },
                    {
                        breakpoint: 551,
                        settings: {
                            slidesToShow: 3
                        }
                    },
                    {
                        breakpoint: 801,
                        settings: {
                            slidesToShow: 4
                        }
                    },
                    {
                        breakpoint: 1000,
                        settings: {
                            slidesToShow: 5
                        }
                    },
                    {
                        breakpoint: 1261,
                        settings: {
                            slidesToShow: 6,
                            arrows: true
                        }
                    }
                ]
            });
        }
    }

    threeColumnCardMatchHeight() {
        const threeColumnCard = $('.three-column-card');

        if (threeColumnCard.length > 0) {
            threeColumnCard.matchHeight();
        }
    }
}
