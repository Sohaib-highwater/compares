import 'foundation-sites/js/foundation/foundation';
import 'foundation-sites/js/foundation/foundation.dropdown';
import utils from '@bigcommerce/stencil-utils';

export const CartPreviewEvents = {
    close: 'closed.fndtn.dropdown',
    open: 'opened.fndtn.dropdown',
};

export default function (secureBaseUrl, cartId) {
    const loadingClass = 'is-loading';
    const $cart = $('[data-cart-preview]');
    const $cartDropdown = $('#cart-preview-dropdown');
    const $cartLoading = $('<div class="loadingOverlay"></div>');

    const $body = $('body');

    $body.on('cart-quantity-update', (event, quantity) => {
        $cart.attr('aria-label', (_, prevValue) => prevValue.replace(/\d+/, quantity));

        if (!quantity) {
            $cart.addClass('navUser-item--cart__hidden-s');
        } else {
            $cart.removeClass('navUser-item--cart__hidden-s');
        }
      fetch('/api/storefront/cart', { credentials: 'include' })
        .then((res) => { return res.json(); })
        .then((cart) => {
          if (cart.length > 0) {
            let physicalItems = cart[0].lineItems.physicalItems;
            let specialSkus = ['LP-PLATINUM', 'LP-SILVER', 'LP-BRONZE', 'LP-COPPER', 'ETAILER', 'LP-DIAMOND'];          
            let PskuArr = [];
            physicalItems.forEach(physical => {
              PskuArr.push(physical.sku);
            })
            let alreadyInCart = specialSkus.filter(sku => PskuArr.includes(sku));
            if (alreadyInCart.length > 0) {
              $('.cart-quantity').text(quantity - alreadyInCart.length).toggleClass('countPill--positive', quantity > 0);
            } else {
              $('.cart-quantity').text(quantity).toggleClass('countPill--positive', quantity > 0);
            }
            let countPill = document.querySelector('.countPill');
            if (countPill.classList.contains('countPill--positive')) {
              let countPillPositive = document.querySelector('.countPill--positive');
              if (parseInt(countPillPositive.textContent) > 99) {
                countPill.classList.add('countPill--large');
              } else {
                countPill.classList.remove('countPill--large');
              }
            }
          }
        });
      
        

        if (utils.tools.storage.localStorageAvailable()) {
            localStorage.setItem('cart-quantity', quantity);
        }
    });

    $cart.on('click', event => {
        const options = {
            template: 'common/cart-preview',
        };

        // Redirect to full cart page
        //
        // https://developer.mozilla.org/en-US/docs/Browser_detection_using_the_user_agent
        // In summary, we recommend looking for the string 'Mobi' anywhere in the User Agent to detect a mobile device.
        if (/Mobi/i.test(navigator.userAgent)) {
            return event.stopPropagation();
        }

        event.preventDefault();

        $cartDropdown
            .addClass(loadingClass)
            .html($cartLoading);
        $cartLoading
            .show();

        utils.api.cart.getContent(options, (err, response) => {  
            $cartDropdown
                .removeClass(loadingClass)
                .html(response);
            $cartLoading
                .hide();
                let configSkusArr = ['CHASECOVER-M', '03609014', '03609013', '03609012', '03609011', '03608246', '03608236', '03608235', '03608234', '03608233', '03608232', '03608231', '03608230', '03608229', '03608228', '03608227', '03608226', '03608225', '03608224', '03608223', '03608222', '03608221', '03608220', '03608219', '03608218', '03608217', '03608216', '03608215', '03608214', '03608213', '3608957', '3608956', '3608955', '3608954'];
                document.querySelectorAll('[data-config-sku]').forEach((configItem) => {
                  if (configSkusArr.filter(config => (configItem.dataset.configSku.includes(config))).length > 0) {
                    configItem.removeAttribute('href');
                    configItem.classList.add('removeHref');
                  }
                });
        });
    });

    let quantity = 0;

    if (cartId) {
        // Get existing quantity from localStorage if found
        if (utils.tools.storage.localStorageAvailable()) {
            if (localStorage.getItem('cart-quantity')) {
                quantity = Number(localStorage.getItem('cart-quantity'));
                $body.trigger('cart-quantity-update', quantity);
            }
        }

        // Get updated cart quantity from the Cart API
        const cartQtyPromise = new Promise((resolve, reject) => {
            utils.api.cart.getCartQuantity({ baseUrl: secureBaseUrl, cartId }, (err, qty) => {
                if (err) {
                    // If this appears to be a 404 for the cart ID, set cart quantity to 0
                    if (err === 'Not Found') {
                        resolve(0);
                    } else {
                        reject(err);
                    }
                }
                resolve(qty);
            });
        });

        // If the Cart API gives us a different quantity number, update it
        cartQtyPromise.then(qty => {
            quantity = qty;
            $body.trigger('cart-quantity-update', quantity);
        });
    } else {
        $body.trigger('cart-quantity-update', quantity);
    }
}
