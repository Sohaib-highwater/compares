import PageManager from "./page-manager";

export default class Invoices extends PageManager {
    constructor(context) {
        super(context);
    }

    onReady() {
      this.customOrders();
    }

    customOrders() {
      if (document.querySelector('.account-content-all')) {
          let jwt = '';
          fetch(`/customer/current.jwt?app_client_id=${this.context.middleware_client_id_v2}&random=${Math.random().toString(36)}`)
          .then(response => response.text())
          .then(result => {
              jwt = result;
              console.log(result)
              if (jwt == '') {
                  document.querySelector('.account-body').innerHTML = '<p class="page-content--centered">API error, please refresh and try again.</p>'
              } else {
                  var myHeaders = new Headers();
                  myHeaders.append("Authorization", `Bearer ${jwt}`);
                  
                  
                  var requestOptions = {
                    method: 'GET',
                    headers: myHeaders,
                    redirect: 'follow'
                  };
                  
                  fetch(`${this.context.middleware_url_v2}/api/acumatica/InvoicesDetails`, requestOptions)
                    .then(response => response.json())
                    .then(result => {
                      this.applyOrderHTML(result)
                    })
                    .catch(error => console.log('error', error));

                  
                  
              }
          })
      }
  }

  moneyRounder(num) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(num);
  }

  applyOrderHTML(res) {
    console.log(res);
    let listItems = ``;
    listItems += `<tbody class="account__tbody-container">`;
    let bigArr = []
    res.Invoices.forEach(invoice => {
        let orderColor = ''
        let date = new Date(invoice.OrderDate.value  ?? '9999-09-09').toISOString().split('T')[0];
        date = date.split('-');
        date = `${date[0]}${date[1]}${date[2]}`;
        if (invoice.Status.value == 'Open') {
            orderColor = '#D11D10'
        } else if (invoice.Status.value == 'Completed') {
            orderColor = '#098F6B'
        } else {
            orderColor = 'black'
        }
        let invoiceNeeded = () => {
            if (invoice.Status.value == 'Open') {
                return `<a class='account__invoice-button' href="https://connect.ebizcharge.net/EbizLogin.aspx?ReturnUrl=%2fcopperfieldchimneyllc" target="_blank">Pay Invoice</a>`
            } else {
                return ''
            }
        }
        let infoBoxNeeded = () => {
            if (invoice.Status.value == 'Open') {
                return `<div class='account__icon-description-container'><p class='account__info-box'>Clicking "Pay Invoice" button on this page will launch a payment portal and a separate login will be required.  
                Please use <a href='mailto:ship-to@email.com'>ship-to@email.com</a> to login to the portal.</p><svg class="info-icon"><use xlink:href="#icon-information-outline"></use></svg></div>`
            } else {
                return ''
            }
        }
        let trackingNumber = () => {
          if (invoice.Carrier.value == null) {
            return 'No Tracking Number'
          } else if (invoice.Carrier.value == 'FEDEX' || invoice.Carrier.value == 'FED EX') {
            return `<span><a href='https://www.fedex.com/fedextrack/?trknbr=${invoice.TrackingNumber.value}' target='_blank' class='account__invoice-link'>${invoice.TrackingNumber.value}</a></span>`
          } else if (invoice.Carrier.value == 'UPS') {
            return `<span><a href='https://www.ups.com/track?tracknum=${invoice.TrackingNumber.value}' target='_blank' class='account__invoice-link'>${invoice.TrackingNumber.value}</a></span>`
          } else {
            return `<span>${invoice.TrackingNumber.value}</span>`
          }
        }


        listItems += `
            <tr class="account__order-dates-container">
              <td class='account__date-item'>
                <div class="account__date-top account__date-content account__first-left">
                  <a href=${`/invoice-details?cin=${invoice.InvoiceNumber.value}`} class='account__order-num account__bold-item'>Invoice # ${invoice.InvoiceNumber.value}</a>
                  <p><span class='account__total-num'>${invoice.InvoicedQty.value}</span><span class='account__order-total'>Items Totaling ${this.moneyRounder(invoice.InvoiceAmount.value)}</span></p>
                </div>
                <div class="account__date-bottom account__date-content account__first-left">
                  <span class="account__bold-item">Order Date</span>
                  <span class="account__order-date" data-event-date="${new Date(invoice.OrderDate.value).toLocaleDateString()}">${new Date(invoice.OrderDate.value).toLocaleDateString()}</span>
                </div>
              </td>
              <td class='account__date-item'>
                <div class="account__date-top account__date-content">
                  <span class="account__bold-item">Tracking Number</span>
                  <span>${trackingNumber()}</span>
                </div>
                <div class="account__date-bottom account__date-content">
                  <span class="account__bold-item">Shipment Date</span>
                  <span>${new Date(invoice.ShipDate.value).toLocaleDateString()}</span>
                </div>
              </td>
              <td class='account__date-item'>
                <div class="account__date-top account__date-content">
                  <span class="account__bold-item">Invoice Status</span>
                  <span>${invoice.Status.value}</span>
                </div>
                <div class="account__date-bottom account__date-content">
                  <span class="account__bold-item">Paid Date</span>
                  <span>${new Date(invoice.PaymentDate.value).toLocaleDateString()}</span>
                </div>
              </td>
              <td class="account__button-container">
                <a class='account__invoice-button' href="${`/invoice-details?cin=${invoice.InvoiceNumber.value}`}">View Invoice</a>
                <div class='account__info-button-container'>${infoBoxNeeded()} ${invoiceNeeded()} 
                </div>
              </td>
              <td style="display: none">${date}</td>
            </tr>`;
    })
    listItems += `</tbody>`;
    document.querySelector('.account-content').innerHTML = `<table class='account__order-list'><thead style="display: none;">
    <tr>
        <th>Name</th>
        <th>Position</th>
        <th>Office</th>
        <th>Age</th>
        <th class="account__th-date">Date</th>
    </tr>
</thead>${listItems.toString()}</table>`
    this.invoiceSearch();
}

invoiceSearch() {
  let sortOption = document.createElement('button');
  sortOption.classList = 'account__sort-option';
  let thDate = document.querySelector('.account__th-date');
  document.querySelector('.account-content').addEventListener('click', e => {
    if (e.target.classList.contains('account__sort-option')) {
      thDate.click();
      sortOption.classList.toggle('account__sort-option--active');
    }
  })
  $('.account__order-list').DataTable({
    paging: false,
    "drawCallback": function() {
      $('.dataTables_filter').append(sortOption);
    },
    order: [[4, 'desc']],
    language: {
      search: '',
      searchPlaceholder: 'Search',
      info: `<span class="dataTable__bold-text">Disclaimer: </span>Order history is only shown for previous 90 days. For additional information please contact us directly.`,
    }
  });
}
}
