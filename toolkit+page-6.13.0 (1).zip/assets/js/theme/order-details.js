import PageManager from "./page-manager";

export default class OrderDetails extends PageManager {
    constructor(context) {
        super(context);
    }

    onReady() {
        this.orderDetailsCall()
    }

    orderDetailsCall() {
        const queryString = window.location.search;
        const params = new URLSearchParams(queryString);
        const orderID = params.get('id')
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        var raw = JSON.stringify({
            "orderId": `${orderID}`
        });

        var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
        };

        fetch(`${this.context.middleware_url_v2}/api/acumatica/orderdetails`, requestOptions)
        .then(response => response.json())
        .then(result => {
            console.log(result.Order)
            let detailItems = ``
            result.Order.Details.forEach(item => {
                detailItems +=  `<li class="account-listItem">
                                    <div class="account-product account-product--alignMiddle">
                                        <div class="account-product-checkItem">
                                            <input class="form-checkbox" type="checkbox" id="account-product-id-{{order_product_id}}" value="{{order_product_id}}">
                                            <label for="account-product-id-{{order_product_id}}" class="form-label">
                                                <span class="is-srOnly">Checkbox {{order_product_id}} label</span>
                                            </label>
                                        </div>
                                        
                                        <div class="account-product-body account-details__body">
                                            <img class='account-details__image' src=''/>
                                            <h5 class="account-product-title">${parseInt(item.OrderQty.value)} &#215; ${item.LineDescription.value}</h5>
                                            <span class="account-product-price"><strong>Unit Price:</strong>$${item.UnitPrice.value}</span>
                                        </div>
                                        </div>
                                    </li>`
            })
            document.querySelector('.account-list').innerHTML = `${detailItems}`

            document.querySelector('.account-orderTotal').innerHTML = `
            <dt class="account-orderTotal-key">Shipping:</dt>
            <dd class="account-orderTotal-value">COME BACK HERE</dd>

            <dt class="account-orderTotal-key">Oversizes:</dt>
            <dd class="account-orderTotal-value">COME BACK HERE</dd>

            <dt class="account-orderTotal-key">Other Charges:</dt>
            <dd class="account-orderTotal-value">COME BACK HERE</dd>

            <dt class="account-orderTotal-key">Subtotal:</dt>
            <dd class="account-orderTotal-value">$${parseFloat(result.Order.OrderTotal.value - result.Order.TaxTotal.value, 2)}</dd>

            <dt class="account-orderTotal-key">Grand Total:</dt>
            <dd class="account-orderTotal-value">$${parseFloat(result.Order.OrderTotal.value, 2)}</dd>
            `

            document.querySelector('.definitionList').innerHTML = `
                <dt class="definitionList-key">Order Status:</dt>
                <dd class="definitionList-value">${result.Order.Status.value}</dd>
                <dt class="definitionList-key">Date:</dt>
                <dd class="definitionList-value">${new Date(result.Order.Date.value).toLocaleDateString()}</dd>
                <dt class="definitionList-key">Order Total:</dt>
                <dd class="definitionList-value">${result.Order.OrderTotal.value}</dd>
                <dt class="definitionList-key">Payment Method</dt>
                <dd class="definitionList-value">
                    ${result.Order.PaymentMethod}
                </dd>
            `
        })
        .catch(error => console.log('error', error));
    }
}
