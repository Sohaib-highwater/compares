/*
 Import all product specific js
 */
import PageManager from './page-manager';
import Review from './product/reviews';
import collapsibleFactory from './common/collapsible';
import ProductDetails from './common/product-details';
import videoGallery from './product/video-gallery';
import { classifyForm } from './common/utils/form-utils';
import modalFactory, { modalTypes } from './global/modal';
import { Callbacks, valHooks } from 'jquery';
import swal from './global/sweet-alert';


const { WRITE_REVIEW } = modalTypes;

export default class Product extends PageManager {
    constructor(context) {
        super(context);
        this.url = window.location.href;
        this.$reviewLink = $('[data-reveal-id="modal-review-form"]');
        this.$bulkPricingLink = $('[data-reveal-id="modal-bulk-pricing"]');
        this.reviewModal = modalFactory('#modal-review-form')[0];
    }

    onReady() {
        //form validation product view caps
        var triggerButton = document.querySelector('#customButton')
        if (triggerButton != null) {
            triggerButton.onclick = () => {
                // this.checkFlange(this.context.flangeError);
                // this.checkSkirt(this.context.skirtError);
                // this.checkOverhang(this.context.lidOverhangError);
                // this.checkScreen(this.context.screenError);
                // this.checkPitch(this.context.pitchError);
                // this.checkLid(this.context.lidError);
                // this.checkCap(this.context.capError);
                // this.checkPowder(this.context.powderError);
                // this.checkMaterial(this.context.materialError);

                // console.log(capsForm.reportValidity());
                // if (capsForm.reportValidity() == true) {
                //     console.log("form validation has passed");
                //     this.getValue();
                // }
                // else {
                //     console.log('form validation has failed');
                // }
            }
        }
        this.checkMaterial()
        
        //form validation product view cover
        let form = document.querySelector('.custom-form-pv_cover');
        let triggerButtonCover = document.querySelector('#calculateQuoteCover');
        if (triggerButtonCover != null) {
            triggerButtonCover.onclick = () => {
                console.log(form.reportValidity());
                if (form.reportValidity() == true) {
                    console.log("form validation has passed")
                    this.getValueCover();
                }
                else {
                    console.log('form validation has failed');
                }
            }
        }

        //invoke function
        this.getHoleValue();
        /* -------------------------------------------------------------------------- */
        // function for input width check
        // check to see if exists
        if(document.getElementById("txtLongWidth") != null){
            document.getElementById("txtLongWidth").addEventListener('blur', () => {
                this.checkWidth(this.context.widthError);
                this.minWidth(this.context.minWidthError);
            })
            document.getElementById("txtLongLength").addEventListener('blur', () => {
                this.checkWidth(this.context.widthError);
                this.minLength(this.context.lengthError);
            })
        }
        /* -------------------------------------------------------------------------- */


        // Listen for foundation modal close events to sanitize URL after review.
        $(document).on('close.fndtn.reveal', () => {
            if (this.url.indexOf('#write_review') !== -1 && typeof window.history.replaceState === 'function') {
                window.history.replaceState(null, document.title, window.location.pathname);
            }
        });

        document.querySelectorAll('.tab-content-accordion').forEach(item => item.addEventListener('click', (evt) => {
            let index = ($(evt.target).data('index'));
            let selected = $('.tabs li').eq(index);
            let tabAnchor = selected.find('a');
            tabAnchor.trigger('click');
            $(evt.target).toggleClass('is-active');
        }));

        let validator;

        // Init collapsible
        collapsibleFactory();

        this.productDetails = new ProductDetails($('.productView'), this.context, window.BCData.product_attributes);
        this.productDetails.setProductVariant();

        videoGallery();

        this.bulkPricingHandler();

        const $reviewForm = classifyForm('.writeReview-form');

        if ($reviewForm.length === 0) return;

        const review = new Review($reviewForm);

        $(document).on('opened.fndtn.reveal', '#modal-review-form', () => this.reviewModal.setupFocusableElements(WRITE_REVIEW));

        $('body').on('click', '[data-reveal-id="modal-review-form"]', () => {
            validator = review.registerValidation(this.context);
            this.ariaDescribeReviewInputs($reviewForm);
        });

        $reviewForm.on('submit', () => {
            if (validator) {
                validator.performCheck();
                return validator.areAll('valid');
            }

            return false;
        });

        this.productReviewHandler();
    }

    

    /* -------------------------------------------------------------------------- */
    checkMaterial() {
        if(document.querySelector('#material_1')) {
            document.querySelector('#material_1').addEventListener('change', (e) => {
                if (e.target.value == "copper") {
                    document.querySelector('#ddlPowderCoat').value = "No";
                    document.querySelector('#ddlPowderCoat').disabled = true
                } else {
                    document.querySelector('#ddlPowderCoat').disabled = false

                }
            })
        }
    }

    /* -------------------------------------------------------------------------- */

    hideLoader () {
        console.log('hi')
        $('.loadingOverlay').hide();

    }

    /* -------------------------------------------------------------------------- */
    checkWidth(errorString) {
        let width = document.querySelector('#txtLongWidth');
        let length = document.querySelector('#txtLongLength');
        if (Number(width.value) > Number(length.value)) {
            swal.fire({
                text: errorString,
                icon: 'error',
            });
        }
    };
    /* -------------------------------------------------------------------------- */

        //does cart exist
    isCartFetch(callback) {
        var data = "";
        var xhr = new XMLHttpRequest();

        xhr.addEventListener("readystatechange", function() {
        if(this.readyState === 4) {
            console.log('here',this.responseText)
            if (this.responseText == '[]') {
                console.log('hit here')
                callback(false)
            } else {
                callback(JSON.parse(this.responseText)[0].id)
            }
        }
        });

        xhr.open("GET", "/api/storefront/carts");

        xhr.send(data);
    }

    /* -------------------------------------------------------------------------- */
    isLoggedIn(callback) {
        var data = "";

        var xhr = new XMLHttpRequest();

        xhr.addEventListener("readystatechange", function() {
        let jwt = ''
        if (this.readyState === 4) {
            if (this.status == 200) {
                jwt = this.responseText
                callback(jwt)
            };
        }
        });

        xhr.open("GET", "/customer/current.jwt?app_client_id=fofeecjdszopvr4xjzzrmvokoyag1ch");

        xhr.send(data);
    }
    /* -------------------------------------------------------------------------- */
        // createCart(jwt, price) {
        //     var data = JSON.stringify({
        //         "line_items": [
        //           {
        //             "quantity": 1,
        //             "product_id": 112,
        //             "list_price": price
        //           }
        //         ]
        //       });
            
        //     var xhr = new XMLHttpRequest();
            
        //     xhr.addEventListener("readystatechange", function() {
        //         if(this.readyState === 4) {
        //             console.log('created', this.responseText)
        //             let xhrStatus = this.status
        //             setTimeout(function(){
        //                 $('.loadingOverlay').hide();
        //                 if (xhrStatus == 200) {
        //                     $('#add-to-cart-success').addClass('is-visible');
        //                     setInterval(() => {
        //                         $('#add-to-cart-success').removeClass('is-visible');
        //                     }, 4000);
        //                 }
        //               }, 1000);
        //         } else {
        //             $('.loadingOverlay').show();
        //         }
              
        //     });
            
        //     xhr.open("POST", `${this.context.middleware_url}/api/carts/create`);
        //     xhr.setRequestHeader("Content-Type", "application/json");
        //     if (jwt != '') {
        //         xhr.setRequestHeader("Authorization", `Bearer ${jwt}`);
        //     }
            
        //     xhr.send(data);
        // }
    /* -------------------------------------------------------------------------- */
        // addToCart(cartId, jwt, price) {
        //     var data = JSON.stringify({
        //         "line_items": [
        //           {
        //             "quantity": 1,
        //             "product_id": 112,
        //             "list_price": price
        //           }
        //         ]
        //       });
              
        //     var xhr = new XMLHttpRequest();
            
        //     xhr.addEventListener("readystatechange", function() {
        //         if(this.readyState === 4) {
        //             console.log('added', this.responseText)
        //             let xhrStatus = this.status
        //             setTimeout(function(){
        //                 $('.loadingOverlay').hide();
        //                 if (xhrStatus == 200) {
        //                     $('#add-to-cart-success').addClass('is-visible');
        //                     setInterval(() => {
        //                         $('#add-to-cart-success').removeClass('is-visible');
        //                     }, 4000);
        //                 }

        //               }, 1000);
        //         } else {
        //             $('.loadingOverlay').show();
        //         }
        //     });
            
        //     xhr.open("POST", `${this.context.middleware_url}/api/carts/addlineitem?cartId=${cartId}`);
        //     xhr.setRequestHeader("Content-Type", "application/json");
        //     if (jwt != '') {
        //         xhr.setRequestHeader("Authorization", `Bearer ${jwt}`);
        //     }
            
              
        //     xhr.send(data);
        // }
    /* -------------------------------------------------------------------------- */



    minLength(errorString) {
        let flue = document.querySelector('#ddlCapType')
        let length = document.querySelector('#txtLongLength')
        if ((length.value.trim() == "" || length.value < 9) && (flue.options[flue.selectedIndex].value != 'MFSRnd')) {
            swal.fire({
                text: errorString,
                icon: 'error',
            });
        }
    };
    /* -------------------------------------------------------------------------- */
    minWidth(errorString) {
        let flue = document.querySelector('#ddlCapType')
        let width = document.querySelector('#txtLongWidth')
        if ((width.value.trim() == "" || width.value < 9) && (flue.options[flue.selectedIndex].value != 'MFSRnd')) {
            swal.fire({
                text: errorString,
                icon: 'error',
            });
        }
    };
    /* -------------------------------------------------------------------------- */

    // on submit functions
    // checkMaterial(errorString) {
    //     if ($("#material_1")[0].selectedIndex <= 0) {
    //         swal.fire({
    //             text: errorString,
    //             icon: 'error',
    //         });
    //     }

    // }
    // checkPowder(errorString) {
    //     if ($("#ddlPowderCoat")[0].selectedIndex <= 0) {
    //         swal.fire({
    //             text: errorString,
    //             icon: 'error',
    //         });
    //     }

    // }
    // checkCap(errorString) {
    //     if ($("#ddlCapType")[0].selectedIndex <= 0) {
    //         swal.fire({
    //             text: errorString,
    //             icon: 'error',
    //         });
    //     }

    // }
    // checkLid(errorString) {
    //     if ($("#ddlLidStyle")[0].selectedIndex <= 0) {
    //         swal.fire({
    //             text: errorString,
    //             icon: 'error',
    //         });
    //     }

    // }
    // //input
    // checkScreen(errorString) {
    //     let screenHeight = document.querySelector('#txtScreenHeight')
    //     if (screenHeight.value.trim() == "" || screenHeight.value > 24) {
    //         swal.fire({
    //             text: errorString,
    //             icon: 'error',
    //         });
    //     }

    // }
    // //input
    // checkOverhang(errorString) {
    //     let lidOverhang = document.querySelector('#txtLidOverHang')
    //     if (lidOverhang.value.trim() == "" || lidOverhang.value > 8) {
    //         swal.fire({
    //             text: errorString,
    //             icon: 'error',
    //         });
    //     }

    // }
    // checkPitch(errorString) {
    //     if ($("#ddlHipRidgePitch")[0].selectedIndex <= 0) {
    //         swal.fire({
    //             text: errorString,
    //             icon: 'error',
    //         });
    //     }

    // }
    // //input
    // checkSkirt(errorString) {
    //     let skirt = document.querySelector('#skirt')
    //     if (skirt.value.trim() == "") {
    //         swal.fire({
    //             text: errorString,
    //             icon: 'error',
    //         });
    //     }

    // }
    // checkFlange(errorString) {
    //     if ($("#ddlCapFlange")[0].selectedIndex <= 0) {
    //         swal.fire({
    //             text: errorString,
    //             icon: 'error',
    //         });
    //     }

    // }
    /* -------------------------------------------------------------------------- */

    // adding here
    //get value on caps page
    getValue() {
        console.log("Function call on caps");
        const capObject = {
            "material": $("#material_1 option:selected").text(),
            "powder_coat": $("#ddlPowderCoat").val(),
            "cap_type": $("#ddlCapType option:selected").text(),
            "lid_style": $("#ddlLidStyle option:selected").text(),
            "pitch": $("#ddlHipRidgePitch option:selected").text(),
            "longest_length": parseFloat($("#txtLongLength").val()),
            "longest_width": parseFloat($("#txtLongWidth").val()),
            "length": parseFloat($("#txtlength").val()),
            "width": parseFloat($("#txtWidth").val()),
            "screen_height": parseFloat($("#txtScreenHeight").val()),
            "lid_overhang": parseFloat($("#txtLidOverHang").val()),
            "skirt_height": parseFloat($("#skirt").val()),
            "flue_diameter": parseFloat($("#txtDiameter").val()),
            "mesh": $("#ddlMesh option:selected").text(),
            "flange_type": $("#ddlCapFlange option:selected").text(),
            "skirt_profile": $("#ddlBigDripperSkirt option:selected").text(),
            "mount_type": $("#ddlMountType option:selected").text(),
            "crated": $("#crated option:selected").text()
        };
        console.log(capObject);
        return capObject
    }

    // get value on cover page
    getValueCover() {
        console.log("Function call on cover");
        const coverObject = {
            "Material": $("#material_cover option:selected").text(),
            "Powder Coat": $("#ddlPowderCoat_cover option:selected").text(),
            "Length 1": $("#length1_cover").val(),
            "Width 2": $("#width1_cover").val(),
            "Length 3": $("#length2_cover").val(),
            "Width 4": $("#width2_cover").val(),
            "Skirt Height": $("#skirt_cover").val(),
            "Built To": $("#ddlFitFinish option:selected").text(),
            "Drip Edge": $("#dripedge_cover option:selected").text(),
            "# Of Holes": $("#holes_cover option:selected").text(),
            "Crated": $("#crated_cover option:selected").text(),
            "Item Notes": $("#lblitemnotes_cover").val()
        };
        console.log(coverObject);
    }

    // Hole specification functionality dropdown
    getHoleValue() {
        $('#holes_dropdown_num').on('change', (e) => {
            let holesValue = parseInt(e.target.value);
            if (holesValue > 0) {
              document.querySelector('.custom-top__image-container').classList.add('active');
            } else {
              document.querySelector('.custom-top__image-container').classList.remove('active');              
            }
            console.log(holesValue);
            let newArray = $('.custom-hole-container');
            console.log(newArray);
            let i = 1;
            let finArray = [];
            $('.custom-hole-container').css('display', 'none');
            while (i <= holesValue) {
                console.log("The number is " + i);
                let calc = i - 1;
                finArray.push(newArray[calc]);
                i++;
            }
            console.log(finArray);
            finArray.forEach(element => element.style.display = 'flex');
        });
    }


    ariaDescribeReviewInputs($form) {
        $form.find('[data-input]').each((_, input) => {
            const $input = $(input);
            const msgSpanId = `${$input.attr('name')}-msg`;

            $input.siblings('span').attr('id', msgSpanId);
            $input.attr('aria-describedby', msgSpanId);
        });
    }

    productReviewHandler() {
        if (this.url.indexOf('#write_review') !== -1) {
            this.$reviewLink.trigger('click');
        }
    }

    bulkPricingHandler() {
        if (this.url.indexOf('#bulk_pricing') !== -1) {
            this.$bulkPricingLink.trigger('click');
        }
    }
}
